﻿using System.ComponentModel.DataAnnotations;

namespace ScottysWebApp.Client.Models.Users
{
    public class DeleteUser
    {
        [Required]
        public string Username { get; set; }
    }
}
