﻿using System.ComponentModel.DataAnnotations;

namespace ScottysWebApp.Client.Models.Users
{
    public class ForgotPasswordRequest
    {
        [Required]
        [EmailAddress]
        public string Email { get; set; }
    }
}
