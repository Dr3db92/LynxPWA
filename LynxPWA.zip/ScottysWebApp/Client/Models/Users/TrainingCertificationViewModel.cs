﻿namespace ScottysWebApp.Client.Models.Users
{
    public class TrainingCertificationViewModel
    {
        public int TrainingID { get; set; }
        public string? UserName { get; set; }
        public string UserID { get; set; }
        public string? ModelName { get; set; }
        public string? PdfData { get; set; } // Base64 string
        public byte[]? FormData { get; set; }
        public DateTime? UploadedAt { get; set; }
    }

}
