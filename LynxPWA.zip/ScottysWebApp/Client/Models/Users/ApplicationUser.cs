﻿namespace ScottysWebApp.Client.Models.Users
{
    public class ApplicationUser
    {
        public int Id { get; set; }
        public string Username { get; set; }
        public string PasswordHash { get; set; }
    }

}
