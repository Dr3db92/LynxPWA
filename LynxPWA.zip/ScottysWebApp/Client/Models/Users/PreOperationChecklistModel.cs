﻿using ScottysWebApp.Client.Models.Forms;

namespace ScottysWebApp.Client.Models.Users
{
    public class PreOperationChecklistModel
    {
        public string OperatorName { get; set; }
        public string SelectedEquipment { get; set; }
        public int? Start { get; set; }
        public int? Stop { get; set; }
        public string Comments { get; set; }
        public byte[]? OperatorSignature { get; set; }
        public DateTime ChecklistDate { get; set; } = DateTime.Now;
        public List<ComponentItem> ComponentItems { get; set; } = new List<ComponentItem>();
    }
}
