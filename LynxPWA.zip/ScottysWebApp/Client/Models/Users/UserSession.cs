﻿namespace ScottysWebApp.Client.Models.Users

{
    public class UserSession
    {
        public string UserID { get; set; }
        public string UserName { get; set; }
        public DateTime LastActiveTime { get; set; } // Track user's last activity time
        public bool IsActive { get; set; } // Whether the user is currently active
    }
}
