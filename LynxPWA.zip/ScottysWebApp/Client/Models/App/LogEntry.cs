﻿namespace ScottysWebApp.Client.Models.App
{
    public class LogEntry
    {
        public int Id { get; set; }
        public DateTime Timestamp { get; set; }
        public string Level { get; set; }
        public string Message { get; set; }
        public string? Exception { get; set; }
        public string? Properties { get; set; }
        public string DeviceId { get; set; }
        public string UserId { get; set; }
        public string RequestPath { get; set; }
        public string CorrelationId { get; set; }
        public string ApplicationVersion { get; set; }
        public string Environment { get; set; }
    }
}
