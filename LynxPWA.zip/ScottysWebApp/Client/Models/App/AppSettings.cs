﻿namespace ScottysWebApp.Client.Models.App
{
    public class AppSettings
    {
        public long MaxFileSize { get; set; }
    }
}
