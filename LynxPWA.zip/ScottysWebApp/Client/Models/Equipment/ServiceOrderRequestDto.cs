﻿using ScottysWebApp.Client.Models.PartModel;

namespace ScottysWebApp.Client.Models.Equipment
{
    public class ServiceOrderRequestDto
    {
        public int RequestID { get; set; }
        public int EquipmentID { get; set; }
        public string OperatorName { get; set; }
        public string DeficienciesIssues { get; set; }
        public string WhereOccurred { get; set; }
        public DateTime? WhenOccurred { get; set; }
        public byte[]? OperatorSignature { get; set; }
        public DateTime? OperatorDate { get; set; }
        public string Corrections { get; set; }
        public byte[]? MaintenanceSignature { get; set; }
        public decimal? MechanicHours { get; set; }
        public DateTime? CorrectionStartDate { get; set; }
        public DateTime? CorrectionDate { get; set; }
        public string Status { get; set; }
        public string Priority { get; set; }
        public EquipmentInfo Equipment { get; set; } // Full Equipment object
        public List<SelectedPartDto> SelectedParts { get; set; }
    }
}
