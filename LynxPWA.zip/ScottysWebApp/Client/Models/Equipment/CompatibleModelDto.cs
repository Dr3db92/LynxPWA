﻿namespace ScottysWebApp.Client.Models.Equipment
{
    public class CompatibleModelDto
    {
        public int ModelID { get; set; }
        public int PartID { get; set; }
        public string ModelName { get; set; }
        public int EquipmentID { get; set; }
    }
}
