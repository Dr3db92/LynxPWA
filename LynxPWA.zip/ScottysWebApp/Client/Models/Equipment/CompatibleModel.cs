﻿using ScottysWebApp.Client.Models.PartModel;
using ScottysWebApp.Client.Models.Users;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace ScottysWebApp.Client.Models.Equipment
{
    public class CompatibleModel
    {
        [Key]
        [JsonPropertyName("modelID")]
        public int ModelID { get; set; }

        [JsonPropertyName("partID")]
        public int PartID { get; set; }

        [JsonPropertyName("modelName")]
        public string ModelName { get; set; }

        [JsonPropertyName("equipmentID")]
        public int EquipmentID { get; set; }

        [JsonIgnore]
        public Parts Part { get; set; } // Ignore during serialization

        public EquipmentInfo Equipment { get; set; }

        public ICollection<EquipmentCompatibleModel> EquipmentCompatibleModels { get; set; } = new List<EquipmentCompatibleModel>();
        public ICollection<TrainingCertifications> TrainingCertifications { get; set; } = new List<TrainingCertifications>();
    }
}
