﻿namespace ScottysWebApp.Client.Models.Equipment
{
    public class UpdateMilesDTO
    {
        public int EquipmentID { get; set; }
        public int Miles { get; set; }
    }
}
