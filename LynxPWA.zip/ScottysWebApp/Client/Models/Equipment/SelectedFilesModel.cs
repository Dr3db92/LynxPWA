﻿using ScottysWebApp.Client.Models.Forms;

namespace ScottysWebApp.Client.Models.Equipment
{
    public class SelectedFilesModel
    {
        public List<FileModel> Files { get; set; } = new List<FileModel>();

        public List<int> SelectedFileIds => Files.Where(f => f.IsSelected).Select(f => f.DocumentId).ToList();
    }
}
