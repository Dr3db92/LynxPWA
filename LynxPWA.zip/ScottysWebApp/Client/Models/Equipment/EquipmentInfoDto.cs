﻿namespace ScottysWebApp.Client.Models.Equipment
{
    public class EquipmentInfoDto
    {
        public string EquipmentID { get; set; }
        public string ModelNumber { get; set; }
        public string SerialNumber { get; set; }
        public string Description { get; set; }
        public string LocalEquipmentName { get; set; }
        public string Manufacturer { get; set; }
        public string PurchaseDate { get; set; }
        public string Cost { get; set; }
        public string WarrantyExpiration { get; set; }
        public string Location { get; set; }
    }
}
