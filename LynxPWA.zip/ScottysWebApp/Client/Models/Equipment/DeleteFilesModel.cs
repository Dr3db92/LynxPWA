﻿namespace ScottysWebApp.Client.Models.Equipment
{
    public class DeleteFilesModel
    {
        public string ModelName { get; set; }
    }
}
