﻿using ScottysWebApp.Client.Models.Plant;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ScottysWebApp.Client.Models.PartModel
{
    public class WorkOrderPart
    {
        public int RecordPartID { get; set; }
        [ForeignKey("WorkOrderRecord")]
        public int RecordID { get; set; }
        public int PartID { get; set; }
        public string PartName { get; set; }
        [Range(0, int.MaxValue, ErrorMessage = "Quantity must be a non-negative number.")]
        public int QuantityUsed { get; set; }
        public WorkOrderRecord WorkOrderRecord { get; set; }
    }
}
