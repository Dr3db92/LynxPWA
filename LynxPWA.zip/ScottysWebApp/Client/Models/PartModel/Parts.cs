﻿using System.ComponentModel.DataAnnotations;
using ScottysWebApp.Client.Models.Equipment;
using ScottysWebApp.Client.Models.Plant;

namespace ScottysWebApp.Client.Models.PartModel
{
    public class Parts
    {
        [Key]
        public int PartID { get; set; }
        public string? PartName { get; set; }
        public string? PartNumber { get; set; }
        public int? Quantity { get; set; }
        public decimal? Cost { get; set; }
        public string? Description { get; set; }
        public string? OEM { get; set; }

        public string? WebsiteLink { get; set; }    // New field for website link

        public int? PlantID { get; set; }  // Nullable in case no plant is assigned
        public Plants? Plant { get; set; }  // Navigation property to the Plant

        public List<CompatibleModel>? CompatibleModels { get; set; } = new List<CompatibleModel>();
        public ICollection<SelectedPart> SelectedParts { get; set; } = new List<SelectedPart>();
        public ICollection<WorkOrderSelectedPart> WorkOrderSelectedPart { get; set; } = new List<WorkOrderSelectedPart>();
    }
}
