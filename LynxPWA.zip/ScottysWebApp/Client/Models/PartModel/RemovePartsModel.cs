﻿namespace ScottysWebApp.Client.Models.PartModel
{
    public class RemovePartsModel
    {
        public List<int> SelectedParts { get; set; } = new List<int>();
    }
}
