﻿using ScottysWebApp.Client.Models.Equipment;
using ScottysWebApp.Client.Models.Plant;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ScottysWebApp.Client.Models.PartModel
{
    public class SelectedPart
    {
        [Key]
        public int SelectedPartID { get; set; }
        public int PartID { get; set; }
        public string PartName { get; set; }
        public int QuantityUsed { get; set; }

        // Foreign key to MaintenanceRequest (RequestID)
        public int? RequestID { get; set; }

        public int? RecordID { get; set; }

        // Foreign key to RepairHistories (RepairID)
        public int? RepairID { get; set; }

        // Navigation properties
        [ForeignKey(nameof(RequestID))]
        public WorkOrderRequest? WorkOrderRequest { get; set; }

        [ForeignKey(nameof(RepairID))]
        public RepairHistories? RepairHistory { get; set; }

        [ForeignKey(nameof(PartID))]
        public Parts? Part { get; set; }

        // Remove ServiceOrderRequest if it's not relevant for your current context
        [ForeignKey(nameof(RequestID))]
        public ServiceOrderRequest? ServiceOrderRequest { get; set; }

        [ForeignKey(nameof(RecordID))]
        public WorkOrderRecord? WorkOrderRecord { get; set; }
    }
}
