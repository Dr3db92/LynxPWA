﻿using ScottysWebApp.Client.Models.Equipment;
using ScottysWebApp.Client.Models.PartModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ScottysWebApp.Client.Models.Plant
{
    public class WorkOrderRequest
    {
        [Key]
        public int RequestID { get; set; }

        public int? EquipmentID { get; set; }

        [Required]
        public string OperatorName { get; set; }

        [Required]
        public string Priority { get; set; } = "Low";  // Default Priority

        public string WhereOccurred { get; set; }

        public DateTime? WhenOccurred { get; set; }

        [Required]
        public string DeficienciesIssues { get; set; }

        public int? PlantID { get; set; }

        public string? Comments { get; set; }

        public byte[]? OperatorSignature { get; set; }

        public DateTime Date { get; set; } = DateTime.Now;

        [Required]
        public string Status { get; set; } = "Pending";  // Default Status

        public DateTime? CorrectionStartDate { get; set; }

        public string? Corrections { get; set; } = string.Empty;  // Default empty string for Corrections

        public decimal? MechanicHours { get; set; }

        public byte[]? MaintenanceSignature { get; set; }

        public ICollection<SelectedPart> SelectedPart { get; set; } = new List<SelectedPart>();

        public string? ImageFileName { get; set; }

        public byte[]? ImageData { get; set; }

        public DateTime? CompletedDate { get; set; }

        public Plants? Plant { get; set; }

        [ForeignKey(nameof(EquipmentID))]
        public EquipmentInfo? Equipment { get; set; }
        public ICollection<WorkOrderSelectedPart> WorkOrderSelectedPart { get; set; } = new List<WorkOrderSelectedPart>();
    }
}
