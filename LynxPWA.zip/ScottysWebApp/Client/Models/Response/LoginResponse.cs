﻿namespace ScottysWebApp.Client.Models.Response
{
    public class LoginResponse
    {
        public string Message { get; set; }
        public string Role { get; set; }
    }
}
