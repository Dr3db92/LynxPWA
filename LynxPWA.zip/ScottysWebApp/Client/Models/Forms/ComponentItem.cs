﻿namespace ScottysWebApp.Client.Models.Forms
{
    public class ComponentItem
    {
        public string? ComponentText { get; set; }
        public string? GroupName { get; set; }
        public string Status { get; set; } = "";
        public bool IsEnabled { get; set; } = false;
        public string Comment { get; set; } = "";
        public bool IsCommentRequired { get; set; } = false;
    }
}
