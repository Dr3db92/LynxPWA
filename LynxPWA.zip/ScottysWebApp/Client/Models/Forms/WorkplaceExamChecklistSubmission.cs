﻿using ScottysWebApp.Client.Models.Plant;
using System.ComponentModel.DataAnnotations;

namespace ScottysWebApp.Client.Models.Forms
{
    public class WorkplaceExamChecklistSubmission
    {
        [Key]
        public int Id { get; set; }

        public string OperatorName { get; set; }
        public int PlantID { get; set; }
        public string? InspectionArea { get; set; }
        public string Comments { get; set; }
        public byte[]? OperatorSignature { get; set; }
        public DateTime ChecklistDate { get; set; }

        public ICollection<WorkplaceExamChecklistItem> Items { get; set; } = new List<WorkplaceExamChecklistItem>();
        public Plants Plant { get; set; }
    }
}
