﻿using System.ComponentModel.DataAnnotations;

namespace ScottysWebApp.Client.Models.Forms
{
    public class AreasWorkingRow
    {
        public string? DeficienciesFound { get; set; }
        public string? Comments { get; set; } = string.Empty;
        [Required]
        public DateTime DateCorrected { get; set; } = DateTime.Today;
    }
}
