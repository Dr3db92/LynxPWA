﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace ScottysWebApp.Client.Models.Forms
{
    public class WorkplaceExamChecklistItem
    {
        [Key]
        public int Id { get; set; }

        [ForeignKey("WorkplaceExamChecklistSubmission")]
        public int SubmissionId { get; set; }
        public WorkplaceExamChecklistSubmission Submission { get; set; }

        public string InspectionText { get; set; }
        public bool IsOkSelected { get; set; }
        public bool IsDefSelected { get; set; }
        public string DeficienciesFound { get; set; }
    }
}
