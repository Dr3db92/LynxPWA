﻿namespace ScottysWebApp.Client.Models.Forms
{
    public class DataRow
    {
    }
}
