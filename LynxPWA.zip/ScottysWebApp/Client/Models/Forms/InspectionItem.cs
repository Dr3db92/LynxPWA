﻿namespace ScottysWebApp.Client.Models.Forms
{
    public class InspectionItem
    {
        public string? InspectionText { get; set; }
        public string? GroupName { get; set; }
        public bool IsOkSelected { get; set; }
        public bool IsDefSelected { get; set; }
        public string DeficienciesFound { get; set; } = "";
        public bool IsCommentRequired { get; set; } = false;
        public bool IsEnabled { get; set; } = false;

    }
}
