﻿using System.ComponentModel.DataAnnotations;

namespace ScottysWebApp.Client.Models.Forms
{
    public class AreasWorkingDTO
    {
        [Required]
        public string? OperatorName { get; set; }
        [Required]
        public string? AreasWorking { get; set; }
        public bool NoDeficienciesFound { get; set; }
        public List<AreasWorkingRowDTO> Deficiencies { get; set; } = new List<AreasWorkingRowDTO>();
        [Required]
        public byte[]? OperatorSignature { get; set; }
        [Required]
        public DateTime Date { get; set; }
    }
}
