﻿namespace ScottysWebApp.Client.Models.Forms
{
    public class InspectionSection
    {
        public string? Title { get; set; }
        public List<InspectionItem>? Items { get; set; }
    }

}
