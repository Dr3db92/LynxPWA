﻿using ScottysWebApp.Client.Models.Plant;

namespace ScottysWebApp.Client.Models.Forms
{
    public class WorkplaceExamChecklistDTO
    {
        public string? OperatorName { get; set; }
        public int? PlantID { get; set; }
        public string? InspectionArea { get; set; }
        public List<InspectionItemDTO> InspectionItems { get; set; } = new List<InspectionItemDTO>();
        public string? Comments { get; set; }
        public byte[]? OperatorSignature { get; set; }
        public DateTime Date { get; set; }

        public Plants? Plant { get; set; }
    }
}
