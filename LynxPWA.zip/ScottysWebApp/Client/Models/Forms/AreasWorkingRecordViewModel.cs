﻿namespace ScottysWebApp.Client.Models.Forms
{
    public class AreasWorkingRecordViewModel
    {
        public int? SubmissionId { get; set; }
        public int? RequestId { get; set; }
        public string OperatorName { get; set; } = string.Empty;
        public string AreasWorking { get; set; } = string.Empty;
        public bool NoDeficienciesFound { get; set; }
        public string DeficienciesFound { get; set; }
        public DateTime? DateCorrected { get; set; }
        public string Comments { get; set; }
        public string? UpdatedComments { get; set; } = string.Empty;
        public byte[]? OperatorSignature { get; set; } = Array.Empty<byte>();
        public DateTime? Date { get; set; }
        public byte[] MaintenanceSignature { get; set; } = Array.Empty<byte>();
        public DateTime? MaintenanceDate { get; set; }
        public bool IsProcessed { get; set; }
        public bool IsRequest { get; set; }
        public List<DeficiencyViewModel> Deficiencies { get; set; } = new List<DeficiencyViewModel>();

    }
}
