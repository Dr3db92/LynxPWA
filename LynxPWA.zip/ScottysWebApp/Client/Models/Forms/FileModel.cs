﻿namespace ScottysWebApp.Client.Models.Forms
{
    public class FileModel
    {
        public int DocumentId { get; set; }
        public string FileName { get; set; }
        public bool IsSelected { get; set; }
    }
}
