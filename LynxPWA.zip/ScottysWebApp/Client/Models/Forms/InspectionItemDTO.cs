﻿namespace ScottysWebApp.Client.Models.Forms
{
    public class InspectionItemDTO
    {
        public string? InspectionText { get; set; }
        public bool IsOkSelected { get; set; }
        public bool IsDefSelected { get; set; }
        public string? DeficienciesFound { get; set; }
    }
}
