﻿namespace ScottysWebApp.Client.Models.Forms
{
    public class DeficiencyViewModel
    {
        public string DeficienciesFound { get; set; }
        public DateTime? DateCorrected { get; set; }
        public string Comments { get; set; }
    }
}
