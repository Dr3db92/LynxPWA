﻿using Microsoft.AspNetCore.Components.Authorization;
using Serilog;
using Serilog.Sinks.Http.BatchFormatters;
using System.Security.Claims;
using System.Text;
using System.Text.Json;

namespace ScottysWebApp.Client.Services
{
    public class ClientLogger
    {
        private readonly AuthenticationStateProvider _authenticationStateProvider;
        private readonly DeviceIdService _deviceIdService;
        private readonly HttpClient _httpClient;

        public ClientLogger(AuthenticationStateProvider authenticationStateProvider, DeviceIdService deviceIdService, HttpClient httpClient)
        {
            _authenticationStateProvider = authenticationStateProvider;
            _deviceIdService = deviceIdService;
            _httpClient = httpClient;
        }

        public async Task Configure()
        {
            var authState = await _authenticationStateProvider.GetAuthenticationStateAsync();
            var user = authState.User;

            var userId = user.FindFirstValue(ClaimTypes.NameIdentifier) ?? "Anonymous";
            var deviceId = await _deviceIdService.GetOrCreateDeviceIdAsync();
            var correlationId = Guid.NewGuid().ToString();

            Log.Logger = new LoggerConfiguration()
                .MinimumLevel.Information()
                .Enrich.WithProperty("DeviceId", deviceId)
                .Enrich.WithProperty("UserId", userId)
                .Enrich.WithProperty("CorrelationId", correlationId)
                .Enrich.WithProperty("ApplicationVersion", "1.0.0")
                .Enrich.WithProperty("Environment", "Development")
                .WriteTo.Http(
                    requestUri: "https://localhost:7119/api/log",
                    queueLimitBytes: null,
                    batchFormatter: new ArrayBatchFormatter())
                .CreateLogger();
        }

        public async Task LogInformation(string message)
        {
            var logEntry = await CreateLogEntry("Information", message);
            await SendLogEntry(logEntry);
        }

        public async Task LogWarning(string message)
        {
            var logEntry = await CreateLogEntry("Warning", message);
            await SendLogEntry(logEntry);
        }

        public async Task LogError(string message, Exception exception = null)
        {
            var logEntry = await CreateLogEntry("Error", message, exception);
            await SendLogEntry(logEntry);
        }

        private async Task<LogEntry> CreateLogEntry(string level, string message, Exception exception = null)
        {
            var deviceId = await _deviceIdService.GetOrCreateDeviceIdAsync();
            var authState = await _authenticationStateProvider.GetAuthenticationStateAsync();
            var user = authState.User.Identity.IsAuthenticated ? authState.User.Identity.Name : "Anonymous";

            return new LogEntry
            {
                Timestamp = DateTime.UtcNow,
                Level = level,
                Message = message,
                Exception = exception?.ToString(),
                Properties = null,
                DeviceId = deviceId,
                UserId = user,
                RequestPath = "", // Adjust this if you can get the actual request path
                CorrelationId = Guid.NewGuid().ToString(),
                ApplicationVersion = "1.0.0",
                Environment = "Development"
            };
        }

        private async Task SendLogEntry(LogEntry logEntry)
        {
            try
            {
                var json = JsonSerializer.Serialize(logEntry);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                var response = await _httpClient.PostAsync("https://localhost:7119/api/log", content);

                if (!response.IsSuccessStatusCode)
                {
                    var errorMessage = await response.Content.ReadAsStringAsync();
                    Console.WriteLine($"Error logging message: {errorMessage}");
                }
            }
            catch (HttpRequestException ex)
            {
                Console.WriteLine($"Request failed: {ex.Message}");
                // Optional: Implement a retry mechanism or handle the failure accordingly.
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Unexpected error: {ex.Message}");
            }
        }
    }

    public class LogEntry
    {
        public int Id { get; set; }
        public DateTime Timestamp { get; set; }
        public string Level { get; set; }
        public string Message { get; set; }
        public string? Exception { get; set; }
        public string? Properties { get; set; }
        public string DeviceId { get; set; }
        public string UserId { get; set; }
        public string RequestPath { get; set; }
        public string CorrelationId { get; set; }
        public string ApplicationVersion { get; set; }
        public string Environment { get; set; }
    }
}