﻿using Microsoft.AspNetCore.Components.Authorization;

public class UpdateUserRoles
{
    private readonly AuthenticationStateProvider AuthenticationStateProvider;
    public string UserRole { get; private set; } = "Guest";
    public string UserName { get; private set; } = "Anonymous";

    //Event to notify when the user role has changed
    public event Action OnRoleChanged;

    //Initialize the authentication state provider
    public UpdateUserRoles(AuthenticationStateProvider authenticationStateProvider)
    {
        AuthenticationStateProvider = authenticationStateProvider;
    }

    //Update the user's role based on their authentication state
    public async Task UpdateUserRoleAsync()
    {
        var authState = await AuthenticationStateProvider.GetAuthenticationStateAsync();
        //Get the authenticated user
        var user = authState.User;

        //Get the username
        UserName = user.Identity?.Name ?? "Anonymous";

        //Check the user's role and update the user role property accordingly
        if (user.IsInRole("Admin"))
        {
            UserRole = "Admin";
        }
        else if (user.IsInRole("Mechanic"))
        {
            UserRole = "Mechanic";
        }
        else if (user.IsInRole("Maintenance"))
        {
            UserRole = "Maintenance";
        }
        else if (user.IsInRole("PartsManager"))
        {
            UserRole = "PartsManager";
        }
        else if (user.IsInRole("User"))
        {
            UserRole = "User";
        }
        //Default to this if there are no other matching roles
        else
        {
            UserRole = "Guest";
        }

        OnRoleChanged?.Invoke();
    }
}