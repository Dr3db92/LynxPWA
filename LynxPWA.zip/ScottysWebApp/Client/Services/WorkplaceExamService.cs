﻿using ScottysWebApp.Client.Models.Forms;

namespace ScottysWebApp.Client.Services
{
    public class WorkplaceExamService
    {
        public List<InspectionItem> GetInspectionItemsByArea(string area)
        {
            List<InspectionItem> items = new List<InspectionItem>();

            switch (area)
            {
                case "Primary Plant":
                    return new List<InspectionItem>
                    {
                        new InspectionItem { InspectionText ="Hand Rails - (Loose, Broken, or Missing)", GroupName="Group1" },
                        new InspectionItem { InspectionText ="Walk Ways - (Clean & Safe)", GroupName = "Group2"},
                        new InspectionItem { InspectionText ="Steps and Ladders - (Clean & Secure)", GroupName="Group3" },
                        new InspectionItem { InspectionText ="Guards - (Intact & Secure)", GroupName="Group4" },
                        new InspectionItem { InspectionText ="Electrical Cables & Connections - (Not Worn or Bare)", GroupName="Group5" },
                        new InspectionItem { InspectionText ="Warning Signs - (Clean & Visible)", GroupName="Group6" },
                        new InspectionItem { InspectionText ="Alarms - (Working Properly)", GroupName="Group7" },
                        new InspectionItem { InspectionText ="Fire Extinguishers - (In Date & Changed)", GroupName="Group8" },
                        new InspectionItem { InspectionText ="MCC #1 - (Clean & Dry)", GroupName="Group9" },
                        new InspectionItem { InspectionText ="MCC #2 - (Clean & Dry)", GroupName="Group10" },
                        new InspectionItem { InspectionText ="Connex - ", GroupName="Group11" },
                        new InspectionItem { InspectionText ="Bearings - ", GroupName="Group12" },
                        new InspectionItem { InspectionText ="Grease Line -", GroupName="Group13" },
                        new InspectionItem { InspectionText ="Zipper Condition -", GroupName="Group14" },
                        new InspectionItem { InspectionText ="Trough Rollers -", GroupName="Group15" },
                        new InspectionItem { InspectionText ="Return Rollers -", GroupName="Group16" }
                    };
                case "Secondary Plant":
                    return new List<InspectionItem>
                    {
                        new InspectionItem { InspectionText ="Hand Rails - (Loose, Broken, or Missing)", GroupName="Group1" },
                        new InspectionItem { InspectionText ="Walk Ways - (Clean & Safe)", GroupName = "Group2"},
                        new InspectionItem { InspectionText ="Steps and Ladders - (Clean & Secure)", GroupName="Group3" },
                        new InspectionItem { InspectionText ="Guards - (Intact & Secure)", GroupName="Group4" },
                        new InspectionItem { InspectionText ="Electrical Cables & Connections - (Not Worn or Bare)", GroupName="Group5" },
                        new InspectionItem { InspectionText ="Warning Signs - (Clean & Visible)", GroupName="Group6" },
                        new InspectionItem { InspectionText ="Alarms - (Working Properly)", GroupName="Group7" },
                        new InspectionItem { InspectionText ="Fire Extinguishers - (In Date & Changed)", GroupName="Group8" },
                        new InspectionItem { InspectionText ="MCC #3 - (Clean & Dry)", GroupName="Group9" },
                        new InspectionItem { InspectionText ="Connex - ", GroupName="Group10" },
                        new InspectionItem { InspectionText ="Oil Check Screen Bearings - ", GroupName="Group11" },
                        new InspectionItem { InspectionText ="Cone Oil #1 - ", GroupName="Group12" },
                        new InspectionItem { InspectionText ="Cone Oil #2 - ", GroupName="Group13" },
                        new InspectionItem { InspectionText ="Bearings - ", GroupName="Group14" },
                        new InspectionItem { InspectionText ="Grease Line -", GroupName="Group15" },
                        new InspectionItem { InspectionText ="Zipper Condition -", GroupName="Group16" },
                        new InspectionItem { InspectionText ="Trough Rollers -", GroupName="Group17" },
                        new InspectionItem { InspectionText ="Return Rollers -", GroupName="Group18" }
                    };
                case "Portable Plant":
                    return new List<InspectionItem>
                    {
                        new InspectionItem { InspectionText ="Hand Rails - (Loose, Broken, or Missing)", GroupName="Group1" },
                        new InspectionItem { InspectionText ="Walk Ways - (Clean & Safe)", GroupName = "Group2"},
                        new InspectionItem { InspectionText ="Steps and Ladders - (Clean & Secure)", GroupName="Group3" },
                        new InspectionItem { InspectionText ="Guards - (Intact & Secure)", GroupName="Group4" },
                        new InspectionItem { InspectionText ="Electrical Cables & Connections - (Not Worn or Bare)", GroupName="Group5" },
                        new InspectionItem { InspectionText ="Warning Signs - (Clean & Visible)", GroupName="Group6" },
                        new InspectionItem { InspectionText ="Alarms - (Working Properly)", GroupName="Group7" },
                        new InspectionItem { InspectionText ="Fire Extinguishers - (In Date & Changed)", GroupName="Group8" },
                        new InspectionItem { InspectionText ="Cone Oil - ", GroupName="Group9" },
                        new InspectionItem { InspectionText ="Control Building (Clean & Safe) - ", GroupName="Group10" },
                        new InspectionItem { InspectionText ="Bearings - ", GroupName="Group11" },
                        new InspectionItem { InspectionText ="Grease Line - ", GroupName="Group12" },
                        new InspectionItem { InspectionText ="Zipper Condition - ", GroupName="Group13" },
                        new InspectionItem { InspectionText ="Trough Rollers - ", GroupName="Group14" },
                        new InspectionItem { InspectionText ="Return Rollers - ", GroupName="Group15" }
                    };
                case "Scale House":
                    return new List<InspectionItem>
                    {
                        new InspectionItem { InspectionText ="House Keeping - (Walkways Clean and Clear of Trip & Fall Hazards, Trash Not Overflowing, Exits Free of Obstruction)",
                            GroupName="Group1" },
                        new InspectionItem { InspectionText ="Electrical Units - (Cables, Outlets, Appliances Working, In Good Codition, and Not Overloaded)",
                            GroupName = "Group2"},
                        new InspectionItem { InspectionText ="Lighting - (Good Visibility and In Working Order)", GroupName="Group3" },
                        new InspectionItem { InspectionText ="Fire Extinguishers - (In Date & Changed)", GroupName="Group4" },
                        new InspectionItem { InspectionText ="Structure - (No Structural Damage)", GroupName="Group5" }
                    };
                case "Shop":
                    return new List<InspectionItem>
                    {
                        new InspectionItem { InspectionText ="Lights - (Bulbs All Present and Working)",GroupName="Group1" },
                        new InspectionItem { InspectionText ="Electric - (Breaker Box Labeled, Accessible)", GroupName = "Group2"},
                        new InspectionItem { InspectionText ="Fire Extinguishers - (In Date & Changed)", GroupName="Group3" },
                        new InspectionItem { InspectionText ="Floors - (Clean & Free of Debris)", GroupName="Group4" },
                        new InspectionItem { InspectionText ="Shelves - (Clean & Accessible)", GroupName="Group5" },
                        new InspectionItem { InspectionText ="Flammable Liquids - (In Marked Cabinet, Sign Posted)", GroupName="Group6" },
                        new InspectionItem { InspectionText ="Signs - (No Smoking, Flammable, No Open Flame)", GroupName="Group7" },
                        new InspectionItem { InspectionText ="Oxygen / Acetylene - (Secure, Clean, Has Caps, Guages & Hoses in Proper Location)", GroupName="Group8" }
                    };
                case "Loading Yard":
                    return new List<InspectionItem>
                    {
                        new InspectionItem { InspectionText ="Rip Rap - (Bermed, Blocked, Ramp or Undercut, Contaminated)", GroupName="Group1" },
                        new InspectionItem { InspectionText ="#3's - (Bermed, Blocked, Ramp or Undercut, Contaminated)", GroupName = "Group2"},
                        new InspectionItem { InspectionText ="#4's - (Bermed, Blocked, Ramp or Undercut, Contaminated)", GroupName="Group3" },
                        new InspectionItem { InspectionText ="DGA - (Bermed, Blocked, Ramp or Undercut, Contaminated)", GroupName="Group4" },
                        new InspectionItem { InspectionText ="#57's - (Bermed, Blocked, Ramp or Undercut, Contaminated)", GroupName="Group5" },
                        new InspectionItem { InspectionText ="#9's - (Bermed, Blocked, Ramp or Undercut, Contaminated)", GroupName="Group6" },
                        new InspectionItem { InspectionText ="Class 1 - (Bermed, Blocked, Ramp or Undercut, Contaminated)", GroupName="Group7" },
                        new InspectionItem { InspectionText ="Lime - (Bermed, Blocked, Ramp or Undercut, Contaminated)", GroupName="Group8" },
                        new InspectionItem { InspectionText ="Berms - (At Least Mid Axel Height & In Place)", GroupName="Group9" },
                        new InspectionItem { InspectionText ="Scale - (Clean and Easy Access, No Trip Hazards)", GroupName="Group10" },
                        new InspectionItem { InspectionText ="Yard Roads - (No Pot Holes, Smooth)", GroupName="Group11" },
                        new InspectionItem { InspectionText ="Clean Off Rack - (Clean Deck, Signs Posted Clean Access)", GroupName="Group12"},
                        new InspectionItem { InspectionText ="Traffic Control Signs - (Speed Limit, Hard Hats, No On Out of Cab On Yard)", GroupName="Group13" },
                        new InspectionItem { InspectionText ="Equipment Parking - (No Mud, Bermed)", GroupName="Group14" },
                        new InspectionItem { InspectionText ="Dumpster - (Easy Access, No Debris Outside Dumpster)", GroupName="Group15" }
                    };
                case "Railroad":
                    return new List<InspectionItem>
                    {

                    };
                case "Pit":
                    return new List<InspectionItem>
                    {
                        new InspectionItem { InspectionText ="Berms - (Adequate Height & Secure)", GroupName="Group1"},
                        new InspectionItem { InspectionText ="High Walls - (Bermed Off & Free of Loose Debris)", GroupName="Group2"},
                        new InspectionItem { InspectionText ="Berms - (Clean & Visible)", GroupName="Group3"}
                    };
                default:
                    return new List<InspectionItem>();
            }
        }
    }
}
