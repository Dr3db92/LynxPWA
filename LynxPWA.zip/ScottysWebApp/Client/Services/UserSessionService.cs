﻿using ScottysWebApp.Client.Models.Users;


namespace ScottysWebApp.Client.Services
{
    public class UserSessionService
    {
        private static List<UserSession> activeUsers = new List<UserSession>();

        public void UpdateUserActivity(string userId, string userName)
        {
            var user = activeUsers.FirstOrDefault(u => u.UserID == userId);
            if (user != null)
            {
                user.LastActiveTime = DateTime.Now;
                user.IsActive = true;
            }
            else
            {
                activeUsers.Add(new UserSession
                {
                    UserID = userId,
                    UserName = userName,
                    LastActiveTime = DateTime.Now,
                    IsActive = true
                });
            }
        }

        public List<UserSession> GetActiveUsers()
        {
            var activeUsersList = activeUsers
                .Where(u => u.IsActive && u.LastActiveTime > DateTime.Now.AddMinutes(-5)) 
                .ToList();

            if (!activeUsersList.Any())
            {
                // Log or handle an empty user list if needed
            }

            return activeUsersList;
        }
    }
}
