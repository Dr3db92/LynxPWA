﻿using ScottysWebApp.Client.Models.Forms;

namespace ScottysWebApp.Client.Services
{
    //Service class to handle the checklist functionality
    public class ChecklistService
    {
        //Property to store a list of component items
        public List<ComponentItem> ComponentItems { get; private set; }

        //Constructor to initialize the checklist service
        public ChecklistService()
        {
            //Initialize the list with predefined component items
            ComponentItems = new List<ComponentItem>
            {
                new ComponentItem { ComponentText = "Windshield (No Cracks)", GroupName = "Group1" },
                new ComponentItem { ComponentText = "Windshield Wiper (Working Properly)", GroupName = "Group2" },
                new ComponentItem { ComponentText = "Rearview Mirror", GroupName = "Group3" },
                new ComponentItem { ComponentText = "Horn (Working Properly)", GroupName = "Group4" },
                new ComponentItem { ComponentText = "Backup Alarm (Working Properly)", GroupName = "Group5" },
                new ComponentItem { ComponentText = "Door(s) (Open, Close, Secure Properly)", GroupName = "Group6" },
                new ComponentItem { ComponentText = "Covers/ Guards (In Place)", GroupName = "Group7" },
                new ComponentItem { ComponentText = "Access Ladder (Good Condition)", GroupName = "Group8" },
                new ComponentItem { ComponentText = "Service Brake (Working Properly)", GroupName = "Group9" },
                new ComponentItem { ComponentText = "Parking Brake (Working Properly)", GroupName = "Group10" },
                new ComponentItem { ComponentText = "Seat Belt (Good Condition)", GroupName = "Group11" },
                new ComponentItem { ComponentText = "Fire Extinguisher (Serviceable)", GroupName = "Group12" },
                new ComponentItem { ComponentText = "Cab Interior (Clean)", GroupName = "Group13" },
                new ComponentItem { ComponentText = "Steering (Working Properly)", GroupName = "Group14" },
                new ComponentItem { ComponentText = "Auxillary Steering (If Equipped)", GroupName = "Group15" },
                new ComponentItem { ComponentText = "Lights (All Working Properly)", GroupName = "Group16" },
                new ComponentItem { ComponentText = "Two-Way Radio/ CB (If Equipped)", GroupName = "Group17" },
                new ComponentItem { ComponentText = "Tire Condition", GroupName = "Group18" },
                new ComponentItem { ComponentText = "Tracks Condition", GroupName = "Group19" },
                new ComponentItem { ComponentText = "Retarder", GroupName = "Group20" },
                new ComponentItem { ComponentText = "All Original Equipment In Place", GroupName = "Group21" },
                new ComponentItem { ComponentText = "Leaks (Oil, Water, Air)", GroupName = "Group22" },
                new ComponentItem { ComponentText = "Suspension System", GroupName = "Group23" },
                new ComponentItem { ComponentText = "Drive Shaft/ U Joints", GroupName = "Group24" },
                new ComponentItem { ComponentText = "Fan Belts", GroupName = "Group25" },
                new ComponentItem { ComponentText = "Cab Protector", GroupName = "Group26" },
                new ComponentItem { ComponentText = "Bed/ Frame/ Bucket/ G.E.T.", GroupName = "Group27" },
                new ComponentItem { ComponentText = "Low Air Warning Device", GroupName = "Group28" },
                new ComponentItem { ComponentText = "Instruments On Dash Panel", GroupName = "Group29" },
                new ComponentItem { ComponentText = "Engine Performance", GroupName = "Group30" },
                new ComponentItem { ComponentText = "Water Cannon", GroupName = "Group31" },
            };

            //Enable the first item in the list
            if (ComponentItems.Any())
            {
                ComponentItems.First().IsEnabled = true;
            }
        }

        //Update the status of a checklist item
        public void UpdateItemStatus(string groupName, string status, string comment = "")
        {
            var currentIndex = ComponentItems.FindIndex(i => i.GroupName == groupName);
            if (currentIndex != -1)
            {
                var item = ComponentItems[currentIndex];
                item.Status = status;

                //If the status is "INOP", check if a comment is required
                if (status == "INOP")
                {
                    item.IsCommentRequired = true;
                    item.Comment = comment;

                    //Enable the next item only if a valid comment is provided
                    if (!string.IsNullOrWhiteSpace(comment))
                    {
                        EnableNextItem(currentIndex);
                    }
                }
                else
                {
                    item.IsCommentRequired = false;
                    item.Comment = comment;
                    EnableNextItem(currentIndex);
                }
            }
        }

        //Update the comment of a checklist item
        public void UpdateItemComment(string groupName, string comment)
        {
            var item = ComponentItems.FirstOrDefault(i => i.GroupName == groupName);
            if(item != null && item.Status == "INOP")
            {
                item.Comment = comment.Trim();
                item.IsCommentRequired = string.IsNullOrWhiteSpace(comment);

                if(!item.IsCommentRequired)
                {
                    var currentIndex = ComponentItems.FindIndex(i => i.GroupName == groupName);
                    EnableNextItem(currentIndex);
                }
            }
        }

        //Enable the next item in the checklist
        private void EnableNextItem(int currentIndex)
        {
            // Disable the current item
            ComponentItems[currentIndex].IsEnabled = false;

            // Enable the next item in the list, if there is one
            if (currentIndex + 1 < ComponentItems.Count)
            {
                ComponentItems[currentIndex + 1].IsEnabled = true;
            }
        }

    }
}