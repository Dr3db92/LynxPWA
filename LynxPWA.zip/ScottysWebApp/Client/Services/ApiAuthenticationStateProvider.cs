﻿using Microsoft.AspNetCore.Components.Authorization;
using ScottysWebApp.Client.Models.Users;
using System.Net.Http.Json;
using System.Security.Claims;

namespace ScottysWebApp.Client.Services
{
    // ApiAuthenticationStateProvider class to manage the authentication state
    public class ApiAuthenticationStateProvider : AuthenticationStateProvider
    {
        private readonly HttpClient _httpClient;
        private readonly ILogger<ApiAuthenticationStateProvider> _logger;
        private UserInfo _userInfo;

        // Constructor to initialize the HTTP client and logger
        public ApiAuthenticationStateProvider(HttpClient httpClient, ILogger<ApiAuthenticationStateProvider> logger)
        {
            _httpClient = httpClient;
            _logger = logger;
            _userInfo = new UserInfo();
        }

        // Override method to get the authentication state asynchronously
        public override async Task<AuthenticationState> GetAuthenticationStateAsync()
        {
            _logger.LogInformation("Getting the authentication state.");
            try
            {
                // Make a call to the API to get the user info
                var userInfo = await _httpClient.GetFromJsonAsync<UserInfo>("api/account/userinfo");

                // Check if the user is authenticated
                if (userInfo?.IsAuthenticated == true)
                {
                    // Create claims based on the user info
                    var identity = new ClaimsIdentity(new[]
                    {
                        new Claim(ClaimTypes.Name, userInfo.UserName),
                        new Claim(ClaimTypes.Email, userInfo.Email),
                        new Claim(ClaimTypes.Role, userInfo.Role ?? "Guest")
                    }, "apiauth");

                    // Create a ClaimsPrincipal with the identity and authenticated state
                    var user = new ClaimsPrincipal(identity);

                    // Notify state changed after successful authentication
                    NotifyAuthenticationStateChanged(Task.FromResult(new AuthenticationState(user)));

                    return new AuthenticationState(user);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error in getting user info: {ex.Message}");
            }

            // Return an anonymous user by default
            return new AuthenticationState(new ClaimsPrincipal(new ClaimsIdentity()));
        }

        // Ensure user is logged out
        public void MarkUserAsLoggedOut()
        {
            _logger.LogInformation("Marking user as logged out.");
            var anonymousUser = new ClaimsPrincipal(new ClaimsIdentity());
            NotifyAuthenticationStateChanged(Task.FromResult(new AuthenticationState(anonymousUser)));
        }
    }
}
