﻿using Microsoft.AspNetCore.SignalR.Client;

namespace ScottysWebApp.Client.Services
{
    public class UserStatusService
    {
        private HubConnection _hubConnection;
        public event Action<string, string, bool> UserStatusChanged;
        public event Action<List<string>> ActiveUsersReceived;

        public async Task StartConnectionAsync(string baseUrl)
        {
            _hubConnection = new HubConnectionBuilder()
                .WithUrl(baseUrl + "/userStatusHub")
                .Build();

            _hubConnection.On<string, string, bool>("ReceiveUserStatus", (userId, userEmail, isOnline) =>
            {
                Console.WriteLine($"User status changed: {userEmail} (ID: {userId}) - Online: {isOnline}");
                UserStatusChanged?.Invoke(userId, userEmail, isOnline);
            });

            _hubConnection.On<List<string>>("ReceiveActiveUsers", (activeUserIds) =>
            {
                Console.WriteLine($"Active users received: {string.Join(", ", activeUserIds)}");
                ActiveUsersReceived?.Invoke(activeUserIds);
            });

            await _hubConnection.StartAsync();
            Console.WriteLine("SignalR connection started.");
        }

        public async Task GetActiveUsers()
        {
            await _hubConnection.SendAsync("GetActiveUsers");
        }

        public async Task StopConnectionAsync()
        {
            if (_hubConnection != null)
            {
                await _hubConnection.StopAsync();
                await _hubConnection.DisposeAsync();
            }
        }
    }
}