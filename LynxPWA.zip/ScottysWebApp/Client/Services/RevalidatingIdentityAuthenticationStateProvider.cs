﻿using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.AspNetCore.Identity;
using System.Security.Claims;

namespace ScottysWebApp.Client.Services
{
    //Responsible for revalidating the identity of the authenticated user at regular intervals.
    public class RevalidatingIdentityAuthenticationStateProvider<TUser> : AuthenticationStateProvider, IDisposable where TUser : IdentityUser
    {
        private readonly UserManager<TUser> _userManager;
        private readonly SignInManager<TUser> _signInManager;
        //Interval for revalidating the user's identity
        private readonly TimeSpan _revalidationInterval = TimeSpan.FromMinutes(30);
        private Timer _timer;

        //Initialize user manager, sign in manager, and timer for revalidation
        public RevalidatingIdentityAuthenticationStateProvider(UserManager<TUser> userManager, SignInManager<TUser> signInManager)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            //Set the timer to call the Callback method at the specified interval.
            _timer = new Timer(Callback, null, _revalidationInterval, _revalidationInterval);
        }

        //Runs at each interval to revalidate the user's identity
        private async void Callback(object state)
        {
            //Checks if the user is authenticated
            var claimsPrincipal = _signInManager.Context.User;

            if (claimsPrincipal.Identity.IsAuthenticated)
            {
                var identityUser = await _userManager.GetUserAsync(claimsPrincipal);
                if (identityUser != null)
                {
                    //Get the security stamp from the claims
                    var securityStampInClaims = claimsPrincipal.Claims.FirstOrDefault(c => c.Type == "AspNet.Identity.SecurityStamp")?.Value;

                    //If the security stamp in the claims does not match the user's security stamp, invalidate the user's authentication state
                    if (securityStampInClaims != identityUser.SecurityStamp)
                    {
                        var anonymous = new ClaimsPrincipal(new ClaimsIdentity());
                        NotifyAuthenticationStateChanged(Task.FromResult(new AuthenticationState(anonymous)));
                    }
                }
            }
        }

        //Get the current authentication state
        public override async Task<AuthenticationState> GetAuthenticationStateAsync()
        {
            var identity = new ClaimsIdentity();

            try
            {
                if (_signInManager.Context?.User?.Identity?.IsAuthenticated == true)
                {
                    var user = await _userManager.GetUserAsync(_signInManager.Context.User);
                    if (user != null)
                    {
                        var claims = new List<Claim>
                        {
                            new Claim(ClaimTypes.Name, user.UserName)
                        };

                        identity = new ClaimsIdentity(claims, "Identity.Application");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error retrieving user: {ex.Message}");
            }

            return new AuthenticationState(new ClaimsPrincipal(identity));
        }

        //Clean up the timer resource
        public void Dispose()
        {
            _timer?.Dispose();
        }
    }
}