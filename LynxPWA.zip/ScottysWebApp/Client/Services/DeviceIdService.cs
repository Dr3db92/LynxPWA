﻿using Microsoft.JSInterop;

namespace ScottysWebApp.Client.Services
{
    public class DeviceIdService
    {
        private readonly IJSRuntime _jsRuntime;
        private const string DeviceIdKey = "device-id";

        public DeviceIdService(IJSRuntime jsRuntime)
        {
            _jsRuntime = jsRuntime;
        }

        public async Task<string> GetOrCreateDeviceIdAsync()
        {
            //Try to get the device ID from local storage
            var deviceId = await _jsRuntime.InvokeAsync<string>("localStorage.getItem", DeviceIdKey);

            //If no device ID is found, generate a new one and store it in local storage
            if (string.IsNullOrEmpty(deviceId))
            {
                deviceId = Guid.NewGuid().ToString();
                await _jsRuntime.InvokeVoidAsync("localStorage.setItem", DeviceIdKey, deviceId);
            }

            return deviceId;
        }
    }
}
