﻿namespace ScottysWebApp.Client.FileHelpers
{
    public static class MimeTypeHelper
    {
        private static readonly Dictionary<string, string> MimeTypes = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
    {
        { ".pdf", "application/pdf" },
        { ".doc", "application/msword" },
        { ".xls", "application/vnd.ms-excel" },
        { ".ppt", "application/vnd.ms-powerpoint" },
        { ".jpg", "image/jpeg" },
        { ".jpeg", "image/jpeg" },
        { ".png", "image/png" },
        { ".gif", "image/gif" },
        { ".txt", "text/plain" },
        { ".html", "text/html" },
        { ".mov", "video/quicktime" },
        { ".mp4", "video/mp4" },
        { ".mp3", "audio/mpeg" },
    };

        public static string GetMimeType(string fileName)
        {
            var extension = Path.GetExtension(fileName);
            return MimeTypes.TryGetValue(extension, out var mimeType) ? mimeType : "application/octet-stream";
        }
    }
}
