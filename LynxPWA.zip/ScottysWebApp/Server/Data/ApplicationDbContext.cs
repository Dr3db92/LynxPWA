﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using ScottysWebApp.Client.Pages.Admin.Users;
using ScottysWebApp.Server.Models.App;
using ScottysWebApp.Server.Models.Equipment;
using ScottysWebApp.Server.Models.Forms;
using ScottysWebApp.Server.Models.PartModel;
using ScottysWebApp.Server.Models.Plant;
using ScottysWebApp.Server.Models.User;

namespace ScottysWebApp.Server.Data
{
    //ApplicationDbContext inherits from IdentityDbContext to include Identity management for users
    public class ApplicationDbContext : IdentityDbContext<IdentityUser>
    {
        //Constructor to pass DbContextOptions to the base class
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        //DbSet properties represent collections of the specified entities in the database
        public DbSet<SaveForms> SaveForms { get; set; }
        public DbSet<EquipmentInfo> Equipment { get; set; }
        public DbSet<EquipmentUser> EquipmentUsers { get; set; }
        public DbSet<EquipmentDocument> EquipmentDocuments { get; set; }
        public DbSet<Parts> Parts { get; set; }
        public DbSet<CompatibleModel> CompatibleModels { get; set; }
        public DbSet<ServiceOrderRecord> MaintenanceRecords { get; set; }
        public DbSet<RepairHistories> RepairHistories { get; set; }
        public DbSet<ServiceOrderRequest> MaintenanceRequests { get; set; }
        public DbSet<PasswordResetToken> PasswordResetTokens { get; set; }
        public DbSet<EquipmentCompatibleModel> EquipmentCompatibleModels { get; set; }
        public DbSet<TrainingCertifications> TrainingCertifications { get; set; }
        public DbSet<LogEntry> LogEntries { get; set; }
        public DbSet<SelectedPart> SelectedPart { get; set; }
        public DbSet<Plants> Plants { get; set; }
        public DbSet<WorkOrderRequest> WorkOrderRequests { get; set; }
        public DbSet<WorkOrderRecord> WorkOrderRecords { get; set; }
        public DbSet<WorkOrderPart> WorkOrderParts { get; set; }
        public DbSet<PreOpChecklistSubmission> PreOpChecklistSubmissions { get; set; }
        public DbSet<PreOpChecklistComponent> PreOpChecklistComponents { get; set; }
        public DbSet<WorkplaceExamChecklistSubmission> WorkplaceExamChecklistSubmissions { get; set; }
        public DbSet<WorkplaceExamChecklistItem> WorkplaceExamChecklistItems { get; set; }
        public DbSet<WorkOrderSelectedPart> WorkOrderSelectedPart { get; set; }
        public DbSet<AreasWorkingSubmission> AreasWorkingSubmission { get; set; }
        public DbSet<AreasWorkingDeficiency> AreasWorkingDeficiency { get; set; }
        public DbSet<AreasWorkingRequest> AreasWorkingRequest { get; set; }

        public async Task<int> DeleteWorkOrderAndRelatedRecordsAsync(int requestId)
        {
            // Execute the stored procedure, which is abstracted within the context
            return await this.Database.ExecuteSqlRawAsync("EXEC DeleteWorkOrderAndRecords @RequestID = {0}", requestId);
        }


        //Configures the entity model relationships and additional constraints
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            //Configure composite key for EquipmentUser entity
            modelBuilder.Entity<EquipmentUser>()
                .HasKey(eu => new { eu.EquipmentID, eu.UserID });

            //Define relationship between EquipmentUser and Equipment entities
            modelBuilder.Entity<EquipmentUser>()
                .HasOne(eu => eu.Equipment)
                .WithMany(e => e.EquipmentUsers)
                .HasForeignKey(eu => eu.EquipmentID);

            //Define relationship between EquipmentUser and IdentityUser entities
            modelBuilder.Entity<EquipmentUser>()
                .HasOne(eu => eu.User)
                .WithMany()
                .HasForeignKey(eu => eu.UserID);

            //Define one-to-many relationship between Parts and CompatibleModels with cascade delete
            modelBuilder.Entity<Parts>()
                .HasMany(p => p.CompatibleModels)
                .WithOne(cm => cm.Part)
                .HasForeignKey(cm => cm.PartID)
                .OnDelete(DeleteBehavior.Cascade);

            //Specify precision for Cost property in Parts entity
            modelBuilder.Entity<Parts>()
                .Property(p => p.Cost)
                .HasColumnType("decimal(18, 2)");

            //Specify precision for Cost property in EquipmentInfo entity
            modelBuilder.Entity<EquipmentInfo>()
                .Property(e => e.Cost)
                .HasColumnType("decimal(18, 2)");

            //Configure primary key for CompatibleModel entity
            modelBuilder.Entity<CompatibleModel>()
                .HasKey(e => e.ModelID);

            //Define relationship between CompatibleModel and EquipmentCompatibleModels
            modelBuilder.Entity<CompatibleModel>()
                .HasMany(cm => cm.EquipmentCompatibleModels)
                .WithOne(ecm => ecm.CompatibleModel)
                .HasForeignKey(ecm => ecm.ModelID);

            //Define one-to-many relationship between CompatibleModel and Parts with cascade delete
            modelBuilder.Entity<CompatibleModel>()
                .HasOne(cm => cm.Part)
                .WithMany(p => p.CompatibleModels)
                .HasForeignKey(cm => cm.PartID)
                .OnDelete(DeleteBehavior.Cascade);

            //Define relationship between WorkOrderRecord and EquipmentInfo entities
            modelBuilder.Entity<ServiceOrderRecord>()
                .HasOne(m => m.Equipment)
                .WithMany(e => e.MaintenanceRecords)
                .HasForeignKey(m => m.EquipmentID);

            //Define relationship between RepairHistories and EquipmentInfo entities
            modelBuilder.Entity<RepairHistories>()
                .HasOne(r => r.Equipment)
                .WithMany(e => e.RepairHistories)
                .HasForeignKey(r => r.EquipmentID);

            //Define relationship between WorkOrderRequest and EquipmentInfo entities
            modelBuilder.Entity<ServiceOrderRequest>()
                .HasOne(m => m.Equipment)
                .WithMany(e => e.MaintenanceRequests)
                .HasForeignKey(m => m.EquipmentID);

            //Configure primary key for EquipmentDocument entity
            modelBuilder.Entity<EquipmentDocument>()
                .HasKey(e => e.DocumentId);

            //Define relationship between EquipmentDocument and EquipmentInfo entities with cascade delete
            modelBuilder.Entity<EquipmentDocument>()
                .HasOne(e => e.Equipment)
                .WithMany(e => e.EquipmentDocuments)
                .HasForeignKey(e => e.EquipmentId)
                .OnDelete(DeleteBehavior.Cascade);

            //Configure primary key for EquipmentCompatibleModel entity
            modelBuilder.Entity<EquipmentCompatibleModel>()
                .HasKey(ecm => ecm.Id);

            //Specify auto-increment for Id property in EquipmentCompatibleModel entity
            modelBuilder.Entity<EquipmentCompatibleModel>()
                .Property(ecm => ecm.Id)
                .ValueGeneratedOnAdd();

            //Define relationship between EquipmentCompatibleModel and EquipmentInfo entities
            modelBuilder.Entity<EquipmentCompatibleModel>()
                .HasOne(ecm => ecm.Equipment)
                .WithMany(e => e.EquipmentCompatibleModels)
                .HasForeignKey(ecm => ecm.EquipmentID);

            //Define relationship between EquipmentCompatibleModel and CompatibleModel entities
            modelBuilder.Entity<EquipmentCompatibleModel>()
                .HasOne(ecm => ecm.CompatibleModel)
                .WithMany(cm => cm.EquipmentCompatibleModels)
                .HasForeignKey(ecm => ecm.ModelID)
                .OnDelete(DeleteBehavior.Cascade);

            //Define relationship between EquipmentCompatibleModel and WorkOrderRecord entities
            modelBuilder.Entity<EquipmentCompatibleModel>()
                .HasOne(ecm => ecm.MaintenanceRecord)
                .WithMany(mr => mr.EquipmentCompatibleModels)
                .HasForeignKey(ecm => ecm.Id);

            //Configure primary key for TrainingCertifications entity
            modelBuilder.Entity<TrainingCertifications>()
                .HasKey(tc => tc.TrainingID);

            //Define relationship between TrainingCertifications and IdentityUser entities
            modelBuilder.Entity<TrainingCertifications>()
                .HasOne<IdentityUser>()
                .WithMany()
                .HasForeignKey(tc => tc.UserID);

            //Define relationship between TrainingCertifications and CompatibleModel entities
            modelBuilder.Entity<TrainingCertifications>()
                .HasOne(tc => tc.CompatibleModel)
                .WithMany(cm => cm.TrainingCertifications)
                .HasForeignKey(tc => tc.EquipmentModelID)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<LogEntry>()
                .HasKey(le => le.Id);

            modelBuilder.Entity<ServiceOrderRequest>()
                .HasMany(r => r.SelectedPart)
                .WithOne(p => p.ServiceOrderRequest)
                .HasForeignKey(p => p.RequestID);

            modelBuilder.Entity<ServiceOrderRequest>()
                .Property(s => s.MechanicHours)
                .HasPrecision(10, 2)
                .IsRequired(false);

            modelBuilder.Entity<RepairHistories>()
                .Property(r => r.MechanicHours)
                .HasColumnType("decimal(18,2)");

            modelBuilder.Entity<Plants>(entity =>
            {
                entity.ToTable("Plant"); // Make sure it's mapping to the correct table name

                entity.HasKey(p => p.PlantID);

                // Define required fields
                entity.Property(p => p.PlantName).IsRequired();
                entity.Property(p => p.StreetAddress).IsRequired();
                entity.Property(p => p.City).IsRequired();
                entity.Property(p => p.State).IsRequired();
                entity.Property(p => p.Zip).IsRequired();

                entity.HasMany(p => p.Parts)
                      .WithOne()
                      .HasForeignKey(part => part.PlantID)
                      .OnDelete(DeleteBehavior.Restrict);
            });

            modelBuilder.Entity<Parts>()
                .HasOne(p => p.Plant)
                .WithMany(pl => pl.Parts)
                .HasForeignKey(p => p.PlantID)
                .OnDelete(DeleteBehavior.SetNull);

            modelBuilder.Entity<WorkOrderRequest>(entity =>
            {
                entity.HasKey(e => e.RequestID);
                entity.HasOne(e => e.Plant)
                      .WithMany(p => p.WorkOrderRequests)  // Correct server-side WorkOrderRequest type
                      .HasForeignKey(e => e.PlantID)
                      .OnDelete(DeleteBehavior.SetNull);
            });

            modelBuilder.Entity<WorkOrderRequest>()
                .Property(w => w.MechanicHours)
                .HasColumnType("decimal(18,2)");

            modelBuilder.Entity<WorkOrderRequest>()
                .HasOne(wo => wo.Equipment)
                .WithMany(e => e.WorkOrderRequests)  // Ensure it's using the server-side model
                .HasForeignKey(wo => wo.EquipmentID);

            modelBuilder.Entity<WorkOrderRequest>()
                .HasMany(wo => wo.SelectedPart)
                .WithOne(sp => sp.WorkOrderRequest)
                .HasForeignKey(sp => sp.RequestID)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<WorkOrderRecord>()
                .HasKey(wr => wr.RecordID); // Set primary key

            modelBuilder.Entity<WorkOrderRecord>()
                .HasOne(wr => wr.Plant)  // Relationship with Plant
                .WithMany(pl => pl.WorkOrderRecords)
                .HasForeignKey(wr => wr.PlantID);

            modelBuilder.Entity<WorkOrderRecord>()
                .HasMany(wr => wr.WorkOrderRecordParts)  // Relationship with WorkOrderRecordParts
                .WithOne(wrp => wrp.WorkOrderRecord)
                .HasForeignKey(wrp => wrp.RecordID);

            // Configure WorkOrderRecordPart relationships
            modelBuilder.Entity<WorkOrderPart>()
                .HasKey(wrp => wrp.RecordPartID);  // Set primary key

            modelBuilder.Entity<WorkOrderPart>()
                .HasOne(wrp => wrp.WorkOrderRecord)
                .WithMany(wr => wr.WorkOrderRecordParts)
                .HasForeignKey(wrp => wrp.RecordID);

            // Configure relationships between WorkOrderRequest and other tables (if not done already)
            modelBuilder.Entity<WorkOrderRequest>()
                .HasMany(wo => wo.SelectedPart)
                .WithOne(sp => sp.WorkOrderRequest)
                .HasForeignKey(sp => sp.RequestID);

            modelBuilder.Entity<SelectedPart>()
                .HasOne(sp => sp.WorkOrderRequest)
                .WithMany(w => w.SelectedPart)
                .HasForeignKey(sp => sp.RequestID)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<SelectedPart>()
                .HasOne(sp => sp.RepairHistory)
                .WithMany(r => r.SelectedParts)
                .HasForeignKey(sp => sp.RepairID)
                .OnDelete(DeleteBehavior.SetNull);

            modelBuilder.Entity<SelectedPart>()
                .HasOne(sp => sp.ServiceOrderRequest)
                .WithMany(s => s.SelectedPart)
                .HasForeignKey(sp => sp.RequestID)
                .OnDelete(DeleteBehavior.SetNull);

            modelBuilder.Entity<WorkOrderRecord>()
                .HasMany(wr => wr.WorkOrderRecordParts)
                .WithOne(wrp => wrp.WorkOrderRecord)
                .HasForeignKey(wrp => wrp.RecordID)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<PreOpChecklistSubmission>()
                .HasMany(s => s.ComponentItems)
                .WithOne(c => c.Submission)
                .HasForeignKey(c => c.SubmissionId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<WorkOrderSelectedPart>()
                .HasOne(wosp => wosp.WorkOrderRequest)
                .WithMany(wor => wor.WorkOrderSelectedPart)
                .HasForeignKey(wosp => wosp.RequestID);

            modelBuilder.Entity<WorkOrderSelectedPart>()
                .HasOne(wosp => wosp.Part)
                .WithMany(p => p.WorkOrderSelectedPart)
                .HasForeignKey(wosp => wosp.PartID);

            modelBuilder.Entity<AreasWorkingDeficiency>()
                .HasOne(d => d.Submission)
                .WithMany(s => s.Deficiencies)
                .HasForeignKey(d => d.SubmissionId);

            modelBuilder.Entity<AreasWorkingRequest>()
                .HasKey(x => x.RequestID); 


        }
    }
}