﻿namespace ScottysWebApp.Server.Models.PartModel
{
    public class ReducePartQuantityRequest
    {
        public int PartID { get; set; }
        public int QuantityUsed { get; set; }
    }

}
