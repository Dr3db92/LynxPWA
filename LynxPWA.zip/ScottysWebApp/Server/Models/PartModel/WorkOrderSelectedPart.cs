﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using ScottysWebApp.Server.Models.Plant;

namespace ScottysWebApp.Server.Models.PartModel
{
    public class WorkOrderSelectedPart
    {
        [Key]
        public int WorkOrderSelectedPartID { get; set; }

        [ForeignKey("WorkOrderRequest")]
        public int RequestID { get; set; }
        public WorkOrderRequest WorkOrderRequest { get; set; }

        public int PartID { get; set; }
        public Parts Part { get; set; }

        [Required]
        [Range(0, int.MaxValue, ErrorMessage = "Quantity must be a non-negative number.")]
        public int QuantityUsed { get; set; }

        public DateTime DateAdded { get; set; } = DateTime.Now;
    }
}
