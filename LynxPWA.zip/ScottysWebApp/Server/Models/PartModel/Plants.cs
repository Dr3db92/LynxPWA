﻿using ScottysWebApp.Server.Models.Plant;
using System.ComponentModel.DataAnnotations;

namespace ScottysWebApp.Server.Models.PartModel
{
    public class Plants
    {
        [Key]
        public int PlantID { get; set; }

        // Plant Name
        public string PlantName { get; set; }

        // New Address Fields
        public string StreetAddress { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }

        public ICollection<Parts> Parts { get; set; } = new List<Parts>();
        public ICollection<WorkOrderRequest>? WorkOrderRequests { get; set; }
        public ICollection<WorkOrderRecord> WorkOrderRecords { get; set; } = new List<WorkOrderRecord>();
    }
}
