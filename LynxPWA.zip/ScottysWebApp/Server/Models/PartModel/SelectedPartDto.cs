﻿using ScottysWebApp.Server.Models.Equipment;

namespace ScottysWebApp.Server.Models.PartModel
{
    public class SelectedPartDto
    {
        public int PartID { get; set; }
        public string PartName { get; set; }
        public int QuantityUsed { get; set; }
        public int RequestID { get; set; }
        public Parts Part { get; set; } // Full Part object
        public ServiceOrderRequestDto ServiceOrderRequest { get; set; } // Reference to the request
    }
}
