﻿namespace ScottysWebApp.Server.Models.PartModel
{
    public class InventoryTotals
    {
        public int? TotalQuantity { get; set; }
        public decimal? TotalCost { get; set; }
        public List<string> OEMs { get; set; } = new List<string>();
    }
}
