﻿using ScottysWebApp.Server.Models.Equipment;

namespace ScottysWebApp.Server.Models.PartModel
{
    public class PartsDto
    {
        public int PartID { get; set; }
        public string PartName { get; set; }
        public string PartNumber { get; set; }
        public int Quantity { get; set; }
        public decimal? Cost { get; set; }
        public string Description { get; set; }
        public string OEM { get; set; }

        public string WebsiteLink { get; set; }    // New field

        public int? PlantID { get; set; }
        public string? PlantName { get; set; }
        public List<CompatibleModelDto>? CompatibleModels { get; set; } = new List<CompatibleModelDto>();
    }
}
