﻿namespace ScottysWebApp.Server.Models.PartModel
{
    public class PartsViewModel
    {
        public int PartID { get; set; }
        public string PartName { get; set; }
        public string PartNumber { get; set; }
        public int? Quantity { get; set; }
        public decimal? Cost { get; set; }
        public string Description { get; set; }
        public string OEM { get; set; }
        public bool IsSelected { get; set; }
        public string PlantName { get; set; }
        public string WebsiteLink { get; set; }
    }
}
