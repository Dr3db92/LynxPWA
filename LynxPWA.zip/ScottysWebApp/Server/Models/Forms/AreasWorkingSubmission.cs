﻿namespace ScottysWebApp.Server.Models.Forms
{
    public class AreasWorkingSubmission
    {
        public int Id { get; set; }
        public string OperatorName { get; set; } = string.Empty;
        public string AreasWorking { get; set; } = string.Empty;
        public bool NoDeficienciesFound { get; set; }
        public byte[]? OperatorSignature { get; set; }
        public DateTime Date { get; set; }
        public List<AreasWorkingDeficiency> Deficiencies { get; set; } = new(); 
    }
}
