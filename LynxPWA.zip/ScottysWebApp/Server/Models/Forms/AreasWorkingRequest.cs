﻿namespace ScottysWebApp.Server.Models.Forms
{
    public class AreasWorkingRequest
    {
        public int SubmissionId { get; set; }
        public int RequestID { get; set; }
        public string OperatorName { get; set; }
        public string AreasWorking { get; set; }
        public byte[] OperatorSignature { get; set; }
        public DateTime Date { get; set; }
        public string DeficienciesFound { get; set; }
        public DateTime? DateCorrected { get; set; }
        public string Comments { get; set; }
        public byte[] MaintenanceSignature { get; set; }
        public DateTime? MaintenanceDate { get; set; }
        public string? UpdatedComments { get; set; }
        public bool IsProcessed { get; set; }
    }
}
