﻿namespace ScottysWebApp.Server.Models.Forms
{
    public class DeficiencyViewModel
    {
        public string DeficienciesFound { get; set; }
        public DateTime? DateCorrected { get; set; }
        public string Comments { get; set; }
    }
}
