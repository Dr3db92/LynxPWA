﻿namespace ScottysWebApp.Server.Models.Forms
{
    public class AreasWorkingDeficiency
    {
        public int Id { get; set; }
        public int SubmissionId { get; set; }
        public string DeficienciesFound { get; set; } = string.Empty;
        public DateTime DateCorrected { get; set; }
        public string Comments { get; set; } = string.Empty;

        public AreasWorkingSubmission Submission { get; set; } // Navigation property
    }
}
