﻿using ScottysWebApp.Server.Models.PartModel;

namespace ScottysWebApp.Server.Models.Forms
{
    public class WorkplaceChecklistDTO
    {
        public string? OperatorName { get; set; }
        public int? PlantID { get; set; }
        public string? InspectionArea { get; set; }
        public List<InspectionItemDTO> InspectionItems { get; set; } = new List<InspectionItemDTO>();
        public string? Comments { get; set; }
        public byte[]? OperatorSignature { get; set; }
        public DateTime Date { get; set; }

        public Plants? Plant { get; set; }
    }
}
