﻿using System.ComponentModel.DataAnnotations;

namespace ScottysWebApp.Server.Models.Forms
{
    public class PreOpChecklistSubmission
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string OperatorName { get; set; }

        [Required]
        public string Equipment { get; set; }

        public int Start { get; set; }

        public int Stop { get; set; }

        public string Comments { get; set; }

        [Required]
        public byte[]? OperatorSignature { get; set; }

        [Required]
        public DateTime ChecklistDate { get; set; }

        public string DocumentType { get; set; } = "PreOpChecklist";

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        // Navigation property for related components
        public ICollection<PreOpChecklistComponent> ComponentItems { get; set; }
    }
}
