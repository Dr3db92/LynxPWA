﻿using System.ComponentModel.DataAnnotations;

namespace ScottysWebApp.Server.Models.Forms
{
    public class PreOpChecklistDTO
    {
        [Required]
        public string? OperatorName { get; set; }
        [Required]
        public string? Equipment { get; set; }
        [Required]
        public int? Start { get; set; }
        [Required]
        public int? Stop { get; set; }
        public List<ComponentItem> ComponentItems { get; set; } = new List<ComponentItem>();
        public string? Comments { get; set; }
        [Required]
        public byte[]? OperatorSignature { get; set; }
        [Required]
        public DateTime Date { get; set; }
        public string DocumentType { get; set; }
    }
}
