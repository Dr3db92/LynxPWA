﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace ScottysWebApp.Server.Models.Forms
{
    public class PreOpChecklistComponent
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int SubmissionId { get; set; }

        [ForeignKey("SubmissionId")]
        public PreOpChecklistSubmission Submission { get; set; }

        [Required]
        public string ComponentText { get; set; }

        [Required]
        public string Status { get; set; }

        public string Comment { get; set; }
    }
}
