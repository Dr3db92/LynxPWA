﻿using System.ComponentModel.DataAnnotations;

namespace ScottysWebApp.Server.Models.Forms
{
    public class ChecklistSubmission
    {
        [Required(ErrorMessage = "DocumentType is required")]
        [MinLength(1, ErrorMessage = "DocumentType cannot be empty")]
        public string DocumentType { get; set; }

        [Required(ErrorMessage = "DocumentType is required")]
        [MinLength(1, ErrorMessage = "DocumentType cannot be empty")]
        public string Data { get; set; }
    }
}
