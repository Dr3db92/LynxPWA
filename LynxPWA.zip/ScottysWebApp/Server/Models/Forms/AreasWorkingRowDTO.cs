﻿namespace ScottysWebApp.Server.Models.Forms
{
    public class AreasWorkingRowDTO
    {
        public string ? DeficienciesFound { get; set; }
        public string ? Comments { get; set; }
        public DateTime DateCorrected { get; set; }
    }
}
