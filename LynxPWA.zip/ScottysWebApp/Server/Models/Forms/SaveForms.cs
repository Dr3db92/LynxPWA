﻿namespace ScottysWebApp.Server.Models.Forms
{
    public class SaveForms
    {
        public int Id { get; set; }
        public string DocumentType { get; set; }
        public string FormData { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}
