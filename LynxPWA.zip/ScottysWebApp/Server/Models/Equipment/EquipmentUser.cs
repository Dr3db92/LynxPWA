﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations.Schema;

namespace ScottysWebApp.Server.Models.Equipment
{
    public class EquipmentUser
    {
        public int EquipmentID { get; set; }
        public EquipmentInfo Equipment { get; set; }

        [ForeignKey("User")]
        public string UserID { get; set; }
        public IdentityUser User { get; set; }
    }
}
