﻿namespace ScottysWebApp.Server.Models.Equipment
{
    public class DeleteFilesModel
    {
        public string ModelName { get; set; }
    }
}
