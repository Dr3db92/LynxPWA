﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace ScottysWebApp.Server.Models.Equipment
{
    public class EquipmentCompatibleModel
    {
        [Key]
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("equipmentID")]
        public int EquipmentID { get; set; }

        [JsonPropertyName("modelID")]
        public int ModelID { get; set; }

        [JsonPropertyName("equipment")]
        public EquipmentInfo? Equipment { get; set; }

        [JsonPropertyName("compatibleModel")]
        public CompatibleModel? CompatibleModel { get; set; }

        [JsonPropertyName("maintenanceRecord")]
        public ServiceOrderRecord? MaintenanceRecord { get; set; }
    }
}
