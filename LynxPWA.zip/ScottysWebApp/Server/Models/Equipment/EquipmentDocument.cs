﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ScottysWebApp.Server.Models.Equipment
{
    public class EquipmentDocument
    {
        [Key]
        public int DocumentId { get; set; }
        public int EquipmentId { get; set; }
        public string FileName { get; set; }
        public string ContentType { get; set; }
        public byte[] Data { get; set; }
        public DateTime UploadedAt { get; set; }
        public string? Keywords { get; set; }
        [ForeignKey("EquipmentId")]
        public EquipmentInfo Equipment { get; set; }
        public string DataUrl => $"api/equipment-documents/download/{DocumentId}";
    }
}
