﻿using ScottysWebApp.Server.Models.Forms;

namespace ScottysWebApp.Server.Models.Equipment
{
    public class SelectedFilesModel
    {
        public List<FileModel> Files { get; set; } = new List<FileModel>();

        public List<int> SelectedFileIds => Files.Where(f => f.IsSelected).Select(f => f.DocumentId).ToList();
    }
}
