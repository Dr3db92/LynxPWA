﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using ScottysWebApp.Server.Models.PartModel;

namespace ScottysWebApp.Server.Models.Equipment
{
    [Table("MaintenanceRequests")]
    public class ServiceOrderRequest
    {
        [Key]
        public int RequestID { get; set; }

        public int EquipmentID { get; set; }
        public string OperatorName { get; set; }
        public string DeficienciesIssues { get; set; }
        public string WhereOccurred { get; set; }
        public DateTime? WhenOccurred { get; set; } = DateTime.Now;
        public byte[]? OperatorSignature { get; set; }
        public DateTime? OperatorDate { get; set; } = DateTime.Now;
        public string Corrections { get; set; }
        public byte[]? MaintenanceSignature { get; set; }
        public DateTime? CorrectionStartDate { get; set; }
        public DateTime? CorrectionDate { get; set; }
        public string Status { get; set; }

        public string Priority { get; set; } // High, Medium, Low
        public decimal? MechanicHours { get; set; }

        [ForeignKey(nameof(EquipmentID))]
        public EquipmentInfo Equipment { get; set; }
        public List<SelectedPart> SelectedPart { get; set; } = new List<SelectedPart>();
    }
}
