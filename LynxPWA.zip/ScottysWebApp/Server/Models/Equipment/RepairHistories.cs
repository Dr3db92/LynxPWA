﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using ScottysWebApp.Server.Models.PartModel;

namespace ScottysWebApp.Server.Models.Equipment
{
    public class RepairHistories
    {
        [Key]
        public int RepairID { get; set; }

        public int EquipmentID { get; set; }
        public string? LocalEquipmentName { get; set; }
        public decimal? MechanicHours { get; set; }
        public string? PartsUsed { get; set; }
        public string? DeficienciesIssues { get; set; }
        public DateTime? WhenOccurred { get; set; }
        public string? OperatorName { get; set; }
        public byte[]? OperatorSignature { get; set; }
        public DateTime? OperatorDate { get; set; }
        public string? Corrections { get; set; }
        public byte[]? MaintenanceSignature { get; set; }
        public DateTime? CorrectionStartDate { get; set; }
        public DateTime? CorrectionDate { get; set; }
        public string? Status { get; set; }

        // Navigation property for SelectedParts
        public ICollection<SelectedPart> SelectedParts { get; set; } = new List<SelectedPart>();

        [ForeignKey(nameof(EquipmentID))]
        public EquipmentInfo Equipment { get; set; }
    }
}
