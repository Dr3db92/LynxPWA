﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ScottysWebApp.Server.Models.Equipment
{
    public class ServiceOrderRecord
    {
        [Key]
        public int MaintenanceID { get; set; }

        public int EquipmentID { get; set; }

        public DateTime StartDate { get; set; } = DateTime.Now;

        public DateTime ExpectedEndDate { get; set; } = DateTime.Now.AddDays(7);

        public DateTime? EndDate { get; set; }

        public string? Description { get; set; }

        public string? Status { get; set; }

        public string Reason { get; set; }

        [ForeignKey(nameof(EquipmentID))]
        public EquipmentInfo Equipment { get; set; }

        public ICollection<EquipmentCompatibleModel> EquipmentCompatibleModels { get; set; } = new List<EquipmentCompatibleModel>();
    }
}
