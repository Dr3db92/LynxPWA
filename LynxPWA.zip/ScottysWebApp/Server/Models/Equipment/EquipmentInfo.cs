﻿using ScottysWebApp.Server.Models.Plant;
using System.ComponentModel.DataAnnotations;

namespace ScottysWebApp.Server.Models.Equipment
{
    public class EquipmentInfo
    {
        [Key]
        public int EquipmentID { get; set; }
        public string? LocalEquipmentName { get; set; }
        public string? ModelNumber { get; set; }
        public string? SerialNumber { get; set; }
        public string? Manufacturer { get; set; }
        public string? Location { get; set; }
        public string? Description { get; set; }
        public DateTime? PurchaseDate { get; set; }
        public decimal? Cost { get; set; }
        public DateTime? WarrantyExpiration { get; set; } = DateTime.Today.AddYears(5);
        public string? Status { get; set; }
        public int? Miles { get; set; }

        public ICollection<EquipmentUser> EquipmentUsers { get; set; } = new List<EquipmentUser>();
        public ICollection<CompatibleModel> CompatibleModels { get; set; } = new List<CompatibleModel>();
        public ICollection<ServiceOrderRecord> MaintenanceRecords { get; set; } = new List<ServiceOrderRecord>();
        public ICollection<RepairHistories> RepairHistories { get; set; } = new List<RepairHistories>();
        public ICollection<ServiceOrderRequest> MaintenanceRequests { get; set; } = new List<ServiceOrderRequest>();
        public ICollection<WorkOrderRequest> WorkOrderRequests { get; set; } = new List<WorkOrderRequest>();
        public ICollection<EquipmentDocument> EquipmentDocuments { get; set; } = new List<EquipmentDocument>();
        public ICollection<EquipmentCompatibleModel> EquipmentCompatibleModels { get; set; }
    }
}
