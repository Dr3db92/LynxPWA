﻿namespace ScottysWebApp.Server.Models.Equipment
{
    public class UploadDocument
    {
        public int EquipmentId { get; set; }
        public string Keywords { get; set; }
        public string ModelName { get; set; }
    }
}
