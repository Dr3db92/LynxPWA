﻿using ScottysWebApp.Server.Models.PartModel;

namespace ScottysWebApp.Server.Models.Plant
{
    public class WorkOrderRecord
    {
        public int RecordID { get; set; }
        public int RequestID { get; set; }
        public string OperatorName { get; set; }
        public string Priority { get; set; }
        public string WhereOccurred { get; set; }
        public DateTime? WhenOccurred { get; set; }
        public string DeficienciesIssues { get; set; }
        public int? PlantID { get; set; }
        public string Comments { get; set; }
        public byte[]? OperatorSignature { get; set; }
        public DateTime Date { get; set; }
        public byte[] ImageData { get; set; }
        public string ImageFileName { get; set; }
        public string Status { get; set; }
        public DateTime? CorrectionStartDate { get; set; }
        public string Corrections { get; set; }
        public decimal? MechanicHours { get; set; }
        public byte[]? MaintenanceSignature { get; set; }
        public DateTime? CompletedDate { get; set; }

        public ICollection<WorkOrderPart> WorkOrderRecordParts { get; set; } = new List<WorkOrderPart>();
        public Plants? Plant { get; set; }
        public ICollection<SelectedPart> SelectedPart { get; set; } = new List<SelectedPart>();
    }
}
