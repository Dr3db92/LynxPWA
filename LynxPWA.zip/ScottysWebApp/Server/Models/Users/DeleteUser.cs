﻿using System.ComponentModel.DataAnnotations;

namespace ScottysWebApp.Server.Models.User
{
    public class DeleteUser
    {
        [Required]
        public string Username { get; set; }
    }
}
