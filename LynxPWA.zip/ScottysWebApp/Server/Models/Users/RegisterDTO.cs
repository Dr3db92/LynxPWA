﻿using System.ComponentModel.DataAnnotations;

namespace ScottysWebApp.Server.Models.User
{
    public class RegisterDTO
    {
        [Required(ErrorMessage = "Username is required")]
        [StringLength(256, ErrorMessage = "Username must be between 3 and 256 characters", MinimumLength = 3)]
        [RegularExpression(@"^[a-zA-Z ]+$", ErrorMessage = "Username contains invalid characters")]
        public string Username { get; set; }

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "A valid email is required")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Password is required")]
        [StringLength(30, ErrorMessage = "Password must be at least 8 characters long", MinimumLength = 8)]
        [Display(Name = "Password")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }

}
