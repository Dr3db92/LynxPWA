﻿using Microsoft.AspNetCore.Identity;
using ScottysWebApp.Server.Models.Equipment;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace ScottysWebApp.Server.Models.User
{
    public class TrainingCertifications
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int TrainingID { get; set; }

        [Required(ErrorMessage = "The User field is required.")]
        public string? UserID { get; set; }

        [Required(ErrorMessage = "The EquipmentModel field is required.")]
        public int EquipmentModelID { get; set; }

        // Additional fields
        [Required(ErrorMessage = "The CertificationDate field is required.")]
        public DateTime CertificationDate { get; set; } = DateTime.Today;
        public byte[]? FormData { get; set; }
        public DateTime? UploadedAt { get; set; }
        public CompatibleModel? CompatibleModel { get; set; }
    }
}
