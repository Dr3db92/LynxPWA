﻿using System.ComponentModel.DataAnnotations;

namespace ScottysWebApp.Server.Models.User
{
    public class UpdateUsersDTO
    {
        [Required]
        [RegularExpression("^[a-zA-Z0-9.-_@+ ]*$", ErrorMessage = "Only alphanumeric characters and decimals are allowed.")]
        public string UserName { get; set; }
        [Required]
        public string Email { get; set; }
        [Required]
        public string PhoneNumber { get; set; }
        [Required]
        public string Role { get; set; }
    }
}
