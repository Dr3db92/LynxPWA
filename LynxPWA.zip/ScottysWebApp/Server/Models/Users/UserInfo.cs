﻿namespace ScottysWebApp.Server.Models.User
{
    public class UserInfo
    {
        public string UserID { get; set; }
        public string UserName { get; set; }
        public string Email { get; set; }
        public bool IsAuthenticated { get; set; }
        public string Role { get; set; }
        public bool IsSelected { get; set; }
        public bool IsActive { get; set; }
    }
}
