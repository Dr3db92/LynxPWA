﻿namespace ScottysWebApp.Server.Models
{
    public class UserInteractionModel
    {
        public string UserName { get; set; }
        public DateTime LastActivity { get; set; }
    }
}