﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace ScottysWebApp.Server.Models.App
{
    public class ApplicationUser
    {
        [Key]
        public string EmployeeID { get; set; }
        public string Username { get; set; }
        public string PasswordHash { get; set; }
        public List<UserRole> UserRoles { get; set; }
    }

    public class Role
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Name { get; set; }
        public virtual List<UserRole> UserRoles { get; set; } = new List<UserRole>();
    }

    public class UserRole
    {
        public string EmployeeID { get; set; }
        public ApplicationUser User { get; set; }
        public int RoleId { get; set; }
        public Role Role { get; set; }
    }

}
