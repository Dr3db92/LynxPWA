﻿namespace ScottysWebApp.Server.Models.App
{
    public class AppSettings
    {
        public long MaxFileSize { get; set; }
    }
}
