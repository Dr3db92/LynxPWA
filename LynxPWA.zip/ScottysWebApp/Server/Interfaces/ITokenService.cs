﻿using ScottysWebApp.Server.Models;
using ScottysWebApp.Server.Models.App;

namespace ScottysWebApp.Server.Interfaces
{
    public interface ITokenService
    {
        Task StoreResetTokenAsync(string userId, string token, DateTime expirationTime);
        Task<TokenData> GetResetTokenAsync(string userId);
        Task DeleteResetTokenAsync(string userId);
    }
}

