﻿using ScottysWebApp.Server.Models;

namespace ScottysWebApp.Server.Interfaces
{
    public interface IPdfService
    {
        Task<Stream> GeneratePdf(object dto);
    }
}
