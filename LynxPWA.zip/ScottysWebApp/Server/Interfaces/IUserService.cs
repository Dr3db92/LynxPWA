﻿using Microsoft.AspNetCore.Identity;
using ScottysWebApp.Server.Models.User;

namespace ScottysWebApp.Server.Interfaces
{
    public interface IUserService
    {
        Task<List<string>> GetUserRolesAsync(IdentityUser user);
        Task<IdentityResult> CreateUserAsync(RegisterDTO registerDto);
        Task<bool> CheckUserLockoutAsync(string username);
    }
}
