﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ScottysWebApp.Server.Models.User;

namespace ScottysWebApp.Server.Controllers
{
    [ApiController]
    [Route("api/update-users")]
    public class UpdateUsersController : Controller
    {
        private readonly UserManager<IdentityUser> _userManager;

        //Initialize user manager
        public UpdateUsersController(UserManager<IdentityUser> userManager)
        {
            _userManager = userManager;
        }

        //Endpoint to update user information
        [Authorize(Policy = "RequireAdministratorRole")]
        [HttpPatch("{email}")]
        public async Task<IActionResult> UpdateUser(string email, [FromBody] UpdateUsersDTO updateUserDto)
        {
            if (string.IsNullOrEmpty(email))
            {
                return BadRequest("Email cannot be null or empty.");
            }

            try
            {
                //Find the user by email
                var user = await _userManager.FindByEmailAsync(email);
                if (user == null)
                {
                    return NotFound("User not found.");
                }

                //Update user properties if they are provided in the DTO
                if (!string.IsNullOrEmpty(updateUserDto.Email))
                {
                    user.Email = updateUserDto.Email;
                    user.NormalizedEmail = updateUserDto.Email.ToUpper();
                    user.UserName = updateUserDto.UserName;
                    user.NormalizedUserName = updateUserDto.UserName.ToUpper();
                }
                if (!string.IsNullOrEmpty(updateUserDto.PhoneNumber))
                {
                    user.PhoneNumber = updateUserDto.PhoneNumber;
                }
                if (!string.IsNullOrEmpty(updateUserDto.Role))
                {
                    //Update the user's role
                    var currentRole = await _userManager.GetRolesAsync(user);
                    await _userManager.RemoveFromRolesAsync(user, currentRole);
                    await _userManager.AddToRoleAsync(user, updateUserDto.Role);
                }

                //Save the updated user information
                var result = await _userManager.UpdateAsync(user);
                if (result.Succeeded)
                {
                    return Ok("User updated successfully.");
                }

                return BadRequest("Failed to update user: " + String.Join("; ", result.Errors.Select(e => e.Description)));
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred while trying to update the user. {ex}");
            }
        }

        //Endpoint to get a list of all users
        [Authorize(Policy = "RequireAdministratorRole")]
        [HttpGet("users")]
        public async Task<IActionResult> GetUsers()
        {
            try
            {
                //Retrieve all users from the UserManager
                var users = await _userManager.Users.ToListAsync();

                //Map the user information to DTOs
                var userDtos = users.Select(user => new UpdateUsersDTO
                {
                    UserName = user.UserName,
                    Email = user.Email,
                    PhoneNumber = user.PhoneNumber,
                    Role = _userManager.GetRolesAsync(user).Result.FirstOrDefault()
                }).ToList();

                //Return the list of user DTOs
                return Ok(userDtos);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred while trying to fetch the users. {ex}");
            }
        }
    }
}