﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ScottysWebApp.Server.Data;
using ScottysWebApp.Server.Models.Equipment;
using ScottysWebApp.Server.Models.PartModel;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace ScottysWebApp.Server.Controllers
{
    [ApiController]
    [Route("api/parts")]
    public class PartsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<PartsController> _logger;

        //Initialize the db context and the logger
        public PartsController(ApplicationDbContext context, ILogger<PartsController> logger)
        {
            _context = context;
            _logger = logger;
        }

        //Endpoint to get a part by its number, OEM, and cost
        [HttpGet("get-part-by-number/{partNumber}/{oem}/{cost}")]
        public async Task<IActionResult> GetPartByNumber(string partNumber, string oem, decimal cost)
        {
            //Retrieve the part with the specified part number, OEM, and cost, including compatible models
            var part = await _context.Parts
                .Include(p => p.CompatibleModels)
                .FirstOrDefaultAsync(p => p.PartNumber == partNumber && p.OEM == oem && p.Cost == cost);

            if (part == null)
            {
                return NotFound();
            }

            //Return the part details
            return Ok(part);
        }

        //Endpoint to add or update a part
        [HttpPost("add-or-update-part")]
        public async Task<IActionResult> AddOrUpdatePart([FromBody] PartsDto partModel)
        {
            //Validate the model state
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            //Begin a new database transaction
            var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                //Retrieve the existing part with the specified part number and OEM
                var existingPart = await _context.Parts
                    .Include(p => p.CompatibleModels)
                    .SingleOrDefaultAsync(p => p.PartNumber == partModel.PartNumber && p.OEM == partModel.OEM);

                if (existingPart != null)
                {
                    //Update the quantity of the existing part
                    existingPart.Quantity += partModel.Quantity;

                    // Update InvoiceNumber and WebsiteLink fields for existing part
                    existingPart.WebsiteLink = partModel.WebsiteLink;

                    if (partModel.PlantID.HasValue)
                    {
                        existingPart.PlantID = partModel.PlantID;
                    }

                    //Update the compatible models of the existing part
                    foreach (var model in partModel.CompatibleModels)
                    {
                        var existingModel = await _context.CompatibleModels
                            .FirstOrDefaultAsync(cm => cm.ModelName == model.ModelName && cm.PartID == existingPart.PartID);

                        if (existingModel == null)
                        {
                            //If the compatible model does not exist, create a new one and link it to the part
                            var equipment = await _context.Equipment.FindAsync(model.EquipmentID);
                            existingPart.CompatibleModels.Add(new CompatibleModel
                            {
                                ModelName = model.ModelName,
                                EquipmentID = model.EquipmentID,
                                Equipment = equipment
                            });
                        }
                    }
                    //Update the existing part in the context
                    _context.Update(existingPart);
                }
                else
                {
                    //Create a new part if it does not exist
                    var newPart = new Parts
                    {
                        PartName = partModel.PartName,
                        PartNumber = partModel.PartNumber,
                        Quantity = partModel.Quantity,
                        Cost = partModel.Cost,
                        Description = partModel.Description,
                        OEM = partModel.OEM,
                        PlantID = partModel.PlantID,
                        WebsiteLink = partModel.WebsiteLink,
                        CompatibleModels = new List<CompatibleModel>()
                    };

                    //Link the compatible models to the new part
                    foreach (var model in partModel.CompatibleModels)
                    {
                        var existingModel = await _context.CompatibleModels
                            .FirstOrDefaultAsync(cm => cm.ModelName == model.ModelName);

                        if (existingModel != null)
                        {
                            // Link the existing compatible model
                            newPart.CompatibleModels.Add(existingModel);
                        }
                    }
                    //Add the new part to the context
                    _context.Parts.Add(newPart);
                }

                //Save changes to the database
                await _context.SaveChangesAsync();

                //Commit the transaction
                await transaction.CommitAsync();
                return Ok(new { Message = "Part added or updated successfully." });
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                return StatusCode(500, "An error occurred: " + ex.Message);
            }
        }

        [HttpGet("get-all-parts")]
        public async Task<IActionResult> GetAllParts()
        {
            _logger.LogInformation("Attempting to retrieve all parts");
            try
            {
                // Retrieve all parts, including compatible models, related equipment, and plant information
                var partsList = await _context.Parts
                    .Include(p => p.CompatibleModels)
                    .ThenInclude(cm => cm.Equipment)
                    .Include(p => p.Plant)  // Include plant information
                    .ToListAsync();

                _logger.LogInformation($"Retrieved {partsList.Count} parts");

                // Map parts to DTOs
                var partsDtoList = partsList.Select(part => new PartsDto
                {
                    PartID = part.PartID,
                    PartName = part.PartName != null ? part.PartName : "No part name provided",
                    PartNumber = part.PartNumber != null ? part.PartNumber : "No part number found",
                    Quantity = part.Quantity ?? 0,
                    Cost = part.Cost ?? 0,
                    Description = part.Description != null ? part.Description : "No description provided",
                    OEM = part.OEM != null ? part.OEM : "No OEM provided",
                    PlantID = part.PlantID ?? 0,  // Include PlantID
                    PlantName = part.Plant != null ? part.Plant.PlantName : "No Plant", 
                    WebsiteLink = part.WebsiteLink != null ? part.WebsiteLink : "No Link",
                    CompatibleModels = part.CompatibleModels.Select(cm => new CompatibleModelDto
                    {
                        ModelID = cm.ModelID,
                        ModelName = cm.ModelName,
                        EquipmentID = cm.EquipmentID
                        }).ToList()
                    }).ToList();

                var options = new JsonSerializerOptions
                {
                    // Preserve object references to avoid circular references
                    ReferenceHandler = ReferenceHandler.Preserve,
                    // Write JSON in an indented format
                    WriteIndented = true
                };

                // Return the list of parts DTO as a JSON response
                return new JsonResult(partsDtoList, options);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to retrieve parts");
                return StatusCode(500, $"An error occurred while retrieving parts: {ex.Message}");
            }
        }

        [HttpPost("reduce-quantity")]
        public async Task<IActionResult> ReducePartQuantity([FromBody] ReducePartQuantityRequest request)
        {
            var part = await _context.Parts.FindAsync(request.PartID);
            if (part == null)
            {
                return NotFound("Part not found");
            }

            part.Quantity -= request.QuantityUsed;
            await _context.SaveChangesAsync();

            return Ok();
        }

        //Endpoint to remove parts
        [HttpPost("remove-parts")]
        public async Task<IActionResult> RemoveParts([FromBody] List<int> partIds)
        {
            if (partIds == null || !partIds.Any())
            {
                return BadRequest("Part IDs are required.");
            }

            //Retrieve the parts to be removed, including related compatible models
            var parts = await _context.Parts
                .Where(p => partIds.Contains(p.PartID))
                .Include(p => p.CompatibleModels)
                .ToListAsync();

            if (!parts.Any())
            {
                return NotFound("No parts found to delete.");
            }

            //Remove the parts from the context
            _context.Parts.RemoveRange(parts);

            try
            {
                //Save changes to the database
                await _context.SaveChangesAsync();
                return Ok("Parts removed successfully.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to remove parts");
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpGet("get-all-parts-with-plants")]
        public async Task<IActionResult> GetAllPartsWithPlants()
        {
            _logger.LogInformation("Attempting to retrieve all parts with associated plants");

            try
            {
                // Retrieve parts with their associated plant and compatible models information
                var parts = await _context.Parts
                    .Include(p => p.Plant)  // Include associated plant
                    .Include(p => p.CompatibleModels)  // Include compatible models
                    .ThenInclude(cm => cm.Equipment)  // Include associated equipment for each compatible model
                    .Select(p => new PartsDto
                    {
                        PartID = p.PartID,
                        PartName = p.PartName ?? "No part name provided",
                        PartNumber = p.PartNumber ?? "No part number found",
                        Quantity = p.Quantity ?? 0,
                        Cost = p.Cost ?? 0,
                        Description = p.Description ?? "No description provided",
                        OEM = p.OEM ?? "No OEM provided",
                        PlantID = p.PlantID ?? 0, // Include PlantID if present
                        PlantName = p.Plant != null ? p.Plant.PlantName : "N/A", // Use plant name if available
                        WebsiteLink = p.WebsiteLink ?? "N/A",

                        // Include CompatibleModels mapped to DTO
                        CompatibleModels = p.CompatibleModels.Select(cm => new CompatibleModelDto
                        {
                            ModelID = cm.ModelID,
                            ModelName = cm.ModelName,
                            EquipmentID = cm.EquipmentID
                        }).ToList()
                    })
                    .ToListAsync();

                _logger.LogInformation($"Successfully retrieved {parts.Count} parts with plant and compatible model data");

                return Ok(parts);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to retrieve parts with associated plants and compatible models");
                return StatusCode(500, $"An error occurred while retrieving parts: {ex.Message}");
            }
        }
    }
}