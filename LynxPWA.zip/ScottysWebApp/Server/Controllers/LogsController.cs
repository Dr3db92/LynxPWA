﻿using Microsoft.AspNetCore.Mvc;
using ScottysWebApp.Server.Data;
using ScottysWebApp.Server.Models.App;
using Serilog;

namespace ScottysWebApp.Server.Controllers
{
    [ApiController]
    [Route("api/log")]
    public class LoggerController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public LoggerController(ApplicationDbContext context)
        {
            _context = context;
        }


        [HttpPost]
        public async Task<IActionResult> Logger([FromBody] LogEntry logEntry)
        {
            if (logEntry == null)
            {
                return BadRequest("Log entry is null.");
            }

            // Save log entry to database
            _context.LogEntries.Add(logEntry);
            await _context.SaveChangesAsync();

            // Use the log level from the log entry
            switch (logEntry.Level.ToLower())
            {
                case "information":
                    Log.Logger.Information("{@LogEntry}", logEntry);
                    break;
                case "warning":
                    Log.Logger.Warning("{@LogEntry}", logEntry);
                    break;
                case "error":
                    Log.Logger.Error("{@LogEntry}", logEntry);
                    break;
                default:
                    Log.Logger.Information("{@LogEntry}", logEntry);
                    break;
            }

            return Ok();
        }
    }
}