﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ScottysWebApp.Server.Data;
using ScottysWebApp.Server.Interfaces;
using ScottysWebApp.Server.Models.Equipment;
using ScottysWebApp.Server.Models.User;
using ScottysWebApp.Server.Models.Users;
using System.Text.Json;

namespace ScottysWebApp.Server.Controllers
{
    //Handles training-related operations, such as fetching users, equipment models, and submitting training certifications
    [Route("api/[controller]")]
    [ApiController]
    public class TrainingController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<IdentityUser> _userManager;
        private readonly IPdfService _pdfService;

        //Initialize db context and user manager
        public TrainingController(ApplicationDbContext context, UserManager<IdentityUser> userManager, IPdfService pdfService)
        {
            _context = context;
            _userManager = userManager;
            _pdfService = pdfService ?? throw new ArgumentNullException(nameof(pdfService));
        }

        //Endpoint to get a list of all users
        [HttpGet("users")]
        public async Task<IActionResult> GetUsers()
        {
            try
            {
                // Define the roles you want to include
                var roles = new[] { "user", "Admin", "Mechanic", "Maintenance" };

                var users = new List<IdentityUser>();

                // Loop through each role and retrieve users
                foreach (var role in roles)
                {
                    var usersInRole = await _userManager.GetUsersInRoleAsync(role);
                    users.AddRange(usersInRole);
                }

                // Removing duplicates if in case single user belongs to multiple roles
                users = users.Distinct().ToList();

                return Ok(users);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error fetching users: {ex.Message}");
                return StatusCode(500, "An error occurred while fetching the users.");
            }
        }

        //Endpoint to get a list of all equipment models
        [HttpGet("equipment/models")]
        public async Task<IActionResult> GetEquipmentModels()
        {
            //Retrieve and group equipment models by ModelID and ModelName, then select them into a DTO
            var models = await _context.CompatibleModels
                                        .GroupBy(m => new { m.ModelID, m.ModelName })
                                        .Select(g => new CompatibleModelDto
                                        {
                                            ModelID = g.Key.ModelID,
                                            ModelName = g.Key.ModelName
                                        })
                                        .ToListAsync();

            //Return the list of equipment models
            return Ok(models);
        }

        [HttpPost("training-certification")]
        public async Task<IActionResult> SubmitTrainingCertification([FromBody] TrainingCertifications model)
        {
            try
            {
                Console.WriteLine($"Received Model: {JsonSerializer.Serialize(model)}"); // Log incoming data

                if (!ModelState.IsValid)
                {
                    foreach (var state in ModelState)
                    {
                        foreach (var error in state.Value.Errors)
                        {
                            Console.WriteLine($"Key: {state.Key}, Error: {error.ErrorMessage}");
                        }
                    }

                    return BadRequest(new
                    {
                        Title = "Validation Error",
                        Status = 400,
                        Detail = "One or more validation errors occurred.",
                        Errors = ModelState.ToDictionary(
                            kvp => kvp.Key,
                            kvp => kvp.Value.Errors.Select(e => e.ErrorMessage).ToArray()
                        )
                    });
                }

                model.UploadedAt = DateTime.Now;
                // Save the certification model to the database
                _context.TrainingCertifications.Add(model);
                await _context.SaveChangesAsync();

                // Return the saved certification along with its details, like the PDF filename (or the content if needed)
                var certificationResponse = new TrainingCertificationViewModel
                {
                    UserName = _userManager.Users.FirstOrDefault(u => u.Id == model.UserID)?.Email,
                    ModelName = _context.CompatibleModels.FirstOrDefault(m => m.ModelID == model.EquipmentModelID)?.ModelName,
                    PdfData = Convert.ToBase64String(model.FormData), // Return the PDF as Base64
                    UploadedAt = model.UploadedAt
                };

                return Ok(certificationResponse);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}"); // Log exception details
                return StatusCode(500, $"Server Error: {ex.Message}");
            }
        }

        [HttpGet("certifications")]
        public async Task<IActionResult> GetCertifications()
        {
            try
            {
                // Fetch all certifications and related data in a single query
                var certifications = await _context.TrainingCertifications
                    .Select(tc => new
                    {
                        tc.TrainingID,
                        tc.UserID,
                        tc.EquipmentModelID,
                        tc.FormData, // Directly map FormData, no conversion here yet
                        tc.UploadedAt
                    })
                    .ToListAsync();

                // Create view models with fallback handling for FormData
                var certificationViewModels = certifications.Select(tc => new TrainingCertificationViewModel
                {
                    TrainingID = tc.TrainingID,
                    UserName = _userManager.Users.FirstOrDefault(u => u.Id == tc.UserID)?.Email,
                    ModelName = _context.CompatibleModels.FirstOrDefault(m => m.ModelID == tc.EquipmentModelID)?.ModelName ?? "Unknown Model",
                    PdfData = tc.FormData != null ? Convert.ToBase64String(tc.FormData) : "No PDF Available", // Safely handle null FormData
                    UploadedAt = tc.UploadedAt.HasValue ? tc.UploadedAt.Value : (DateTime?)null
                }).ToList();


                return Ok(certificationViewModels);
            }
            catch (Exception ex)
            {
                // Log the error
                Console.WriteLine($"Error fetching training certifications: {ex.Message}");
                return StatusCode(500, "An error occurred while retrieving training certifications.");
            }
        }


        [HttpDelete("delete/{trainingId}")]
        public async Task<IActionResult> DeleteCertification(int trainingId)
        {
            var certification = await _context.TrainingCertifications.FindAsync(trainingId);
            if (certification == null)
            {
                return NotFound();
            }

            var form = await _context.SaveForms.FirstOrDefaultAsync(f => f.FormData.Contains(trainingId.ToString()));
            if (form != null)
            {
                _context.SaveForms.Remove(form);
            }

            _context.TrainingCertifications.Remove(certification);
            await _context.SaveChangesAsync();

            return Ok();
        }


    }
}