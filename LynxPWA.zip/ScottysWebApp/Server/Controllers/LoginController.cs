﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.Google;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Options;
using ScottysWebApp.Server.Interfaces;
using ScottysWebApp.Server.Models.User;
using System.Net;
using System.Security.Claims;
using System.Text.Encodings.Web;

namespace ScottysWebApp.Server.Controllers
{
    [ApiController]
    [Route("api/auth")]
    public class LoginController : ControllerBase
    {
        //Dependency injections for managing users, roles, authentication schemes, options, email service, and memory cache
        private readonly UserManager<IdentityUser> _userManager;
        private readonly SignInManager<IdentityUser> _signInManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly IAuthenticationSchemeProvider _schemeProvider;
        private readonly IOptions<AuthenticationOptions> _authOptions;
        private readonly IEmailService _emailService;
        private readonly IMemoryCache _memoryCache;

        //Initialize dependencies
        public LoginController(
            UserManager<IdentityUser> userManager,
            SignInManager<IdentityUser> signInManager,
            RoleManager<IdentityRole> roleManager,
            IAuthenticationSchemeProvider schemeProvider,
            IOptions<AuthenticationOptions> authOptions,
            IEmailService emailService,
            IMemoryCache memoryCache)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _roleManager = roleManager;
            _schemeProvider = schemeProvider;
            _authOptions = authOptions;
            _emailService = emailService;
            _memoryCache = memoryCache;
        }

        //Helper method to get user roles from memory cache
        private async Task<List<string>> GetUserRolesAsync(IdentityUser user)
        {
            var cacheKey = $"UserRoles-{user.Id}";
            var roles = await _memoryCache.GetOrCreateAsync(cacheKey, async entry =>
            {
                //Cache expiration time set to 1 hour
                entry.AbsoluteExpirationRelativeToNow = TimeSpan.FromHours(1);
                return await _userManager.GetRolesAsync(user);
            });
            //Return roles or an empty list if roles are null
            return roles?.ToList() ?? new List<string>();
        }

        // Endpoint to handle user login
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginDTO loginDto)
        {
            // Check if the loginDto is valid
            if (loginDto == null || string.IsNullOrWhiteSpace(loginDto.Email) || string.IsNullOrWhiteSpace(loginDto.Password))
            {
                return BadRequest("Invalid login attempt.");
            }

            // Find the user by email
            var user = await _userManager.FindByEmailAsync(loginDto.Email);
            if (user == null)
            {
                // If the user with the provided email does not exist, return Unauthorized
                return Unauthorized("Invalid login attempt.");
            }

            // Check the password directly against the user
            var result = await _signInManager.CheckPasswordSignInAsync(user, loginDto.Password, lockoutOnFailure: false);

            if (result.Succeeded)
            {
                // If the sign-in attempt is successful, retrieve the roles assigned to the user
                var roles = await _userManager.GetRolesAsync(user);
                var claims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name, user.Email),
                    new Claim(ClaimTypes.NameIdentifier, user.Id),
                    new Claim(ClaimTypes.Email, user.Email)
                };

                // Add the roles as claims to the claims list
                foreach (var role in roles)
                {
                    claims.Add(new Claim(ClaimTypes.Role, role));
                }

                // Create a ClaimsIdentity and ClaimsPrincipal for the authenticated user
                var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                var claimsPrincipal = new ClaimsPrincipal(claimsIdentity);
                var authProperties = new AuthenticationProperties
                {
                    IsPersistent = true, // Make the login session persistent
                    ExpiresUtc = DateTime.UtcNow.AddMinutes(30) // Set expiration time for the session
                };

                // Sign in the user with cookie authentication
                await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, claimsPrincipal, authProperties);

                // Return a success response with the user role
                return Ok(new { Message = "User authenticated successfully", Role = roles.FirstOrDefault() ?? "User" });
            }
            else if (result.IsLockedOut)
            {
                // If the user account is locked out, return a Locked response
                return StatusCode((int)HttpStatusCode.Locked, "User account locked out due to multiple failed login attempts.");
            }
            else
            {
                // If the sign-in attempt fails, return an Unauthorized response
                return Unauthorized("Invalid login attempt.");
            }
        }

        //Endpoint to handle user logout
        [HttpPost("logout")]
        public async Task<IActionResult> Logout()
        {
            //Sign out the user from cookie authentication
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return Ok();
        }

        //Endpoint to register a new user
        [Authorize(Policy = "RequireAdministratorRole")]
        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegisterDTO registerDto)
        {
            //Check if model state is valid
            if (!ModelState.IsValid)
            {
                return BadRequest(new { Title = "Invalid input data" });
            }

            try
            {
                //Normalize the email to ensure case insensitivity
                var normalizedEmail = registerDto.Email.ToUpperInvariant();
                //Check if a user with the given email already exists
                var userExists = await _userManager.FindByEmailAsync(normalizedEmail);
                if (userExists != null)
                {
                    return BadRequest(new { Title = "Email already exists." });
                }

                //Create a new user with the provided username, email, and password
                var user = new IdentityUser { UserName = registerDto.Username, Email = registerDto.Email };
                var result = await _userManager.CreateAsync(user, registerDto.Password);

                if (result.Succeeded)
                {
                    //Assign the "User" role to the newly created user
                    var roleResult = await _userManager.AddToRoleAsync(user, "User");
                    if (!roleResult.Succeeded)
                    {
                        return StatusCode(500, new { Title = "Failed to assign user role.", Errors = roleResult.Errors.Select(e => e.Description) });
                    }

                    //Generate an email confirmation token for the user
                    var code = await _userManager.GenerateEmailConfirmationTokenAsync(user);
                    var callbackUrl = Url.Action("ConfirmEmail", "Account", new { userId = user.Id, code = code }, protocol: HttpContext.Request.Scheme);

                    try
                    {
                        //Send the email confirmation link to the user
                        await _emailService.SendEmailAsync(user.Email, "Confirm your email",
                        $"Please confirm your account by <a href='{HtmlEncoder.Default.Encode(callbackUrl ?? string.Empty)}'>clicking here</a>. The link expires in 10 minutes.");
                    }
                    catch (Exception ex)
                    {
                        Console.Error.WriteLine($"Error sending confirmation email: {ex.Message}");
                        return StatusCode(500, new { Title = "Failed to send confirmation email.", Error = ex.Message });
                    }

                    return Ok(new { Title = "User registered successfully. Please check your email to confirm your account." });
                }

                Console.Error.WriteLine($"User creation failed: {string.Join(", ", result.Errors.Select(e => e.Description))}");
                return BadRequest(new { Title = "Failed to register user.", Errors = result.Errors.Select(e => e.Description) });
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine($"Error during registration: {ex.Message}");
                return StatusCode(500, new { Title = "An unexpected error occurred.", Error = ex.Message });
            }
        }

        //Endpoint to delete a user by username
        [Authorize(Policy = "RequireAdministratorRole")]
        [HttpDelete("delete-user/{username}")]
        public async Task<IActionResult> DeleteUser(string username)
        {
            if (string.IsNullOrEmpty(username))
            {
                return BadRequest("Username cannot be null or empty.");
            }

            try
            {
                //Find the user by username
                var user = await _userManager.FindByNameAsync(username);
                if (user == null)
                {
                    return NotFound("User not found.");
                }

                //Attempt to delete the user
                var result = await _userManager.DeleteAsync(user);
                if (result.Succeeded)
                {
                    // Log the successful deletion
                    return Ok("User deleted successfully.");
                }

                // Log the failure
                return BadRequest("Failed to delete user: " + String.Join("; ", result.Errors.Select(e => e.Description)));
            }
            catch (Exception ex)
            {
                // Log the exception
                return StatusCode(500, $"An error occurred while trying to delete the user. {ex}");
            }
        }
    }
}