﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using ScottysWebApp.Server.Interfaces;
using ScottysWebApp.Server.Models.Response;
using ScottysWebApp.Server.Models.User;

namespace ScottysWebApp.Server.Controllers
{
    [ApiController]
    [Route("api/account")]
    public class AccountController : ControllerBase
    {
        //Dependency injections for managing users, sending emails, and handling tokens
        private readonly UserManager<IdentityUser> _userManager;
        private readonly IEmailService _emailService;
        private readonly ILogger<EquipmentController> _logger;
        private readonly ITokenService _tokenService;

        //Initialize user manager, email service, and token service
        public AccountController(UserManager<IdentityUser> userManager, IEmailService emailService, ITokenService tokenService)
        {
            _userManager = userManager;
            _emailService = emailService;
            _tokenService = tokenService;
        }

        //Endpoint to confirm a user's email
        [HttpGet("confirm-email")]
        public async Task<IActionResult> ConfirmEmail(string userId, string code)
        {
            //Check if userId or code is null or whitespace, return BadRequest if so
            if (string.IsNullOrWhiteSpace(userId) || string.IsNullOrWhiteSpace(code))
            {
                return BadRequest("User ID and Code must be provided.");
            }

            //Find the user by their ID
            var user = await _userManager.FindByIdAsync(userId);
            if (user == null)
            {
                return NotFound("User not found.");
            }

            //Confirm the user's email and redirect on success
            var result = await _userManager.ConfirmEmailAsync(user, code);
            if (result.Succeeded)
            {
                return Redirect("/confirm-email-success");
            }
            else
            {
                return BadRequest("Failed to confirm email or the link has expired.");
            }
        }

        //Endpoint test to ensure the API is working
        [HttpGet("test")]
        public IActionResult Test()
        {
            return Ok(new { Message = "Test endpoint is working." });
        }

        //Endpoint to get the current user's state
        [AllowAnonymous]
        [HttpGet("userinfo")]
        public async Task<IActionResult> GetUserState()
        {
            // Check if the user is authenticated
            if (User.Identity?.IsAuthenticated != true)
            {
                return Ok(new { IsAuthenticated = false });
            }

            // Get the authenticated user
            var user = await _userManager.GetUserAsync(User);
            // Return 404 if the user is not found
            if (user == null)
            {
                return NotFound("User not found.");
            }

            //Get the user's role
            var roles = await _userManager.GetRolesAsync(user);
            var userInfo = new
            {
                IsAuthenticated = true,
                UserName = user.UserName,
                Email = user.Email,
                IsEmailConfirmed = user.EmailConfirmed,
                //Assumes the user has one primary role
                Role = roles.FirstOrDefault()
            };

            //Return user info
            return Ok(userInfo);
        }

        //Handle forgot password requests
        [HttpPost("forgot-password")]
        public async Task<IActionResult> ForgotPassword([FromBody] ForgotPasswordRequest model)
        {
            //Validate the request model
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            //Find the user by their email address
            var user = await _userManager.FindByEmailAsync(model.Email);
            if (user == null)
            {
                return BadRequest("User not found.");
            }

            //Generates a password reset token and sets the expiration time
            var token = await _userManager.GeneratePasswordResetTokenAsync(user);
            var tokenExpirationTime = DateTime.Now.AddMinutes(10);

            //Store the token and its expiration in the token service
            await _tokenService.StoreResetTokenAsync(user.Id, token, tokenExpirationTime);

            //Create the reset password link
            var resetLink = $"{Request.Scheme}://{Request.Host}/reset-password?token={Uri.EscapeDataString(token)}&email={Uri.EscapeDataString(model.Email)}";

            Console.WriteLine(resetLink);

            // Send email with reset link
            await _emailService.SendEmailAsync(model.Email, "Reset Password", $"<a href='{resetLink}'>Reset Password</a>");

            return Ok();
        }

        //Endpoint to reset the user's password
        [HttpPost("reset-password")]
        public async Task<IActionResult> ResetPassword([FromBody] ResetPasswordRequest model)
        {
            //Validate the request model
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            //Find the user by their email address
            var user = await _userManager.FindByEmailAsync(model.Email);
            if (user == null)
            {
                return BadRequest("User not found.");
            }

            // Retrieve the token and expiration time from the token service
            var storedTokenData = await _tokenService.GetResetTokenAsync(user.Id);
            if (storedTokenData == null)
            {
                return BadRequest("Invalid or expired token.");
            }

            //Check if the token has expired
            var tokenExpirationTime = storedTokenData.ExpirationTime;
            if (tokenExpirationTime < DateTime.UtcNow)
            {
                return BadRequest("The password reset token has expired.");
            }

            //Reset the user's password using the token
            var resetToken = storedTokenData.Token;
            var result = await _userManager.ResetPasswordAsync(user, resetToken, model.NewPassword);

            //Deletes the token after a successful reset
            if (result.Succeeded)
            {
                await _tokenService.DeleteResetTokenAsync(user.Id);
                return Ok();
            }

            //Adds errors to the model state if the reset failed
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError(string.Empty, error.Description);
            }

            //Returns the model state with errors
            return BadRequest(ModelState);
        }
    }
}
