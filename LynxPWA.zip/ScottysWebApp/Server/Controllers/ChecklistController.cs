﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ScottysWebApp.Server.Data;
using ScottysWebApp.Server.Interfaces;
using ScottysWebApp.Server.Models.Forms;
using ScottysWebApp.Server.Models.PartModel;
using System.Text.Json;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace ScottysWebApp.Server.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ChecklistController : ControllerBase
    {
        private readonly IPdfService _pdfService;
        private readonly ApplicationDbContext _context;

        //Initialize the pdf service and the application db context
        public ChecklistController(IPdfService pdfService, ApplicationDbContext context)
        {
            _pdfService = pdfService ?? throw new ArgumentNullException(nameof(pdfService));
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        //Endpoint to submit a checklist
        [HttpPost("submit")]
        public async Task<IActionResult> SubmitChecklist([FromBody] PreOpChecklistDTO submission)
        {
            try
            {
                // Check for duplicate Start mileage
                bool duplicateMileage = await _context.PreOpChecklistSubmissions
                    .AnyAsync(s => s.Equipment == submission.Equipment && s.Start == submission.Start);

                if (duplicateMileage)
                {
                    return BadRequest("The start mileage entered is a duplicate. Please enter a unique mileage.");
                }

                // Save checklist submission
                var checklistSubmission = new PreOpChecklistSubmission
                {
                    OperatorName = submission.OperatorName,
                    Equipment = submission.Equipment,
                    Start = submission.Start ?? 0,
                    Stop = submission.Stop ?? 0,
                    Comments = submission.Comments,
                    OperatorSignature = submission.OperatorSignature,
                    ChecklistDate = submission.Date,
                    DocumentType = submission.DocumentType
                };

                _context.PreOpChecklistSubmissions.Add(checklistSubmission);
                await _context.SaveChangesAsync();

                // Save component items
                if (submission.ComponentItems != null && submission.ComponentItems.Any())
                {
                    var componentItems = submission.ComponentItems.Select(item => new PreOpChecklistComponent
                    {
                        SubmissionId = checklistSubmission.Id,
                        ComponentText = item.ComponentText,
                        Status = item.Status,
                        Comment = item.Comment
                    }).ToList();

                    _context.PreOpChecklistComponents.AddRange(componentItems);
                    await _context.SaveChangesAsync();
                }

                // Generate PDF
                var dto = new PreOpChecklistDTO
                {
                    OperatorName = checklistSubmission.OperatorName,
                    Equipment = checklistSubmission.Equipment,
                    Start = checklistSubmission.Start,
                    Stop = checklistSubmission.Stop,
                    ComponentItems = checklistSubmission.ComponentItems.Select(c => new ComponentItem
                    {
                        ComponentText = c.ComponentText,
                        Status = c.Status,
                        Comment = c.Comment
                    }).ToList(),
                    Comments = checklistSubmission.Comments,
                    OperatorSignature = checklistSubmission.OperatorSignature,
                    Date = checklistSubmission.ChecklistDate,
                    DocumentType = checklistSubmission.DocumentType
                };

                var pdfStream = await _pdfService.GeneratePdf(dto);
                pdfStream.Position = 0;

                // Format the file name with DateTime and OperatorName
                string dateTimeString = DateTime.Now.ToString("yyyyMMddHHmmss");
                string sanitizedOperatorName = string.Join("_", checklistSubmission.OperatorName.Split(Path.GetInvalidFileNameChars()));
                string fileName = $"PreOperationChecklist_{sanitizedOperatorName}_{dateTimeString}.pdf";

                return File(pdfStream, "application/pdf", fileName);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred while saving the checklist: {ex.Message}");
            }
        }

        [HttpPost("submit-workplace")]
        public async Task<IActionResult> SubmitWorkplaceChecklist([FromBody] WorkplaceChecklistDTO submission)
        {
            Console.WriteLine($"Received InspectionArea: {submission.InspectionArea}");
            Console.WriteLine($"Received OperatorName: {submission.OperatorName}");
            try
            {
                var checklistSubmission = new WorkplaceExamChecklistSubmission
                {
                    OperatorName = submission.OperatorName,
                    PlantID = submission.PlantID ?? 0,
                    InspectionArea = submission.InspectionArea,
                    Comments = submission.Comments,
                    OperatorSignature = submission.OperatorSignature,
                    ChecklistDate = submission.Date
                };

                _context.WorkplaceExamChecklistSubmissions.Add(checklistSubmission);
                await _context.SaveChangesAsync();

                if (submission.InspectionItems != null && submission.InspectionItems.Any())
                {
                    var checklistItems = submission.InspectionItems.Select(item => new WorkplaceExamChecklistItem
                    {
                        SubmissionId = checklistSubmission.Id,
                        InspectionText = item.InspectionText,
                        IsOkSelected = item.IsOkSelected,
                        IsDefSelected = item.IsDefSelected,
                        DeficienciesFound = item.DeficienciesFound
                    }).ToList();

                    _context.WorkplaceExamChecklistItems.AddRange(checklistItems);
                    await _context.SaveChangesAsync();
                }

                Console.WriteLine($"Received InspectionArea: {submission.InspectionArea}");

                var pdfStream = await _pdfService.GeneratePdf(submission);
                pdfStream.Position = 0;

                string dateTimeString = DateTime.Now.ToString("yyyyMMddHHmmss");
                string fileName = $"WorkplaceExamChecklist_{submission.OperatorName}_{dateTimeString}.pdf";

                return File(pdfStream, "application/pdf", fileName);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred while saving the checklist: {ex.Message}");
            }
        }

        [HttpPost("submit-areas-working")]
        public async Task<IActionResult> SubmitAreasWorking([FromBody] AreasWorkingDTO submission)
        {
            try
            {
                // Check if no deficiencies are found, skip the save operation entirely if true
                if (submission.NoDeficienciesFound)
                {
                    // If no deficiencies, return a success response without saving any data
                    return Ok("No deficiencies were found, so no data was saved.");
                }

                // Create a new AreasWorkingSubmission instance from DTO data
                var areasWorkingSubmission = new AreasWorkingSubmission
                {
                    OperatorName = submission.OperatorName,
                    AreasWorking = submission.AreasWorking,
                    NoDeficienciesFound = submission.NoDeficienciesFound,
                    OperatorSignature = submission.OperatorSignature,
                    Date = submission.Date,
                };

                     // Add deficiencies only if NoDeficienciesFound is false
                     areasWorkingSubmission.Deficiencies = submission.Deficiencies
                        .Where(d => !string.IsNullOrWhiteSpace(d.DeficienciesFound)) // Make sure there's a valid deficiency
                        .Select(d => new AreasWorkingDeficiency
                        {
                            DeficienciesFound = d.DeficienciesFound,
                            DateCorrected = d.DateCorrected,
                            Comments = d.Comments
                        }).ToList();
                
                _context.AreasWorkingSubmission.Add(areasWorkingSubmission);
                await _context.SaveChangesAsync();

                // Check if deficiencies exist and save to AreasWorkingRequests
                var deficienciesData = submission.Deficiencies
                    .Where(d => !string.IsNullOrWhiteSpace(d.DeficienciesFound) && d.DeficienciesFound != "N/A")
                    .ToList();

                if (deficienciesData.Any())
                {
                    // Save to AreasWorkingRequests for each deficiency row
                    foreach (var deficiency in submission.Deficiencies)
                    {
                        var areasWorkingRequest = new AreasWorkingRequest
                        {
                            SubmissionId = areasWorkingSubmission.Id,
                            OperatorName = submission.OperatorName,
                            AreasWorking = submission.AreasWorking,
                            OperatorSignature = submission.OperatorSignature,
                            Date = submission.Date,
                            DeficienciesFound = deficiency.DeficienciesFound,
                            DateCorrected = deficiency.DateCorrected,
                            Comments = deficiency.Comments
                        };
                        _context.AreasWorkingRequest.Add(areasWorkingRequest);
                    }

                    await _context.SaveChangesAsync();
                }

                // Generate the PDF after saving data
                var pdfStream = await _pdfService.GeneratePdf(submission);
                var fileName = $"AreasWorking_{DateTime.Now:yyyyMMddHHmmss}.pdf";

                return File(pdfStream, "application/pdf", fileName);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred while saving the submission: {ex.Message}");
            }
        }

        [HttpGet("areas-working-progress")]
        public async Task<IActionResult> GetAreasWorkingProgress()
        {
            try
            {
                var submissions = await _context.AreasWorkingRequest
                    .Where(a => !a.IsProcessed)
                    .Select(a => new
                    {
                        a.RequestID,
                        a.OperatorName,
                        a.Comments,
                        a.AreasWorking,
                        a.Date,
                        a.DeficienciesFound,
                        a.OperatorSignature,
                        a.DateCorrected,
                        a.MaintenanceSignature,
                        a.MaintenanceDate,
                        a.UpdatedComments
                    })
                    .ToListAsync();

                return Ok(submissions);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred while fetching data: {ex.Message}");
            }
        }

        [HttpPut("update-areas-working")]
        public async Task<IActionResult> UpdateAreasWorking([FromBody] AreasWorkingRequest submission)
        {
            try
            {
                // Log received data
                Console.WriteLine($"Received update for RequestID: {submission.RequestID}");
                var existing = await _context.AreasWorkingRequest.FindAsync(submission.RequestID);
                if (existing == null)
                    return NotFound("Submission not found.");

                // Update fields
                existing.MaintenanceSignature = submission.MaintenanceSignature;
                existing.MaintenanceDate = submission.MaintenanceDate;
                existing.UpdatedComments = submission.UpdatedComments;
                existing.IsProcessed = true;

                await _context.SaveChangesAsync();
                return Ok("Submission updated successfully.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred while updating the submission: {ex.Message}");
            }
        }

        [HttpGet("areas-working-records")]
        public async Task<IActionResult> GetAreasWorkingRecords()
        {
            try
            {
                // Join AreasWorkingSubmission and AreasWorkingRequest for combined data
                var submissionRecords = await _context.AreasWorkingSubmission
                 .Select(record => new AreasWorkingRecordViewModel
                 {
                     SubmissionId = record.Id,
                     OperatorName = record.OperatorName,
                     AreasWorking = record.AreasWorking,
                     NoDeficienciesFound = record.NoDeficienciesFound,
                     OperatorSignature = record.OperatorSignature,
                     Date = record.Date,
                     Deficiencies = record.Deficiencies.Select(d => new DeficiencyViewModel
                     {
                         DeficienciesFound = d.DeficienciesFound,
                         DateCorrected = d.DateCorrected,
                         Comments = d.Comments
                     }).ToList(),

                     MaintenanceSignature = null,
                     MaintenanceDate = null,
                     UpdatedComments = null,
                     IsRequest = false
                 }).ToListAsync();

                // Fetch and map AreasWorkingRequest records
                var requestRecords = await _context.AreasWorkingRequest
                    .Where(r => r.IsProcessed) // Getting processed records only
                    .Select(request => new 
                    {
                        request.SubmissionId,
                        request.RequestID,
                        request.MaintenanceSignature,
                        request.MaintenanceDate,
                        request.UpdatedComments,
                        Deficiency = new DeficiencyViewModel
                        {
                            DeficienciesFound = request.DeficienciesFound,
                            DateCorrected = request.DateCorrected,
                            Comments = request.UpdatedComments
                        }
                    }).ToListAsync();

                // Merge the records
                foreach (var request in requestRecords)
                {
                    var combineddata = submissionRecords
                        .FirstOrDefault(s => s.SubmissionId == request.SubmissionId);

                    if (combineddata != null)
                    {
                        // Update the existing submission with request data
                        combineddata.RequestId = request.RequestID;
                        combineddata.MaintenanceSignature = request.MaintenanceSignature;
                        combineddata.MaintenanceDate = request.MaintenanceDate;
                        combineddata.UpdatedComments = request.UpdatedComments;
                    }
                    else
                    {
                        // If no matching submission, create a new card from request data
                        submissionRecords.Add(new AreasWorkingRecordViewModel
                        {
                            SubmissionId = request.SubmissionId,
                            MaintenanceSignature = request.MaintenanceSignature,
                            MaintenanceDate = request.MaintenanceDate,
                            UpdatedComments = request.UpdatedComments,
                            Deficiencies = request.Deficiency != null
                                ? new List<DeficiencyViewModel> { request.Deficiency }
                                : new List<DeficiencyViewModel>(),
                            IsRequest = true
                        });
                    }
                }

                return Ok(submissionRecords);  
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred while fetching data: {ex.Message}");
            }
        }

        [HttpGet("get-all-forms")]
        public async Task<IActionResult> GetAllForms()
        {
            try
            {
                var forms = await _context.SaveForms.ToListAsync();
                return Ok(forms);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred while retrieving forms: {ex.Message}");
            }
        }

        [HttpPost("save-form")]
        public async Task<IActionResult> SaveForm([FromBody] SaveForms request)
        {
            try
            {
                // Validate the request
                if (string.IsNullOrWhiteSpace(request.DocumentType) || string.IsNullOrWhiteSpace(request.FormData))
                {
                    return BadRequest("DocumentType and FormData are required.");
                }

                // Deserialize based on DocumentType
                object deserializedForm;
                switch (request.DocumentType)
                {
                    case "PreOpChecklist":
                        deserializedForm = JsonSerializer.Deserialize<PreOpChecklistDTO>(request.FormData);
                        break;
                    case "WorkplaceExamChecklist":
                        deserializedForm = JsonSerializer.Deserialize<WorkplaceChecklistDTO>(request.FormData);
                        break;
                    default:
                        return BadRequest($"Unsupported DocumentType: {request.DocumentType}");
                }

                // Save to SaveForms table
                var saveForm = new SaveForms
                {
                    DocumentType = request.DocumentType,
                    FormData = request.FormData,
                    CreatedAt = DateTime.UtcNow
                };

                _context.SaveForms.Add(saveForm);
                await _context.SaveChangesAsync();

                return Ok(new { Message = "Form saved successfully.", FormId = saveForm.Id });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred while saving the form: {ex.Message}");
            }
        }

        [HttpGet("download-pdf/{formId}")]
        public async Task<IActionResult> DownloadPdf(int formId)
        {
            var submission = await _context.PreOpChecklistSubmissions
                .Include(s => s.ComponentItems)
                .FirstOrDefaultAsync(s => s.Id == formId);

            if (submission == null)
            {
                return NotFound("Form not found.");
            }

            var dto = new PreOpChecklistDTO
            {
                OperatorName = submission.OperatorName,
                Equipment = submission.Equipment,
                Start = submission.Start,
                Stop = submission.Stop,
                ComponentItems = submission.ComponentItems.Select(c => new ComponentItem
                {
                    ComponentText = c.ComponentText,
                    Status = c.Status,
                    Comment = c.Comment
                }).ToList(),
                Comments = submission.Comments,
                OperatorSignature = submission.OperatorSignature,
                Date = submission.ChecklistDate,
                DocumentType = submission.DocumentType
            };

            var pdfStream = await _pdfService.GeneratePdf(dto);
            var fileName = $"PreOperationChecklist_{DateTime.Now:yyyyMMddHHmmss}.pdf";
            return File(pdfStream, "application/pdf", fileName);
        }

        [HttpGet("generate-pdf/{id}")]
        public async Task<IActionResult> GeneratePdf(int id)
        {
            var submission = await _context.PreOpChecklistSubmissions
                .Include(s => s.ComponentItems)
                .FirstOrDefaultAsync(s => s.Id == id);

            if (submission == null)
            {
                return NotFound("Submission not found.");
            }

            var dto = new PreOpChecklistDTO
            {
                OperatorName = submission.OperatorName,
                Equipment = submission.Equipment,
                Start = submission.Start,
                Stop = submission.Stop,
                ComponentItems = submission.ComponentItems.Select(c => new ComponentItem
                {
                    ComponentText = c.ComponentText,
                    Status = c.Status,
                    Comment = c.Comment
                }).ToList(),
                Comments = submission.Comments,
                OperatorSignature = submission.OperatorSignature,
                Date = submission.ChecklistDate,
                DocumentType = submission.DocumentType
            };

            var pdfStream = await _pdfService.GeneratePdf(dto);
            var fileName = $"PreOperationChecklist_{DateTime.Now:yyyyMMddHHmmss}.pdf";
            return File(pdfStream, "application/pdf", fileName);
        }

        //Generate a PDF based on document type and JSON data
        private async Task<Stream> GeneratePdf(string documentType, string jsonData)
        {
            try
            {
                // Deserialize and generate the PDF stream based on the document type
                Stream? pdfStream = documentType switch
                {
                    "WorkplaceChecklist" =>
                        await GeneratePdfFromData<WorkplaceChecklistDTO>(jsonData),

                    "AreasWorking" =>
                        await GeneratePdfFromData<AreasWorkingDTO>(jsonData),

                    "PreOpChecklist" =>
                        await GeneratePdfFromData<PreOpChecklistDTO>(jsonData),

                    _ => throw new InvalidOperationException($"Unsupported document type '{documentType}' for PDF generation")
                };

                // Ensure the PDF stream is not null
                return pdfStream ?? throw new InvalidOperationException("Failed to generate PDF");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in GeneratePdf: {ex.Message}");
                throw new InvalidOperationException("Error generating PDF", ex);
            }
        }

        private async Task<Stream> GeneratePdfFromData<T>(string jsonData) where T : class
        {
            var deserializedData = JsonSerializer.Deserialize<T>(jsonData);
            if (deserializedData == null)
            {
                throw new InvalidOperationException($"Failed to deserialize JSON data for type '{typeof(T).Name}'");
            }

            // Generate the PDF with deserialized data
            var pdfStream = await _pdfService.GeneratePdf(deserializedData);

            // Reset stream position to beginning
            pdfStream.Position = 0;
            return pdfStream;
        }
    }
}