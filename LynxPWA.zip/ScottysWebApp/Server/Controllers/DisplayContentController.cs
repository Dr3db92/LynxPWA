﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using ScottysWebApp.Server.Models.User;

namespace ScottysWebApp.Server.Controllers
{
    [ApiController]
    [Route("api/display")]
    public class DisplayContentController : Controller
    {
        //Dependency injections for user management, role management, authentication scheme, and authentication options
        private readonly UserManager<IdentityUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly IAuthenticationSchemeProvider _schemeProvider;
        private readonly IOptions<AuthenticationOptions> _authOptions;

        //Initialize user manager, role manager, the scheme provider, and the authentication options
        public DisplayContentController(
            UserManager<IdentityUser> userManager,
            RoleManager<IdentityRole> roleManager,
            IAuthenticationSchemeProvider schemeProvider,
            IOptions<AuthenticationOptions> authOptions)
        {
            _userManager = userManager;
            _roleManager = roleManager;
            _schemeProvider = schemeProvider;
            _authOptions = authOptions;

        }

        //Endpoint to retrieve all users
        [HttpGet("users")]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult<List<UserInfo>>> GetAllUsers()
        {
            // Retrieve all users from the user manager
            var users = await _userManager.Users.ToListAsync();
            var userInfos = new List<UserInfo>();

            // Iterate through each user and retrieve their roles
            foreach (var user in users)
            {
                var roles = await _userManager.GetRolesAsync(user);

                // Create a user info object for each user and add it to the list
                userInfos.Add(new UserInfo
                {
                    UserID = user.Id, // Include the User ID
                    UserName = user.UserName,
                    Email = user.Email,
                    IsAuthenticated = true,
                    Role = string.Join(", ", roles)
                });
            }

            // Return the list of user info objects
            return userInfos;
        }
    }
}