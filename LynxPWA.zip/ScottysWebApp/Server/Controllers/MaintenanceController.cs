﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ScottysWebApp.Server.Data;
using ScottysWebApp.Server.Models.Equipment;
using ScottysWebApp.Server.Models.PartModel;
using System.Text.Json;

namespace ScottysWebApp.Server.Controllers
{
    [ApiController]
    [Route("api/maintenance")]
    public class MaintenanceController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<MaintenanceController> _logger;

        //Initialize the db context and the logger
        public MaintenanceController(ApplicationDbContext context, ILogger<MaintenanceController> logger)
        {
            _context = context;
            _logger = logger;
        }

        //Endpoint to create a new maintenance request
        [HttpPost("request")]
        public async Task<IActionResult> CreateMaintenanceRequest([FromBody] ServiceOrderRequest request)
        {
            if (request == null)
            {
                return BadRequest("Invalid maintenance request data");
            }

            if (request.SelectedPart != null)
            {
                foreach (var part in request.SelectedPart)
                {
                    // Ensure Plant is null if PlantID is not provided
                    part.Part.Plant = part.Part.PlantID.HasValue
                        ? await _context.Plants.FindAsync(part.Part.PlantID)
                        : null;
                }
            }

            try
            {
                // Ensure the EquipmentID in the request is valid
                var equipment = await _context.Equipment.FindAsync(request.EquipmentID);
                if (equipment == null)
                {
                    return BadRequest("Invalid equipment ID");
                }

                // Check if the equipment is already being tracked
                var trackedEquipment = _context.ChangeTracker.Entries<EquipmentInfo>()
                    .FirstOrDefault(e => e.Entity.EquipmentID == request.EquipmentID);

                // Detach any tracked equipment
                if (trackedEquipment != null)
                {
                    trackedEquipment.State = EntityState.Detached;
                }

                // Reattach the equipment entity
                _context.Attach(equipment);

                // Ensure no circular references
                equipment.EquipmentCompatibleModels = null;

                // Set the Equipment property on the request
                request.Equipment = equipment;

                // Add the maintenance request to the context and save changes
                _context.MaintenanceRequests.Add(request);
                await _context.SaveChangesAsync();

                return Ok(new { Message = "Maintenance request created successfully." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to create maintenance request: {Message}", ex.Message);
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        //Endpoint to get a maintenance request by its ID
        [HttpGet("request/{id}")]
        public async Task<IActionResult> GetMaintenanceRequest(int id)
        {
            var maintenanceRequest = await _context.MaintenanceRequests
                .Include(r => r.SelectedPart)
                .Include(r => r.Equipment)
                .ThenInclude(e => e.EquipmentCompatibleModels)
                .FirstOrDefaultAsync(r => r.RequestID == id);

            if (maintenanceRequest == null)
            {
                return NotFound();
            }

            // Optionally, remove circular references from the response
            foreach (var model in maintenanceRequest.Equipment.EquipmentCompatibleModels)
            {
                model.Equipment = null;  // Break the circular reference
            }

            return Ok(maintenanceRequest);
        }

        [HttpPut("save-request")]
        public async Task<IActionResult> SaveRequest([FromBody] ServiceOrderRequest request)
        {
            if (request == null)
            {
                return BadRequest("Invalid request data");
            }

            try
            {
                // Ensure the EquipmentID in the request is valid
                var equipment = await _context.Equipment
                    .Include(e => e.EquipmentCompatibleModels)  // Include compatible models if needed
                    .FirstOrDefaultAsync(e => e.EquipmentID == request.EquipmentID);

                if (equipment == null)
                {
                    return BadRequest("Invalid equipment ID");
                }

                // Detach or nullify nested properties to avoid circular references
                equipment.CompatibleModels = null; // Nullify to avoid cycles
                request.Equipment = equipment; // Attach the equipment

                // Find existing service order request or create a new one
                var existingRequest = await _context.MaintenanceRequests
                    .Include(r => r.SelectedPart)
                    .FirstOrDefaultAsync(r => r.RequestID == request.RequestID);

                if (existingRequest != null)
                {
                    // Update existing service order request
                    existingRequest.Status = request.Status;
                    existingRequest.Priority = request.Priority;
                    existingRequest.DeficienciesIssues = request.DeficienciesIssues;
                    existingRequest.CorrectionStartDate = request.CorrectionStartDate;
                    existingRequest.Corrections = request.Corrections;
                    existingRequest.MaintenanceSignature = request.MaintenanceSignature;
                    existingRequest.MechanicHours = request.MechanicHours;
                    existingRequest.CorrectionDate = request.CorrectionDate;

                    // Handle parts usage and update stock
                    foreach (var selectedPart in request.SelectedPart)
                    {
                        var part = await _context.Parts.FindAsync(selectedPart.PartID);
                        if (part != null && part.Quantity >= selectedPart.QuantityUsed)
                        {
                            part.Quantity -= selectedPart.QuantityUsed;

                            // Ensure part is added to SelectedParts table
                            var existingPart = existingRequest.SelectedPart
                                .FirstOrDefault(sp => sp.PartID == selectedPart.PartID);
                            if (existingPart == null)
                            {
                                _context.SelectedPart.Add(new SelectedPart
                                {
                                    PartID = selectedPart.PartID,
                                    PartName = selectedPart.PartName,
                                    QuantityUsed = selectedPart.QuantityUsed,
                                    RequestID = existingRequest.RequestID
                                });
                            }
                            else if (existingPart != null)
                            {
                                existingPart.QuantityUsed += selectedPart.QuantityUsed;
                            }
                        }
                        else
                        {
                            return BadRequest($"Not enough stock for part {selectedPart.PartName}");
                        }
                    }

                    // Save the updated request
                    await _context.SaveChangesAsync();
                }
                else
                {
                    // For new requests, nullify the equipment to avoid circular reference issues
                    request.Equipment = null;
                    _context.MaintenanceRequests.Add(request);
                    await _context.SaveChangesAsync();
                }

                // Convert the updated request to DTO, ensuring no cycles
                var dto = new ServiceOrderRequestDto
                {
                    RequestID = request.RequestID,
                    OperatorName = request.OperatorName,
                    DeficienciesIssues = request.DeficienciesIssues,
                    WhereOccurred = request.WhereOccurred,
                    WhenOccurred = request.WhenOccurred,
                    OperatorSignature = request.OperatorSignature,
                    OperatorDate = request.OperatorDate,
                    Corrections = request.Corrections,
                    MechanicHours = request.MechanicHours,
                    MaintenanceSignature = request.MaintenanceSignature,
                    CorrectionStartDate = request.CorrectionStartDate,
                    CorrectionDate = request.CorrectionDate,
                    Status = request.Status,
                    Priority = request.Priority,
                    SelectedParts = request.SelectedPart.Select(sp => new SelectedPartDto
                    {
                        PartID = sp.PartID,
                        PartName = sp.PartName,
                        QuantityUsed = sp.QuantityUsed
                    }).ToList(),
                    EquipmentID = request.EquipmentID
                };

                // Return the updated DTO as response
                return Ok(new { Message = "Request saved successfully.", Request = dto });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred while saving the request: {ex.Message}");
            }
        }

        //Endpoint to get all maintenance requests with related data
        [HttpGet("get-all")]
        public async Task<IActionResult> GetAllMaintenanceRequests()
        {
            //Retrieve all maintenance requests and include relevant related fields
            var maintenanceRequests = await _context.MaintenanceRequests
                .Include(m => m.Equipment)  // Include equipment
                .Include(m => m.SelectedPart)  // Include selected parts
                .Select(m => new
                {
                    m.RequestID,
                    m.EquipmentID,
                    m.OperatorName,
                    m.DeficienciesIssues,
                    m.WhereOccurred,
                    m.WhenOccurred,
                    m.OperatorSignature,
                    m.OperatorDate,
                    m.Corrections,
                    m.MaintenanceSignature,
                    m.CorrectionStartDate,
                    m.MechanicHours,
                    m.Status,
                    m.Priority,
                    Equipment = new  // Flatten the Equipment details to avoid circular references
                    {
                        m.Equipment.EquipmentID,
                        m.Equipment.LocalEquipmentName,
                        m.Equipment.ModelNumber,
                        m.Equipment.SerialNumber,
                        m.Equipment.Manufacturer,
                        m.Equipment.Location
                    },
                    SelectedPart = m.SelectedPart.Select(p => new  // Flatten SelectedParts
                    {
                        p.PartID,
                        p.PartName,
                        p.QuantityUsed
                    })
                })
                .ToListAsync();

            return Ok(maintenanceRequests);
        }
    }

    //Controller for managing repair history
    [ApiController]
    [Route("api/repairhistory")]
    public class RepairHistoryController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<RepairHistoryController> _logger;

        //initialize db context and the logger
        public RepairHistoryController(ApplicationDbContext context, ILogger<RepairHistoryController> logger)
        {
            _context = context;
            _logger = logger;
        }

        //Endpoint to get all repair history records
        [HttpGet("get-all-repair-history")]
        public async Task<IActionResult> GetAllRepairHistory()
        {
            try
            {
                //Retrieve all repair history records and include related equipment
                var repairHistoryList = await _context.RepairHistories
                    .Include(rh => rh.Equipment)
                    .ToListAsync();
                //Return the list of repair history records
                return Ok(repairHistoryList);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to retrieve repair history");
                return StatusCode(500, $"An error occurred while retrieving repair history: {ex.Message}");
            }
        }

        //Endpoint to get a repair history record by its ID
        [HttpGet("get-repair-history/{id}")]
        public async Task<IActionResult> GetRepairHistoryById(int id)
        {
            //Retrieve the repair history record by its ID and include related equipment
            var repairHistory = await _context.RepairHistories
                .Include(rh => rh.Equipment)
                .FirstOrDefaultAsync(rh => rh.RepairID == id);

            if (repairHistory == null)
            {
                return NotFound("Repair history not found");
            }

            //Return the repair history record details
            return Ok(repairHistory);
        }

        [HttpPost("add")]
        public async Task<IActionResult> AddRepairHistory([FromBody] RepairHistories repairHistory)
        {
            if (repairHistory == null)
            {
                _logger.LogError("Invalid repair history data");
                return BadRequest("Invalid repair history data");
            }

            try
            {
                _logger.LogInformation("Received repair history: {@repairHistory}", repairHistory);

                // Validate and attach equipment
                var equipment = await _context.Equipment.AsNoTracking()
                    .FirstOrDefaultAsync(e => e.EquipmentID == repairHistory.EquipmentID);
                if (equipment == null)
                {
                    _logger.LogError("Invalid Equipment ID: {EquipmentID}", repairHistory.EquipmentID);
                    return BadRequest("Invalid Equipment ID");
                }

                _context.Attach(equipment);
                repairHistory.Equipment = equipment;

                // Deserialize parts and validate stock
                var partsUsedDtos = JsonSerializer.Deserialize<List<SelectedPartDto>>(repairHistory.PartsUsed);
                if (partsUsedDtos != null && partsUsedDtos.Any())
                {
                    var partsUsed = new List<SelectedPart>();

                    foreach (var dto in partsUsedDtos)
                    {
                        // Ensure the RequestID references a valid MaintenanceRequests record
                        if (!await _context.MaintenanceRequests.AnyAsync(r => r.RequestID == dto.RequestID))
                        {
                            return BadRequest($"Invalid RequestID: {dto.RequestID}. No matching maintenance request found.");
                        }

                        var part = new SelectedPart
                        {
                            PartID = dto.PartID,
                            PartName = dto.PartName,
                            QuantityUsed = dto.QuantityUsed,
                            RequestID = dto.RequestID // Ensure this value is valid
                        };

                        // Validate stock
                        var partInStock = await _context.Parts.FindAsync(part.PartID);

                        partsUsed.Add(part);
                    }

                    // Assign validated parts to repair history
                    repairHistory.SelectedParts = partsUsed;
                }

                // Add and save the repair history
                _context.RepairHistories.Add(repairHistory);
                await _context.SaveChangesAsync();

                _logger.LogInformation("Repair history added successfully: {@repairHistory}", repairHistory);
                return Ok(new { Message = "Repair history created successfully." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to create repair history: {Message}", ex.Message);
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("get-equipment-with-repair-histories")]
        public async Task<IActionResult> GetEquipmentWithRepairHistories()
        {
            try
            {
                // Ensure EquipmentID is explicitly handled as an integer
                var equipmentWithHistories = await _context.RepairHistories
                    .Include(r => r.Equipment)
                    .Select(r => new
                    {
                        EquipmentID = r.Equipment.EquipmentID, // Ensure this is treated as an integer
                        r.Equipment.LocalEquipmentName
                    })
                    .Distinct()
                    .ToListAsync();

                return Ok(equipmentWithHistories);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving equipment with repair histories.");
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("get-by-equipment/{equipmentId}")]
        public async Task<IActionResult> GetRepairHistoriesByEquipment(int equipmentId)
        {
            try
            {
                // Retrieve repair histories along with related selected parts
                var repairHistories = await _context.RepairHistories
                    .Include(r => r.Equipment)
                    .Where(r => r.EquipmentID == equipmentId)
                    .Select(r => new
                    {
                        r.RepairID,
                        r.CorrectionDate,
                        r.CorrectionStartDate,
                        r.Corrections,
                        r.DeficienciesIssues,
                        r.EquipmentID,
                        r.LocalEquipmentName,
                        r.MaintenanceSignature,
                        r.MechanicHours,
                        r.OperatorDate,
                        r.OperatorName,
                        r.OperatorSignature,
                        r.PartsUsed,
                        r.Status,
                        r.WhenOccurred,
                        // Load the selected parts through ServiceOrderRequest
                        SelectedParts = _context.SelectedPart
                            .Where(sp => sp.RequestID == r.RepairID)
                            .Select(sp => new
                            {
                                sp.PartID,
                                sp.PartName,
                                sp.QuantityUsed,
                                sp.RequestID
                            }).ToList()
                    })
                    .ToListAsync();

                if (repairHistories == null || !repairHistories.Any())
                {
                    return NotFound("No repair history found for this equipment.");
                }

                return Ok(repairHistories);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving repair histories for EquipmentID: {EquipmentID}", equipmentId);
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
    }
}