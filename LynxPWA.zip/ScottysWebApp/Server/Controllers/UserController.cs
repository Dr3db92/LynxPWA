﻿using Microsoft.AspNetCore.Mvc;
using ScottysWebApp.Server.Models;
using ScottysWebApp.Server.Services;

namespace ScottysWebApp.Server.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UserInteractionController : ControllerBase
    {
        private readonly UserSessionService _userSessionService;

        public UserInteractionController(UserSessionService userSessionService)
        {
            _userSessionService = userSessionService;
        }

        // POST: api/user/interaction
        [HttpPost("interaction")]
        public async Task<IActionResult> LogUserInteraction([FromBody] UserInteractionModel interaction)
        {
            if (interaction == null || string.IsNullOrEmpty(interaction.UserName))
            {
                return BadRequest("Invalid user interaction data.");
            }

            _userSessionService.UpdateUserActivity(interaction.UserName, interaction);
            return Ok();
        }
    }
}