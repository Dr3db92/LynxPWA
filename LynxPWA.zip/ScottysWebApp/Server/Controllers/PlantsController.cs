﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ScottysWebApp.Server.Data;
using ScottysWebApp.Server.Models.PartModel;

namespace ScottysWebApp.Server.Controllers
{
    [ApiController]
    [Route("api/plants")]
    public class PlantsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public PlantsController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet("get-all-plants")]
        public async Task<ActionResult<IEnumerable<Plants>>> GetAllPlants()
        {
            return await _context.Plants.ToListAsync();
        }

        [HttpGet("get-plant/{id}")]
        public async Task<ActionResult<Plants>> GetPlant(int id)
        {
            var plant = await _context.Plants.FindAsync(id);

            if (plant == null)
            {
                return NotFound();
            }

            return plant;
        }

        [HttpPost("add-plant")]
        public async Task<IActionResult> AddPlant([FromBody] Plants newPlant)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest("Invalid plant data.");
            }

            // Check if a plant with the same name and address already exists
            var existingPlant = await _context.Plants
                .FirstOrDefaultAsync(p => p.PlantName == newPlant.PlantName
                                       && p.StreetAddress == newPlant.StreetAddress
                                       && p.City == newPlant.City);

            if (existingPlant != null)
            {
                return Conflict(new { Message = "A plant with the same name and address already exists." });
            }

            _context.Plants.Add(newPlant);
            await _context.SaveChangesAsync();

            return Ok(new { Message = "Plant added successfully." });
        }

        [HttpPut("update-plant/{id}")]
        public async Task<IActionResult> UpdatePlant(int id, Plants plant)
        {
            if (id != plant.PlantID)
            {
                return BadRequest();
            }

            // Check if another plant with the same name and address already exists (excluding the current plant being updated)
            var existingPlant = await _context.Plants
                .FirstOrDefaultAsync(p => p.PlantName == plant.PlantName
                                          && p.StreetAddress == plant.StreetAddress
                                          && p.City == plant.City
                                          && p.PlantID != id); // Exclude the current plant

            if (existingPlant != null)
            {
                return Conflict(new { Message = "A plant with the same name and address already exists." });
            }

            _context.Entry(plant).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PlantExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        [HttpDelete("delete-plant/{id}")]
        public async Task<IActionResult> DeletePlant(int id)
        {
            var plant = await _context.Plants.FindAsync(id);
            if (plant == null)
            {
                return NotFound();
            }

            _context.Plants.Remove(plant);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool PlantExists(int id)
        {
            return _context.Plants.Any(e => e.PlantID == id);
        }
    }
}