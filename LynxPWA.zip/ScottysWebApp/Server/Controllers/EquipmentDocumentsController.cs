﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ScottysWebApp.Client.FileHelpers;
using ScottysWebApp.Server.Data;
using ScottysWebApp.Server.Models.Equipment;
using ScottysWebApp.Server.Models.Forms;

[ApiController]
[Route("api/equipment-documents")]
public class EquipmentDocumentsController : ControllerBase
{
    private readonly ApplicationDbContext _context;
    private readonly ILogger<EquipmentDocumentsController> _logger;
    private const long MaxFileSize = 10 * 1024 * 1024; // 10MB

    //Initialize db context and the logger
    public EquipmentDocumentsController(ApplicationDbContext context, ILogger<EquipmentDocumentsController> logger)
    {
        _context = context;
        _logger = logger;
    }

    //Endpoint to get all equipment documents
    [HttpGet("get-all-documents")]
    public async Task<IActionResult> GetAllDocuments()
    {
        var documents = await _context.EquipmentDocuments.ToListAsync();
        //Return list of documents
        return Ok(documents);
    }

    //Endpoint to get documents by equipment model name
    [HttpGet("get-documents-by-model/{modelName}")]
    public async Task<IActionResult> GetFilesByModel(string modelName)
    {
        //Retrieve the model by name and include related equipment and documents
        var model = await _context.CompatibleModels
            .Include(cm => cm.EquipmentCompatibleModels)
            .ThenInclude(ecm => ecm.Equipment)
            .ThenInclude(e => e.EquipmentDocuments)
            .FirstOrDefaultAsync(cm => cm.ModelName == modelName);

        if (model == null)
        {
            return NotFound("Model not found.");
        }

        //Select and return unique documents related to the model
        var documents = model.EquipmentCompatibleModels
            .SelectMany(ecm => ecm.Equipment.EquipmentDocuments)
            .Select(doc => new FileModel
            {
                DocumentId = doc.DocumentId,
                FileName = doc.FileName
            })
            .Distinct()
            .ToList();

        //Return list of documents 
        return Ok(documents);
    }

    //Endpoint to upload a new document
    [HttpPost("upload-document")]
    [Authorize(Policy = "RequireAdministratorRole")]
    public async Task<IActionResult> UploadDocument([FromForm] IFormFile file, [FromForm] string modelName)
    {
        _logger.LogInformation($"Model Name: {modelName}");

        if (file == null || string.IsNullOrEmpty(modelName))
        {
            _logger.LogWarning("File or model name is missing.");
            return BadRequest("File and model name are required.");
        }

        //Get the MIME type of the file
        var contentType = MimeTypeHelper.GetMimeType(file.FileName);
        _logger.LogInformation($"File ContentType: {contentType}");

        //Retrieve the model by name and include related equipment
        var model = await _context.CompatibleModels
            .Include(cm => cm.EquipmentCompatibleModels)
            .ThenInclude(ecm => ecm.Equipment)
            .FirstOrDefaultAsync(cm => cm.ModelName == modelName);

        if (model == null)
        {
            _logger.LogWarning($"Model {modelName} not found.");
            return NotFound("Model not found.");
        }

        using (var memoryStream = new MemoryStream())
        {
            await file.CopyToAsync(memoryStream);
            var fileBytes = memoryStream.ToArray();

            //Iterate through equipment related to the model and add documents
            foreach (var equipment in model.EquipmentCompatibleModels.Select(ecm => ecm.Equipment))
            {
                var document = new EquipmentDocument
                {
                    EquipmentId = equipment.EquipmentID,
                    FileName = file.FileName,
                    ContentType = contentType,  // Ensure ContentType is assigned correctly
                    Data = fileBytes,
                    UploadedAt = DateTime.UtcNow,
                    Keywords = modelName
                };

                _context.EquipmentDocuments.Add(document);
            }

            try
            {
                await _context.SaveChangesAsync();
                _logger.LogInformation("File uploaded successfully.");
                return Ok("File uploaded successfully.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to upload document");
                return StatusCode(500, "Internal server error");
            }
        }
    }

    //Endpoint to delete documents
    [HttpPost("delete-document")]
    [Authorize(Policy = "RequireAdministratorRole")]
    public async Task<IActionResult> DeleteDocument([FromBody] List<int> fileIds)
    {
        if (fileIds == null || !fileIds.Any())
        {
            return BadRequest("File IDs are required.");
        }

        //Retrieve the documents to be deleted by their IDs
        var documents = await _context.EquipmentDocuments
            .Where(d => fileIds.Contains(d.DocumentId))
            .ToListAsync();

        if (!documents.Any())
        {
            return NotFound("No documents found to delete.");
        }

        //Remove the documents from the context
        _context.EquipmentDocuments.RemoveRange(documents);

        try
        {
            //Save changes to the database
            await _context.SaveChangesAsync();
            return Ok("Files deleted successfully.");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to delete files");
            return StatusCode(500, "Internal server error");
        }
    }

    //Endpoint to get documents by equipment ID
    [HttpGet("{equipmentId}")]
    public async Task<IActionResult> GetDocuments(int equipmentId)
    {
        //Retrieve documents related to the equipment ID, ordered by file name
        var documents = await _context.EquipmentDocuments
            .Where(d => d.EquipmentId == equipmentId)
            .OrderBy(d => d.FileName)
            .Select(d => new { d.DocumentId, d.FileName, d.UploadedAt, d.Keywords })
            .ToListAsync();

        return Ok(documents);
    }

    //Endpoint to download a document by its ID
    [HttpGet("download/{documentId}")]
    public async Task<IActionResult> DownloadDocument(int documentId)
    {
        //Retrieve the document by its ID
        var document = await _context.EquipmentDocuments.FindAsync(documentId);
        if (document == null)
            return NotFound();

        //Return the document file with its data, content type, and file name
        return File(document.Data, document.ContentType ?? "application/octet-stream", document.FileName);  // Default to "application/octet-stream" if ContentType is null
    }

    //Endpoint to delete a document by its ID
    [HttpDelete("{documentId}")]
    public async Task<IActionResult> DeleteDocument(int documentId)
    {
        //Retrieve the document by its ID
        var document = await _context.EquipmentDocuments.FindAsync(documentId);
        if (document == null)
            return NotFound();

        //Remove the document from the context
        _context.EquipmentDocuments.Remove(document);
        await _context.SaveChangesAsync();

        return Ok();
    }
}