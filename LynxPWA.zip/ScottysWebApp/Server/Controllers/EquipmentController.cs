﻿using iText.Commons.Actions.Contexts;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ScottysWebApp.Server.Data;
using ScottysWebApp.Server.Models.Equipment;
using System.Security.Claims;
using System.Text.Json;
using System.Text.Json.Serialization;

[ApiController]
[Route("api/equipment")]
public class EquipmentController : ControllerBase
{
    //Dependency injections for managing users, data context, and a logger
    private readonly UserManager<IdentityUser> _userManager;
    private readonly ApplicationDbContext _dataContext;
    private readonly ILogger<EquipmentController> _logger;

    //Initialize user manager, data context, and a logger
    public EquipmentController(UserManager<IdentityUser> userManager, ApplicationDbContext dataContext, ILogger<EquipmentController> logger)
    {
        _userManager = userManager;
        _dataContext = dataContext;
        _logger = logger;
    }

    //Test endpoint to check if the controller is working
    [HttpGet("test")]
    public IActionResult TestEndpoint()
    {
        return Ok("Endpoint reached");
    }

    //Endpoint to add equipment,
    [Authorize(Policy = "RequireAdministratorRole")]
    [HttpPost("add-equipment")]
    public async Task<IActionResult> AddEquipment([FromBody] EquipmentInfo equipment)
    {
        _logger.LogInformation("AddEquipment endpoint hit.");

        using (var transaction = await _dataContext.Database.BeginTransactionAsync())
        {
            try
            {
                //Initialize EquipmentCompatibleModels if it's null
                if (equipment.EquipmentCompatibleModels == null)
                {
                    equipment.EquipmentCompatibleModels = new List<EquipmentCompatibleModel>();
                }

                _logger.LogInformation($"Equipment Model Number: {equipment.ModelNumber}");

                //Add the equipment to the database and save changes to get the EquipmentID
                _dataContext.Equipment.Add(equipment);
                await _dataContext.SaveChangesAsync();

                _logger.LogInformation($"Equipment saved with ID: {equipment.EquipmentID}");

                //Check if a compatible model with the same model number exists
                var existingModel = await _dataContext.CompatibleModels
                    .FirstOrDefaultAsync(cm => cm.ModelName == equipment.ModelNumber);

                //If no existing compatible model is found, create a new one
                if (existingModel == null)
                {
                    _logger.LogInformation("Compatible model not found. Creating a new one.");
                    //Create a new compatible model if it doesn't exist
                    var newModel = new CompatibleModel { ModelName = equipment.ModelNumber, EquipmentID = equipment.EquipmentID };
                    _dataContext.CompatibleModels.Add(newModel);
                    await _dataContext.SaveChangesAsync();

                    //Create the relationship between equipment and the new compatible model
                    var equipmentCompatibleModel = new EquipmentCompatibleModel
                    {
                        EquipmentID = equipment.EquipmentID,
                        ModelID = newModel.ModelID
                    };
                    _dataContext.EquipmentCompatibleModels.Add(equipmentCompatibleModel);
                }
                else
                {
                    _logger.LogInformation("Compatible model found. Linking to existing model.");
                    //If an existing compatible model is found, link it to the new equipment
                    var equipmentCompatibleModel = new EquipmentCompatibleModel
                    {
                        EquipmentID = equipment.EquipmentID,
                        ModelID = existingModel.ModelID
                    };
                    _dataContext.EquipmentCompatibleModels.Add(equipmentCompatibleModel);
                }

                //Save the changes to commit the relationship
                await _dataContext.SaveChangesAsync();
                await transaction.CommitAsync(); //Commit the transaction
                _logger.LogInformation("Equipment added successfully.");
                return Ok(new { Message = "Equipment added successfully.", EquipmentId = equipment.EquipmentID });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to add equipment");
                await transaction.RollbackAsync();
                return StatusCode(500, "An error occurred while adding the equipment.");
            }
        }
    }

    //Endpoint to update equipment
    [Authorize(Policy = "RequireAdministratorRole")]
    [HttpPut("update-equipment")]
    public async Task<IActionResult> UpdateEquipment([FromBody] EquipmentInfo equipment)
    {
        using var transaction = await _dataContext.Database.BeginTransactionAsync();
        try
        {
            var existingEquipment = await _dataContext.Equipment
                .Include(e => e.EquipmentCompatibleModels)
                .ThenInclude(ecm => ecm.CompatibleModel)
                .FirstOrDefaultAsync(e => e.EquipmentID == equipment.EquipmentID);

            if (existingEquipment == null)
            {
                return NotFound(new { Message = "Equipment not found." });
            }

            // Update basic properties
            _dataContext.Entry(existingEquipment).CurrentValues.SetValues(equipment);

            // Handle nested properties (e.g., EquipmentCompatibleModels)
            foreach (var model in equipment.EquipmentCompatibleModels)
            {
                var existingModel = existingEquipment.EquipmentCompatibleModels
                    .FirstOrDefault(m => m.ModelID == model.ModelID);

                if (existingModel == null)
                {
                    existingEquipment.EquipmentCompatibleModels.Add(model);
                }
                else
                {
                    _dataContext.Entry(existingModel).CurrentValues.SetValues(model);
                }
            }

            await _dataContext.SaveChangesAsync();
            await transaction.CommitAsync();
            return Ok(new { Message = "Equipment updated successfully." });
        }
        catch (Exception ex)
        {
            await transaction.RollbackAsync();
            return StatusCode(500, $"An error occurred: {ex.Message}");
        }
    }

    //Endpoint to delete equipment
    [Authorize(Policy = "RequireAdministratorRole")]
    [HttpDelete("delete-equipment/{id}")]
    public async Task<IActionResult> DeleteEquipment(int id)
    {
        //Begin a new database transaction
        using (var transaction = await _dataContext.Database.BeginTransactionAsync())
        {
            try
            {
                //Find the equipment to delete, including related maintenance requests and compatible models
                var equipment = await _dataContext.Equipment
                    .Include(e => e.MaintenanceRequests)
                    .Include(e => e.EquipmentCompatibleModels) // Include related EquipmentCompatibleModels
                    .FirstOrDefaultAsync(e => e.EquipmentID == id);

                if (equipment == null)
                {
                    return NotFound("Equipment not found");
                }

                //Remove related maintenance requests
                if (equipment.MaintenanceRequests.Any())
                {
                    _dataContext.MaintenanceRequests.RemoveRange(equipment.MaintenanceRequests);
                }

                //Remove related EquipmentCompatibleModels
                if (equipment.EquipmentCompatibleModels.Any())
                {
                    _dataContext.EquipmentCompatibleModels.RemoveRange(equipment.EquipmentCompatibleModels);
                }

                //Remove the equipment
                _dataContext.Equipment.Remove(equipment);

                await _dataContext.SaveChangesAsync();
                await transaction.CommitAsync();

                return Ok(new { Message = "Equipment and related records deleted successfully." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to delete equipment");
                await transaction.RollbackAsync();
                return StatusCode(500, $"Failed to delete equipment. Error: {ex.Message}");
            }
        }
    }

    //Endpoint to get all equipment
    [HttpGet("get-all-equipment")]
    public async Task<IActionResult> GetAllEquipment()
    {
        try
        {
            // Retrieve all equipment, including related documents, ordered by location and model number
            var equipmentList = await _dataContext.Equipment
                .Include(e => e.EquipmentDocuments) // Include related documents
                .OrderBy(e => e.Location)
                .ThenBy(e => e.ModelNumber)
                .Select(e => new
                {
                    e.EquipmentID,
                    e.ModelNumber,
                    e.SerialNumber,
                    e.Description,
                    e.LocalEquipmentName,
                    e.Manufacturer,
                    PurchaseDate = e.PurchaseDate.HasValue ? e.PurchaseDate.Value.ToString("yyyy-MM-dd") : "N/A",
                    Cost = e.Cost.HasValue ? e.Cost.Value.ToString("F2") : "0.00",
                    WarrantyExpiration = e.WarrantyExpiration.HasValue ? e.WarrantyExpiration.Value.ToString("yyyy-MM-dd") : "N/A",
                    e.Location,
                    e.Miles,
                    EquipmentDocuments = e.EquipmentDocuments.Select(ed => new
                    {
                        ed.DocumentId,
                        ed.FileName,
                        ed.Keywords,
                        ed.UploadedAt,
                        ed.ContentType
                    }).ToList()
                })
                .ToListAsync();

            return Ok(equipmentList);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to retrieve equipment");
            return StatusCode(500, $"An error occurred while retrieving equipment: {ex.Message}");
        }
    }

    [HttpGet("get-equipment-with-repair-history")]
    public async Task<IActionResult> GetEquipmentWithRepairHistory()
    {
        var equipmentWithRepairHistory = await _dataContext.Equipment
            .Where(e => e.RepairHistories.Any())
            .ToListAsync();

        return Ok(equipmentWithRepairHistory);
    }


    [HttpGet("get-certified-equipment")]
    public async Task<IActionResult> GetCertifiedEquipment()
    {
        var userId = User.FindFirstValue(ClaimTypes.NameIdentifier); // Get the logged-in user's ID

        if (string.IsNullOrEmpty(userId))
        {
            return Unauthorized();
        }

        try
        {
            var certifiedModelIds = await _dataContext.TrainingCertifications
                .Where(tc => tc.UserID == userId)
                .Select(tc => tc.EquipmentModelID)
                .ToListAsync();

            if (!certifiedModelIds.Any())
            {
                return NotFound("No certifications found for this user.");
            }

            var certifiedModelNames = await _dataContext.CompatibleModels
                .Where(cm => certifiedModelIds.Contains(cm.ModelID))
                .Select(cm => cm.ModelName)
                .ToListAsync();

            if (!certifiedModelNames.Any())
            {
                return NotFound("No certified model names found.");
            }

            var certifiedEquipment = await _dataContext.Equipment
                .Where(e => certifiedModelNames.Contains(e.ModelNumber)) // Compare ModelNumber directly as a string
                .ToListAsync();

            if (!certifiedEquipment.Any())
            {
                return NotFound("No certified equipment found for this user.");
            }

            return Ok(certifiedEquipment);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to retrieve certified equipment");
            return StatusCode(500, $"An error occurred while retrieving certified equipment: {ex.Message}");
        }
    }

    //Endpoint to get equipment by ID
    [HttpGet("get-equipment/{id}")]
    public async Task<IActionResult> GetEquipmentById(int id)
    {
        var equipment = await _dataContext.Equipment
            .Where(e => e.EquipmentID == id)
            .Select(e => new EquipmentInfo
            {
                EquipmentID = e.EquipmentID,
                ModelNumber = e.ModelNumber,
                SerialNumber = e.SerialNumber,
                Description = e.Description,
                LocalEquipmentName = e.LocalEquipmentName,
                Manufacturer = e.Manufacturer,
                PurchaseDate = e.PurchaseDate,
                Cost = e.Cost,
                WarrantyExpiration = e.WarrantyExpiration,
                Location = e.Location,
                Miles = e.Miles,
                EquipmentCompatibleModels = e.EquipmentCompatibleModels
                    .Select(ecm => new EquipmentCompatibleModel
                    {
                        EquipmentID = ecm.EquipmentID,
                        ModelID = ecm.ModelID,
                        // Optionally include the CompatibleModel details
                        CompatibleModel = new CompatibleModel
                        {
                            ModelID = ecm.CompatibleModel.ModelID,
                            ModelName = ecm.CompatibleModel.ModelName,
                            Part = ecm.CompatibleModel.Part, // Include Part
                            Equipment = ecm.CompatibleModel.Equipment // Include Equipment
                        }
                    }).ToList()
            })
            .FirstOrDefaultAsync();

        if (equipment == null)
        {
            return NotFound("Equipment not found");
        }

        // Return the equipment details
        return Ok(equipment);
    }

    //Endpoint to update equipment miles
    [HttpPut("update-miles/{id}")]
    public async Task<IActionResult> UpdateMiles(int id, [FromBody] UpdateMilesDTO updateMilesDTO)
    {
        //Check if the ID in the URL matches the ID in the body
        if (id != updateMilesDTO.EquipmentID)
        {
            return BadRequest("Mismatched Equipment ID.");
        }

        //Find the equipment by ID
        var equipment = await _dataContext.Equipment.FindAsync(id);
        if (equipment == null)
        {
            return NotFound();
        }

        // Update the miles and save changes
        equipment.Miles = updateMilesDTO.Miles;
        _dataContext.Equipment.Update(equipment);
        await _dataContext.SaveChangesAsync();

        return NoContent();
    }

    //Endpoint to get the history of a specific piece of equipment
    [HttpGet("{equipmentId}/history")]
    public async Task<IActionResult> GetEquipmentHistory(int equipmentId)
    {
        //Retrieve the equipment by ID, including repair histories
        var equipment = await _dataContext.Equipment
            .Include(e => e.RepairHistories)
            .FirstOrDefaultAsync(e => e.EquipmentID == equipmentId);

        if (equipment == null)
        {
            return NotFound();
        }

        return Ok(equipment);
    }

    //Endpoint to get detailed information about a specific piece of equipment
    [HttpGet("{equipmentId}/details")]
    public async Task<IActionResult> GetEquipmentDetails(int equipmentId)
    {
        //Retrieve the equipment by ID, including repair histories and maintenance records
        var equipment = await _dataContext.Equipment
            .Include(e => e.RepairHistories)
            .Include(e => e.MaintenanceRecords)
            .FirstOrDefaultAsync(e => e.EquipmentID == equipmentId);

        if (equipment == null)
        {
            return NotFound();
        }

        return Ok(equipment);
    }

    //Endpoint to get all equipment that has maintenance requests
    [HttpGet("get-all-equipment-maintenance")]
    public async Task<IActionResult> GetAllEquipmentWithMaintenanceRequests()
    {
        try
        {
            //Retrieve all equipment with maintenance requests, including related equipment
            var equipmentWithMaintenanceRequests = await _dataContext.MaintenanceRequests
                .Include(mr => mr.Equipment) // Ensure related equipment is included
                .Select(mr => mr.Equipment)
                .Distinct()
                .ToListAsync();

            //Serialize the equipment with maintenance requests to JSON
            var options = new JsonSerializerOptions
            {
                ReferenceHandler = ReferenceHandler.Preserve,
                WriteIndented = true
            };

            var json = System.Text.Json.JsonSerializer.Serialize(equipmentWithMaintenanceRequests, options);
            return Ok(json);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to get equipment with maintenance requests");
            return StatusCode(500, "Internal server error");
        }
    }

    //Endpoint to get all unique model numbers of equipment
    [HttpGet("get-all-model-numbers")]
    public async Task<IActionResult> GetAllModelNumbers()
    {
        //Retrieve all unique model numbers of equipment
        var modelNumbers = await _dataContext.Equipment
            .Select(e => e.ModelNumber)
            .Distinct()
            .ToListAsync();
        return Ok(modelNumbers);
    }

    //Endpoint to get compatible models for a given model number
    [HttpGet("{modelNumber}/compatible-models")]
    public async Task<IActionResult> GetCompatibleModels(string modelNumber)
    {
        try
        {
            //Retrieve compatible models by model number, including related EquipmentCompatibleModels
            var compatibleModels = await _dataContext.CompatibleModels
                .Where(cm => cm.ModelName == modelNumber)
                .Include(cm => cm.EquipmentCompatibleModels)
                .ToListAsync();

            if (compatibleModels == null || !compatibleModels.Any())
            {
                return NotFound(new { Message = "No compatible models found for the selected equipment." });
            }

            //Serialize the compatible models to JSON
            var jsonOptions = new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                WriteIndented = true,
                ReferenceHandler = ReferenceHandler.Preserve // Ensure references are preserved
            };

            var jsonResponse = JsonSerializer.Serialize(compatibleModels, jsonOptions);
            return Ok(jsonResponse);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error fetching compatible models: {ex.Message}");
            return StatusCode(500, new { Message = "Internal server error", Error = ex.Message });
        }
    }
}