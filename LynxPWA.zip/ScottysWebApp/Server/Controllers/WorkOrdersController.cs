﻿using Microsoft.AspNetCore.Mvc;
using ScottysWebApp.Server.Data;
using ScottysWebApp.Server.Models.Plant;
using Microsoft.EntityFrameworkCore;
using ScottysWebApp.Server.Models.PartModel;

namespace ScottysWebApp.Server.Controllers
{
    [ApiController]
    [Route("api/work-orders")]
    public class WorkOrdersController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<WorkOrdersController> _logger;

        public WorkOrdersController(ApplicationDbContext context, ILogger<WorkOrdersController> logger)
        {
            _context = context;
            _logger = logger;
        }

        // Create a new work order
        [HttpPost("create")]
        public async Task<IActionResult> CreateWorkOrder([FromBody] WorkOrderRequest workOrderRequest)
        {
            if (workOrderRequest == null)
            {
                return BadRequest("Invalid work order request data.");
            }

            // Ensure default values for nullable fields
            workOrderRequest.Priority = string.IsNullOrEmpty(workOrderRequest.Priority) ? "Low" : workOrderRequest.Priority;
            workOrderRequest.Status = string.IsNullOrEmpty(workOrderRequest.Status) ? "Pending" : workOrderRequest.Status;
            workOrderRequest.Corrections = string.IsNullOrEmpty(workOrderRequest.Corrections) ? string.Empty : workOrderRequest.Corrections;

            try
            {
                // Store the work order request, including the image data and file name
                _context.WorkOrderRequests.Add(workOrderRequest);
                await _context.SaveChangesAsync();

                return Ok(new { Message = "Work order created successfully." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to create work order");
                return StatusCode(500, "Internal server error.");
            }
        }

        // Get all work orders
        [HttpGet("get-all")]
        public async Task<IActionResult> GetAllWorkOrders()
        {
            try
            {
                var workOrders = await _context.WorkOrderRequests
                    .Include(wo => wo.SelectedPart)
                    .Where(wo => wo.Status != "Repair Completed" &&
                                 wo.Status != "Completed" &&
                                 wo.Status != "Operational") // Filter out unwanted statuses
                    .Select(wo => new
                    {
                        wo.RequestID,
                        OperatorName = wo.OperatorName ?? "N/A",
                        Date = wo.Date.ToString("yyyy-MM-dd"),
                        wo.Priority,
                        wo.Status,
                        wo.PlantID,
                        WhereOccurred = wo.WhereOccurred ?? "N/A",
                        WhenOccurred = wo.WhenOccurred.HasValue ? wo.WhenOccurred.Value.ToString("yyyy-MM-dd") : "N/A",
                        DeficienciesIssues = wo.DeficienciesIssues ?? "N/A",
                        Comments = wo.Comments ?? string.Empty,
                        OperatorSignature = wo.OperatorSignature,
                        ImageFileName = wo.ImageFileName ?? string.Empty,
                        ImageData = wo.ImageData ?? Array.Empty<byte>(),
                        CorrectionStartDate = wo.CorrectionStartDate.HasValue ? wo.CorrectionStartDate.Value.ToString("yyyy-MM-dd") : "N/A",
                        Corrections = wo.Corrections ?? string.Empty,
                        MechanicHours = wo.MechanicHours ?? 0,
                        MaintenanceSignature = wo.MaintenanceSignature,
                        SelectedPart = wo.SelectedPart.Select(p => new
                        {
                            p.PartID,
                            p.PartName,
                            p.QuantityUsed
                        }).ToList()
                    })
                    .ToListAsync();

                return Ok(workOrders);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to retrieve work orders");
                return StatusCode(500, "Internal server error.");
            }
        }

        // Get a specific work order by ID
        [HttpGet("{id}")]
        public async Task<IActionResult> GetWorkOrderById(int id)
        {
            var workOrder = await _context.WorkOrderRequests
                .Include(w => w.Plant)
                .FirstOrDefaultAsync(w => w.RequestID == id);

            if (workOrder == null)
            {
                return NotFound("Work order not found.");
            }

            return Ok(new
            {
                workOrder.RequestID,
                workOrder.OperatorName,
                workOrder.Priority,
                workOrder.WhereOccurred,
                workOrder.WhenOccurred,  // Keep nullable
                workOrder.DeficienciesIssues,
                workOrder.PlantID,
                workOrder.Comments,
                workOrder.OperatorSignature,
                workOrder.Date,
                workOrder.Status,
                workOrder.CorrectionStartDate,  // Keep nullable
                workOrder.Corrections,
                workOrder.MechanicHours,
                workOrder.MaintenanceSignature,
                workOrder.ImageFileName,
                workOrder.ImageData
            });
        }

        [HttpPut("update/{id}")]
        public async Task<IActionResult> UpdateWorkOrder(int id, [FromBody] WorkOrderRequest updatedRequest)
        {
            var existingRequest = await _context.WorkOrderRequests
                .Include(w => w.SelectedPart.Where(sp => sp.RepairID == null)) // Only include parts without RepairID
                .FirstOrDefaultAsync(w => w.RequestID == id);

            if (existingRequest == null) return NotFound("Work order not found.");

            // Update allowed fields
            existingRequest.Priority = updatedRequest.Priority;
            existingRequest.Status = updatedRequest.Status;
            existingRequest.DeficienciesIssues = updatedRequest.DeficienciesIssues;
            existingRequest.CorrectionStartDate = updatedRequest.CorrectionStartDate;
            existingRequest.Corrections = updatedRequest.Corrections;
            existingRequest.MechanicHours = updatedRequest.MechanicHours;
            existingRequest.MaintenanceSignature = updatedRequest.MaintenanceSignature;
            existingRequest.CompletedDate = updatedRequest.CompletedDate;

            // Process parts for the work order
            foreach (var part in updatedRequest.SelectedPart)
            {
                // Ensure each part has the correct RequestID
                part.RequestID = id;

                if (part.SelectedPartID == 0) // Assuming 0 or absence of ID signifies a new part
                {
                    // Add new parts explicitly
                    _context.SelectedPart.Add(part);
                }
                else
                {
                    // Update existing parts
                    _context.Entry(part).State = EntityState.Modified;
                }
            }

            await _context.SaveChangesAsync();

            return Ok();
        }

        [HttpPut("save-to-selected-parts/{id}")]
        public async Task<IActionResult> SaveToSelectedParts(int id, [FromBody] WorkOrderRequest updatedRequest)
        {
            var existingRequest = await _context.WorkOrderRequests
                .Include(w => w.WorkOrderSelectedPart)  // Ensure the correct inclusion of the collection
                .FirstOrDefaultAsync(w => w.RequestID == id);

            if (existingRequest == null)
            {
                return NotFound("Work order not found. Please create the work order before adding parts.");
            }

            // Iterate over each part in the updated request
            foreach (var part in updatedRequest.WorkOrderSelectedPart)
            {
                var existingPart = existingRequest.WorkOrderSelectedPart.FirstOrDefault(p => p.PartID == part.PartID);
                if (existingPart != null)
                {
                    // If part exists, update its quantity
                    existingPart.QuantityUsed = part.QuantityUsed;
                    _context.Entry(existingPart).State = EntityState.Modified;
                }
                else
                {
                    // Add new part if it doesn't exist in WorkOrderSelectedParts
                    existingRequest.WorkOrderSelectedPart.Add(new WorkOrderSelectedPart
                    {
                        RequestID = id,
                        PartID = part.PartID,
                        QuantityUsed = part.QuantityUsed,
                        DateAdded = DateTime.Now
                    });
                }
            }

            try
            {
                await _context.SaveChangesAsync();
                return Ok("Parts saved to WorkOrderSelectedParts.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to save parts to WorkOrderSelectedParts");
                return StatusCode(500, "An error occurred while saving parts.");
            }
        }

        [HttpGet("get-all-records")]
        public async Task<IActionResult> GetWorkOrderRecords()
        {
            try
            {


                var records = await _context.WorkOrderRecords
                    .Include(r => r.WorkOrderRecordParts) // Include parts used for this record
                    .Include(r => r.SelectedPart) // Include additional parts
                    .Select(r => new
                    {
                        r.RecordID,
                        r.OperatorName,
                        r.Priority,
                        r.Status,
                        r.DeficienciesIssues,
                        r.Corrections,
                        r.MechanicHours,
                        r.PlantID,
                        r.Date,
                        r.CompletedDate,
                        r.ImageData,
                        r.ImageFileName,
                        PartsUsed = r.WorkOrderRecordParts.Select(p => new
                        {
                            p.PartID,
                            p.PartName,
                            p.QuantityUsed
                        }),
                        AdditionalParts = r.SelectedPart.Select(sp => new
                        {
                            sp.PartID,
                            sp.PartName,
                            sp.QuantityUsed
                        })
                    })
                    .ToListAsync();

                return Ok(records);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to retrieve work order records");
                return StatusCode(500, "Internal server error.");
            }
        }

        [HttpPut("complete/{id}")]
        public async Task<IActionResult> CompleteWorkOrder(int id, [FromBody] WorkOrderRequest updatedRequest)
        {
            _logger.LogInformation($"Completing work order with ID: {id}");

            if (!updatedRequest.CompletedDate.HasValue)
                return BadRequest("Completion date is required.");

            var existingRequest = await _context.WorkOrderRequests
                .Include(w => w.SelectedPart)
                .ThenInclude(sp => sp.Part)
                .FirstOrDefaultAsync(r => r.RequestID == id);

            if (existingRequest == null)
                return NotFound("Work order request not found.");

            var workOrderRecord = new WorkOrderRecord
            {
                RequestID = existingRequest.RequestID,
                OperatorName = existingRequest.OperatorName,
                Priority = existingRequest.Priority,
                WhereOccurred = existingRequest.WhereOccurred,
                WhenOccurred = existingRequest.WhenOccurred,
                DeficienciesIssues = existingRequest.DeficienciesIssues,
                PlantID = existingRequest.PlantID,
                Comments = existingRequest.Comments,
                OperatorSignature = existingRequest.OperatorSignature,
                Date = existingRequest.Date,
                ImageData = existingRequest.ImageData,
                ImageFileName = existingRequest.ImageFileName,
                Status = "Completed",
                CorrectionStartDate = updatedRequest.CorrectionStartDate,
                Corrections = updatedRequest.Corrections,
                MechanicHours = updatedRequest.MechanicHours,
                MaintenanceSignature = updatedRequest.MaintenanceSignature,
                CompletedDate = updatedRequest.CompletedDate
            };

            _context.WorkOrderRecords.Add(workOrderRecord);
            await _context.SaveChangesAsync();
            int generatedRecordID = workOrderRecord.RecordID;

            // Retrieve selected parts
            var selectedParts = await _context.WorkOrderSelectedPart
                .Where(sp => sp.RequestID == id)
                .Include(sp => sp.Part)
                .ToListAsync();

            if (selectedParts.Any(p => p.WorkOrderSelectedPartID == 0))
            {
                await _context.SaveChangesAsync(); // Ensure all parts have permanent IDs
                _logger.LogInformation($"Temporary IDs for parts resolved.");
            }

            foreach (var part in selectedParts)
            {
                _context.WorkOrderParts.Add(new WorkOrderPart
                {
                    RecordID = generatedRecordID,
                    PartID = part.PartID,
                    PartName = part.Part.PartName,
                    QuantityUsed = part.QuantityUsed
                });
            }

            _context.WorkOrderSelectedPart.RemoveRange(selectedParts);
            await _context.SaveChangesAsync();

            existingRequest.Status = "Completed";
            existingRequest.CompletedDate = updatedRequest.CompletedDate;
            existingRequest.MaintenanceSignature = updatedRequest.MaintenanceSignature;

            await _context.SaveChangesAsync();

            return Ok("Work order completed successfully and parts transferred.");
        }
    }
}