﻿using Microsoft.AspNetCore.Identity;

namespace ScottysWebApp.Server.Services
{
    public class CreateRoles
    {
        //Ensures that the specified roles are created in the Identity system.
        public static void EnsureRolesCreated(IServiceProvider serviceProvider)
        {
            //Create a new scope to get required services.
            using (var scope = serviceProvider.CreateScope())
            {
                //Get the RoleManager service from the service provider.
                var roleManager = scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>();

                //List of roles to be created.
                var roles = new List<string> { "Guest", "User", "PartsManager", "Mechanic", "Maintenance", "Admin" };

                //Loop through each role in the list.
                foreach (var role in roles)
                {
                    //Check if the role already exists.
                    if (!roleManager.RoleExistsAsync(role).Result)
                    {
                        //If the role does not exist, create it.
                        roleManager.CreateAsync(new IdentityRole(role)).Wait();
                    }
                }
            }
        }
    }
}
