﻿using Microsoft.EntityFrameworkCore;
using ScottysWebApp.Server.Data;
using ScottysWebApp.Server.Interfaces;
using ScottysWebApp.Server.Models.App;

namespace ScottysWebApp.Server.Services
{
    //TokenService class implements ITokenService interface to manage password reset tokens
    public class TokenService : ITokenService
    {
        //Database context for accessing the database
        private readonly ApplicationDbContext _context;

        //Initialize the token service with the database context
        public TokenService(ApplicationDbContext context)
        {
            _context = context;
        }

        //Store a password reset token in the database
        public async Task StoreResetTokenAsync(string userId, string token, DateTime expirationTime)
        {
            //Create a new PasswordResetToken entity with the provided userId, token, and expiration time
            var tokenEntity = new PasswordResetToken
            {
                UserId = userId,
                Token = token,
                ExpirationTime = expirationTime
            };

            //Add the token entity to the database context
            _context.PasswordResetTokens.Add(tokenEntity);
            //Save the changes to the database asynchronously
            await _context.SaveChangesAsync();
        }

        //Retrieve a password reset token from the database based on userId
        public async Task<TokenData> GetResetTokenAsync(string userId)
        {
            //Query the database for the password reset token associated with the specified userId
            var tokenEntity = await _context.PasswordResetTokens
                .FirstOrDefaultAsync(t => t.UserId == userId);


            //If no token entity is found, return null
            if (tokenEntity == null)
            {
                return null;
            }

            //Return a TokenData object with the token and expiration time from the database
            return new TokenData
            {
                Token = tokenEntity.Token,
                ExpirationTime = tokenEntity.ExpirationTime
            };
        }

        //Delete a password reset token from the database based on userId
        public async Task DeleteResetTokenAsync(string userId)
        {
            //Query the database for the password reset token associated with the specified userId
            var tokenEntity = await _context.PasswordResetTokens
                .FirstOrDefaultAsync(t => t.UserId == userId);

            //If a token entity is found, remove it from the database context
            if (tokenEntity != null)
            {
                _context.PasswordResetTokens.Remove(tokenEntity);
                //Save the changes to the database asynchronously
                await _context.SaveChangesAsync();
            }
        }
    }
}