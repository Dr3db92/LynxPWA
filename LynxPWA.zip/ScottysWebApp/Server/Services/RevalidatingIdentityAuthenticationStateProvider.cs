﻿using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.AspNetCore.Identity;
using System.Security.Claims;

namespace ScottysWebApp.Server.Services
{
    public class RevalidatingIdentityAuthenticationStateProvider<TUser> : AuthenticationStateProvider, IDisposable where TUser : IdentityUser
    {
        private readonly UserManager<TUser> _userManager;
        private readonly SignInManager<TUser> _signInManager;
        //30 minute interval
        private readonly TimeSpan _revalidationInterval = TimeSpan.FromMinutes(30);
        //Timer to trigger revalidation
        private Timer _timer;

        //Inititialize the user manager and the sign in manager and the timer
        public RevalidatingIdentityAuthenticationStateProvider(UserManager<TUser> userManager, SignInManager<TUser> signInManager)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _timer = new Timer(Callback, null, _revalidationInterval, _revalidationInterval);
        }

        //Callback method executed periodically by the timer to revalidate the user's identity
        private async void Callback(object state)
        {
            var claimsPrincipal = _signInManager.Context.User;

            //Check if the user is authenticated
            if (claimsPrincipal.Identity.IsAuthenticated)
            {
                //Retrieve the user from UserManager
                var identityUser = await _userManager.GetUserAsync(claimsPrincipal);
                if (identityUser != null)
                {
                    //Get the security stamp from claims
                    var securityStampInClaims = claimsPrincipal.Claims.FirstOrDefault(c => c.Type == "AspNet.Identity.SecurityStamp")?.Value;
                    if (securityStampInClaims != identityUser.SecurityStamp)
                    {
                        //If they don't match, notify that the authentication state has changed to an anonymous state
                        var anonymous = new ClaimsPrincipal(new ClaimsIdentity());
                        NotifyAuthenticationStateChanged(Task.FromResult(new AuthenticationState(anonymous)));
                    }
                }
            }
        }

        //Override to get the current authentication state asynchronously
        public override async Task<AuthenticationState> GetAuthenticationStateAsync()
        {
            var identity = new ClaimsIdentity();
            //Check if the user is authenticated
            if (_signInManager.Context?.User?.Identity?.IsAuthenticated == true)
            {
                //Retrieve the user from UserManager
                var user = await _userManager.GetUserAsync(_signInManager.Context.User);
                if (user != null)
                {
                    //Create claims identity with the user's name
                    var claims = new[] { new Claim(ClaimTypes.Name, user.UserName) };
                    identity = new ClaimsIdentity(claims, "Identity.Application");
                }
            }
            //Return the authentication state
            return new AuthenticationState(new ClaimsPrincipal(identity));
        }

        //Dispose method to clean up the timer
        public void Dispose()
        {
            _timer?.Dispose();
        }
    }
}