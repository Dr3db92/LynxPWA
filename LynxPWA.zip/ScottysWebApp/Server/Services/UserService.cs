﻿using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Caching.Memory;
using ScottysWebApp.Server.Interfaces;
using ScottysWebApp.Server.Models.User;

namespace ScottysWebApp.Server.Services
{
    //Implements the IUserService interface to manage user-related operations
    public class UserService : IUserService
    {
        private readonly UserManager<IdentityUser> _userManager;
        private readonly IMemoryCache _memoryCache;

        //Initialize user manager and the memory cache
        public UserService(UserManager<IdentityUser> userManager, IMemoryCache memoryCache)
        {
            _userManager = userManager;
            _memoryCache = memoryCache;
        }

        //Get the roles of a user and cache them
        public async Task<List<string>> GetUserRolesAsync(IdentityUser user)
        {
            //Cache key based on user ID
            var cacheKey = $"UserRoles-{user.Id}";

            //Try to get the roles from the cache or create a new cache entry if not present
            var roles = await _memoryCache.GetOrCreateAsync(cacheKey, async entry =>
            {
                //Set cache expiration time
                entry.AbsoluteExpirationRelativeToNow = TimeSpan.FromHours(1);
                //Get roles from user manager
                return await _userManager.GetRolesAsync(user);
            });
            //Convert roles to a list and return
            return roles.ToList();
        }

        //Create a new user
        public async Task<IdentityResult> CreateUserAsync(RegisterDTO registerDto)
        {
            //Create a new IdentityUser with the provided username and email from the DTO
            var user = new IdentityUser { UserName = registerDto.Username, Email = registerDto.Username };

            //Create the user with the provided password and return the result
            return await _userManager.CreateAsync(user, registerDto.Password);
        }

        //Check if a user is locked out
        public async Task<bool> CheckUserLockoutAsync(string username)
        {
            //Find the user by username
            var user = await _userManager.FindByNameAsync(username);

            //Check if the user is locked out and return the result
            return await _userManager.IsLockedOutAsync(user);
        }
    }
}