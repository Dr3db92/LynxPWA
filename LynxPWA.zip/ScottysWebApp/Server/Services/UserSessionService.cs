﻿using ScottysWebApp.Client.Models.Users;
using ScottysWebApp.Server.Data;
using System.Collections.Concurrent;

namespace ScottysWebApp.Server.Services
{
    public class UserSessionService
    {
        private static ConcurrentDictionary<string, Models.UserInteractionModel> activeUsers = new ConcurrentDictionary<string, Models.UserInteractionModel>();

        // Method to update user activity
        public void UpdateUserActivity(string userName, Models.UserInteractionModel interaction)
        {
            activeUsers.AddOrUpdate(interaction.UserName, interaction, (key, existingValue) =>
            {
                existingValue.LastActivity = interaction.LastActivity;
                return existingValue;
            });
        }

        // Method to get all active users (optional)
        public List<Models.UserInteractionModel> GetActiveUsers()
        {
            // Optionally, filter users that have interacted in the last 5 minutes
            var cutoffTime = DateTime.Now.AddMinutes(-5);
            return activeUsers.Values
                .Where(e => e.LastActivity > cutoffTime)
                .ToList();
        }
    }
}
