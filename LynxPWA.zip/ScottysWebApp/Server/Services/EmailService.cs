﻿using Google.Apis.Auth.OAuth2;
using Google.Apis.Auth.OAuth2.Flows;
using Google.Apis.Auth.OAuth2.Responses;
using Google.Apis.Gmail.v1;
using Google.Apis.Services;
using Microsoft.Extensions.Options;
using MimeKit;
using ScottysWebApp.Server.Interfaces;
using ScottysWebApp.Server.Models;
using ScottysWebApp.Server.Models.App;

namespace ScottysWebApp.Server.Services
{
    //The EmailService class implements the IEmailService interface to provide email sending functionality using the Gmail API
    public class EmailService : IEmailService
    {
        //Holds the email configuration settings
        private readonly EmailSettings _emailSettings;

        //Constructor to initialize the EmailService with email settings injected through IOptions
        public EmailService(IOptions<EmailSettings> emailSettings)
        {
            _emailSettings = emailSettings.Value;
        }

        //Send an email asynchronously
        public async Task SendEmailAsync(string email, string subject, string message)
        {
            if (string.IsNullOrWhiteSpace(email))
            {
                //Validate recipient email address
                throw new ArgumentNullException(nameof(email), "Recipient email address cannot be null or empty.");
            }

            if (string.IsNullOrWhiteSpace(_emailSettings.SenderEmail))
            {
                //Validate sender email address from settings
                throw new ArgumentNullException(nameof(_emailSettings.SenderEmail), "Sender email address cannot be null or empty.");
            }

            //Get Google credential for sending email
            var credential = await GetGoogleCredentialAsync();

            //Initialize GmailService with the obtained credential
            var service = new GmailService(new BaseClientService.Initializer()
            {
                HttpClientInitializer = credential,
                ApplicationName = this.GetType().ToString()
            });

            //Create a MimeMessage for the email
            var emailMessage = new MimeMessage();
            emailMessage.From.Add(new MailboxAddress(_emailSettings.SenderName, _emailSettings.SenderEmail));
            emailMessage.To.Add(MailboxAddress.Parse(email));
            emailMessage.Subject = subject;
            emailMessage.Body = new TextPart("html") { Text = message };

            //Encode the MimeMessage to a base64url string
            var msg = new Google.Apis.Gmail.v1.Data.Message
            {
                Raw = EncodeToBase64Url(emailMessage)
            };

            //Send the email using the Gmail API
            await service.Users.Messages.Send(msg, "me").ExecuteAsync();
        }

        //Get Google credential using OAuth2 flow and refresh token
        private async Task<GoogleCredential> GetGoogleCredentialAsync()
        {
            var flow = new GoogleAuthorizationCodeFlow(new GoogleAuthorizationCodeFlow.Initializer
            {
                ClientSecrets = new ClientSecrets
                {
                    ClientId = _emailSettings.ClientId,
                    ClientSecret = _emailSettings.ClientSecret
                },
                //Specify the scopes required for sending email via Gmail API
                Scopes = new[] { "https://www.googleapis.com/auth/gmail.send", "https://localhost:7119/signin-google", "https://localhost:7119/", "https://mail.google.com", "https://localhost:7119/account" }
            });

            //Create the token response using the refresh token from settings
            var token = new TokenResponse { RefreshToken = _emailSettings.RefreshToken };

            //Create the user credential from the flow and the token
            var credential = new UserCredential(flow, "user", token);

            //Refresh the token to ensure it is valid and get an access token
            await credential.RefreshTokenAsync(CancellationToken.None);
            return GoogleCredential.FromAccessToken(credential.Token.AccessToken);
        }

        //Encode a MimeMessage to a base64url string
        private string EncodeToBase64Url(MimeMessage message)
        {
            using (var stream = new MemoryStream())
            {
                message.WriteTo(stream);
                //Convert the stream to a base64 string and replace characters to match base64url encoding
                return Convert.ToBase64String(stream.GetBuffer(), 0, (int)stream.Length)
                    .Replace('+', '-').Replace('/', '_').Replace("=", "");
            }
        }
    }
}
