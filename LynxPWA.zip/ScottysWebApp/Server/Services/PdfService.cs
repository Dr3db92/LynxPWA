﻿using iText.IO.Image;
using iText.Kernel.Pdf;
using iText.Layout;
using iText.Layout.Borders;
using iText.Layout.Element;
using iText.Layout.Properties;
using ScottysWebApp.Server.Interfaces;
using ScottysWebApp.Server.Models.Forms;
using System.Globalization;
using ScottysWebApp.Server.Models.User;

public class PdfService : IPdfService
{
    //Method to generate a PDF document based on the given DTO (Data Transfer Object)
    public async Task<Stream> GeneratePdf(object dto)
    {
        // Initialize memory stream to hold the generated PDF
        MemoryStream pdfStream = new MemoryStream();

        try
        {
            // Initialize PdfWriter with the memory stream and prevent closing the stream when the writer is closed
            var writer = new PdfWriter(pdfStream);
            writer.SetCloseStream(false);

            using (var pdf = new PdfDocument(writer))
            {
                using (var document = new Document(pdf))
                {
                    // Type-checking for each DTO type and calling the appropriate generation method
                    switch (dto)
                    {
                        case PreOpChecklistDTO preOpChecklistDto:
                            GeneratePreOpChecklistPdfContent(document, preOpChecklistDto);
                            break;

                        case WorkplaceChecklistDTO checklistDto:
                            GenerateWorkplaceChecklistPdfContent(document, checklistDto);
                            break;

                        case AreasWorkingDTO areasWorkingDto:
                            GenerateAreasWorkingPdfContent(document, areasWorkingDto);
                            break;

                        //case TrainingCertifications trainingCert:
                        //    GenerateTrainingCertificationPdfContent(document, trainingCert);
                        //    break;

                        default:
                            throw new ArgumentException($"Unsupported DTO type: {dto.GetType().Name}", nameof(dto));
                    }
                }
            }

            // Reset stream position to the beginning to ensure the PDF content is ready for reading
            pdfStream.Position = 0;
            return pdfStream;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error generating PDF: {ex.Message}");
            throw;
        }
    }

    //private void GenerateTrainingCertificationPdfContent(Document document, TrainingCertifications trainingCert)
    //{
    //    document.Add(new Paragraph("Training Certification")
    //        .SetTextAlignment(TextAlignment.CENTER)
    //        .SetFontSize(18)
    //        .SetBold());

    //    document.Add(new Paragraph($"User ID: {trainingCert.UserID}"));
    //    document.Add(new Paragraph($"Equipment Model ID: {trainingCert.EquipmentModelID}"));
    //    document.Add(new Paragraph($"Certification Date: {trainingCert.CertificationDate.ToShortDateString()}"));
    //    //document.Add(new Paragraph($"Signature: {trainingCert.Signature}"));
    //}

    //Generate PDF content for a Workplace Checklist
    public void GenerateWorkplaceChecklistPdfContent(Document document, WorkplaceChecklistDTO checklistDto)
    {
        document.Add(new Paragraph("Workplace Exam Checklist")
            .SetTextAlignment(TextAlignment.CENTER)
            .SetFontSize(16)
            .SetBold()
            .SetUnderline()
            .SetMarginBottom(10));

        var metadataTable = new Table(UnitValue.CreatePercentArray(new float[] { 1, 1 })).UseAllAvailableWidth();
        metadataTable.AddCell(new Cell().Add(new Paragraph($"Operator Name: {checklistDto.OperatorName}").SetBold()));
        metadataTable.AddCell(new Cell().Add(new Paragraph($"Inspection Area: {checklistDto.InspectionArea}").SetBold()));
        document.Add(metadataTable);

        var table = new Table(UnitValue.CreatePercentArray(new float[] { 4, 1, 5 })).UseAllAvailableWidth().SetMarginBottom(10);
        table.AddHeaderCell("Inspection Points").AddHeaderCell("OK").AddHeaderCell("Deficiencies");

        foreach (var item in checklistDto.InspectionItems)
        {
            table.AddCell(new Paragraph(item.InspectionText));

            // Check if OK or DEF is selected, and display it in the status column
            string status = item.IsOkSelected ? "OK" : item.IsDefSelected ? "DEF" : "";
            table.AddCell(new Paragraph(status));

            // Display any deficiencies found
            table.AddCell(new Paragraph(item.DeficienciesFound ?? ""));
        }
        document.Add(table);

        if (!string.IsNullOrWhiteSpace(checklistDto.Comments))
        {
            document.Add(new Paragraph("Comments:").SetBold().SetUnderline());
            document.Add(new Paragraph(checklistDto.Comments));
        }

        var signatureTable = new Table(UnitValue.CreatePercentArray(new float[] { 1, 2, 1, 2 })).UseAllAvailableWidth();
        signatureTable.AddCell(new Cell().Add(new Paragraph("Operator Signature:").SetBold()));
        // Display Operator Signature, if present
        if (checklistDto.OperatorSignature != null && checklistDto.OperatorSignature.Length > 0)
        {
            var signatureImageData = ImageDataFactory.Create(checklistDto.OperatorSignature);
            var signatureImage = new Image(signatureImageData).SetHeight(75).SetWidth(150).SetMarginTop(10);
            document.Add(new Paragraph("Operator Signature:").SetBold());
            document.Add(signatureImage);
        }
        document.Add(new Paragraph($"Date: {checklistDto.Date.ToShortDateString()}"));
    }

    //Generate PDF content for an Areas Working form
    public void GenerateAreasWorkingPdfContent(Document document, AreasWorkingDTO workingDto)
    {
        //Create a table for the document header
        Table table = new Table(new float[] { 6, 1 })
            .UseAllAvailableWidth();

        Cell textCell = new Cell()
            .SetBorder(Border.NO_BORDER)
            .Add(new Paragraph("Workplace Exam Checklist")
                    .SetTextAlignment(TextAlignment.RIGHT)
                    .SetFontSize(16)
                    .SetBold()
                    .SetUnderline())
            .SetTextAlignment(TextAlignment.RIGHT);
        table.AddCell(textCell);

        //Add the company logo to the header
        string imagePath = "Images/LargeLynxLogo-Black-Small.png";
        ImageData imageData = ImageDataFactory.Create(imagePath);
        Cell imageCell = new Cell()
            .SetBorder(Border.NO_BORDER)
            .Add(new Image(imageData)
                    .SetHeight(75)
                    .SetWidth(75)
                    .SetHorizontalAlignment(HorizontalAlignment.RIGHT))
            .SetTextAlignment(TextAlignment.RIGHT);
        table.AddCell(imageCell);
        document.Add(table);


        //Add operator name
        Text operatorNameLabel = new Text("Operator Name: ")
          .SetUnderline()
          .SetBold();
        Paragraph operatorNameParagraph = new Paragraph()
            .Add(operatorNameLabel)
            .Add(new Text(workingDto.OperatorName ?? ""))
            .SetMarginBottom(10)
            .SetUnderline();
        document.Add(operatorNameParagraph);

        //Add areas working section
        document.Add(new Paragraph("Areas Working:")
            .SetBold()
            .SetMarginTop(10)
            .SetUnderline());
        document.Add(new Paragraph(workingDto.AreasWorking).SetMarginBottom(10));

        //Add deficiencies section if present
        if (!workingDto.NoDeficienciesFound && workingDto.Deficiencies != null && workingDto.Deficiencies.Any())
        {
            document.Add(new Paragraph("Deficiencies Found:")
                .SetBold()
                .SetMarginTop(10));

            var deficienciesTable = new Table(new float[] { 1, 3, 1, 3 }).UseAllAvailableWidth();
            deficienciesTable.AddHeaderCell("Date Corrected")
                .AddHeaderCell("Deficiencies Found")
                .AddHeaderCell("Comments");

            foreach (var deficiency in workingDto.Deficiencies)
            {
                deficienciesTable.AddCell(new Cell().Add(new Paragraph(deficiency.DateCorrected.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture))));
                deficienciesTable.AddCell(new Cell().Add(new Paragraph(deficiency.DeficienciesFound ?? string.Empty)));
                deficienciesTable.AddCell(new Cell().Add(new Paragraph(deficiency.Comments)));
            }
            document.Add(deficienciesTable);
        }
        else
        {
            document.Add(new Paragraph("No deficiencies were found.")
                .SetItalic()
                .SetMarginTop(10));
        }

        //Add operator signature
        var signatureTable = new Table(UnitValue.CreatePercentArray(new float[] { 1, 2, 1, 2 })).UseAllAvailableWidth();
        signatureTable.AddCell(new Cell().Add(new Paragraph("Operator Signature:").SetBold()));
        // Display Operator Signature, if present
        if (workingDto.OperatorSignature != null && workingDto.OperatorSignature.Length > 0)
        {
            var signatureImageData = ImageDataFactory.Create(workingDto.OperatorSignature);
            var signatureImage = new Image(signatureImageData).SetHeight(75).SetWidth(150).SetMarginTop(10);
            document.Add(new Paragraph("Operator Signature:").SetBold());
            document.Add(signatureImage);
        }

        //Add date
        document.Add(new Paragraph($"Date: {workingDto.Date.ToShortDateString()}")
            .SetMarginTop(10)
            .SetBold()
            .SetUnderline());
    }

    //Generate PDF content for a Pre-Operation Checklist
    public void GeneratePreOpChecklistPdfContent(Document document, PreOpChecklistDTO checklistDto)
    {
        try
        {
            document.Add(new Paragraph("Pre-Operation Checklist")
                .SetTextAlignment(TextAlignment.CENTER)
                .SetFontSize(18)
                .SetBold()
                .SetUnderline()
                .SetMarginBottom(10));

            var metadataTable = new Table(UnitValue.CreatePercentArray(new float[] { 1, 2, 1, 2 })).UseAllAvailableWidth();
            metadataTable.AddCell(new Cell().Add(new Paragraph("Operator Name:").SetBold()));
            metadataTable.AddCell(new Cell().Add(new Paragraph(checklistDto.OperatorName ?? "")));
            metadataTable.AddCell(new Cell().Add(new Paragraph("Equipment:").SetBold()));
            metadataTable.AddCell(new Cell().Add(new Paragraph(checklistDto.Equipment ?? "")));
            metadataTable.AddCell(new Cell().Add(new Paragraph("Start Mileage/Hours:").SetBold()));
            metadataTable.AddCell(new Cell().Add(new Paragraph(checklistDto.Start.ToString())));
            metadataTable.AddCell(new Cell().Add(new Paragraph("Stop Mileage/Hours:").SetBold()));
            metadataTable.AddCell(new Cell().Add(new Paragraph(checklistDto.Stop.ToString())));
            document.Add(metadataTable);

            var componentsTable = new Table(UnitValue.CreatePercentArray(new float[] { 3, 2, 5 })).UseAllAvailableWidth().SetMarginTop(10);
            componentsTable.AddHeaderCell(new Cell().Add(new Paragraph("Component").SetBold()));
            componentsTable.AddHeaderCell(new Cell().Add(new Paragraph("Status").SetBold()));
            componentsTable.AddHeaderCell(new Cell().Add(new Paragraph("Comments").SetBold()));

            foreach (var item in checklistDto.ComponentItems)
            {
                componentsTable.AddCell(new Cell().Add(new Paragraph(item.ComponentText)));
                componentsTable.AddCell(new Cell().Add(new Paragraph(item.Status)));
                componentsTable.AddCell(new Cell().Add(new Paragraph(item.Comment ?? "")));
            }
            document.Add(componentsTable);

            document.Add(new Paragraph("Comments:")
                .SetBold().SetUnderline().SetMarginTop(10));
            document.Add(new Paragraph(checklistDto.Comments ?? ""));

            var signatureTable = new Table(UnitValue.CreatePercentArray(new float[] { 1, 2, 1, 2 })).UseAllAvailableWidth();
            signatureTable.AddCell(new Cell().Add(new Paragraph("Operator Signature:").SetBold()));
            // Display Operator Signature, if present
            if (checklistDto.OperatorSignature != null && checklistDto.OperatorSignature.Length > 0)
            {
                var signatureImageData = ImageDataFactory.Create(checklistDto.OperatorSignature);
                var signatureImage = new Image(signatureImageData).SetHeight(75).SetWidth(150).SetMarginTop(10);
                document.Add(new Paragraph("Operator Signature:").SetBold());
                document.Add(signatureImage);
            }

            //Add date
            document.Add(new Paragraph($"Date: {checklistDto.Date.ToShortDateString()}")
                .SetMarginTop(10)
                .SetBold()
                .SetUnderline());
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error generating PDF: {ex.Message}");
            throw;
        }
    }
}