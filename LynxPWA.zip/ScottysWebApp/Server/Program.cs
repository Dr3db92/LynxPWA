using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.Google;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using ScottysWebApp.Server.Data;
using ScottysWebApp.Server.Interfaces;
using ScottysWebApp.Server.Models.App;
using ScottysWebApp.Server.Services;
using Serilog;
using Serilog.Sinks.MSSqlServer;
using System.Collections.ObjectModel;
using System.Data;
using System.Net;
using System.Text.Json;
using System.Text.Json.Serialization;

Log.Information("Starting the application setup");

try
{
    var builder = WebApplication.CreateBuilder(args);

    var columnOptions = new ColumnOptions
    {
        AdditionalColumns = new Collection<SqlColumn>
    {
        new SqlColumn { ColumnName = "DeviceId", DataType = SqlDbType.NVarChar, DataLength = 128 },
        new SqlColumn { ColumnName = "UserId", DataType = SqlDbType.NVarChar, DataLength = 450 },
        new SqlColumn { ColumnName = "RequestPath", DataType = SqlDbType.NVarChar, DataLength = 2000 },
        new SqlColumn { ColumnName = "CorrelationId", DataType = SqlDbType.NVarChar, DataLength = 450 },
        new SqlColumn { ColumnName = "ApplicationVersion", DataType = SqlDbType.NVarChar, DataLength = 100 },
        new SqlColumn { ColumnName = "Environment", DataType = SqlDbType.NVarChar, DataLength = 100 }
    }
    };

    // Configure services
    builder.Services.AddControllersWithViews().AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
        options.JsonSerializerOptions.NumberHandling = JsonNumberHandling.AllowReadingFromString | JsonNumberHandling.WriteAsString;
    });

    var outputTemplate = "{Timestamp:yyyy-MM-dd HH:mm:ss} [{Level:u3}] {Message:lj}{NewLine}{Exception}";

    Log.Logger = new LoggerConfiguration()
        .MinimumLevel.Warning() // Only log warnings, errors, and critical issues
        .WriteTo.Console(new Serilog.Formatting.Display.MessageTemplateTextFormatter(outputTemplate))
        .WriteTo.MSSqlServer(
            connectionString: builder.Configuration.GetConnectionString("DefaultConnection"),
            sinkOptions: new Serilog.Sinks.MSSqlServer.MSSqlServerSinkOptions { TableName = "Logs", AutoCreateSqlTable = true },
            columnOptions: columnOptions,
            restrictedToMinimumLevel: Serilog.Events.LogEventLevel.Warning)
        .Enrich.FromLogContext()
        .Enrich.WithEnvironmentName()
        .Enrich.WithMachineName()
        .Enrich.WithThreadId()
        .CreateLogger();

    builder.Host.UseSerilog();

    builder.Services.AddHttpClient();
    builder.Services.AddRazorPages();
    builder.Services.AddSignalR();
    builder.Services.AddCors(options =>
    {
        options.AddPolicy("AllowSpecificOrigin", builder =>
        {
            builder.WithOrigins("https://localhost:7119")
                   .AllowAnyHeader()
                   .AllowAnyMethod()
                   .AllowCredentials();
        });
    });
    builder.Services.AddAuthorization(options =>
    {
        options.AddPolicy("RequireAdministratorRole",
            policy => policy.RequireRole("Admin"));

        options.AddPolicy("RequireMechanicRole",
            policy => policy.RequireRole("Mechanic"));

        options.AddPolicy("RequireMaintenanceRole",
            policy => policy.RequireRole("Maintenance"));

        options.AddPolicy("RequireUserRole",
            policy => policy.RequireRole("User"));

        options.AddPolicy("RequirePartsManagerRole",
            policy => policy.RequireRole("PartsManager"));

        options.AddPolicy("RequireMaintenanceOrMechanicRole",
            policy => policy.RequireRole("Maintenance", "Mechanic"));

        options.AddPolicy("RequireMaintenanceOrMechanicOrAdminRole",
            policy => policy.RequireRole("Maintenance", "Mechanic", "Admin"));

        options.AddPolicy("RequireAnyManagerRole",
            policy => policy.RequireRole("Admin", "Maintenance", "Mechanic", "PartsManager"));

        options.AddPolicy("AllCanAccess",
            policy => policy.RequireRole("Admin", "Maintenance", "Mechanic", "PartsManager", "User"));

    });
    builder.Services.ConfigureApplicationCookie(options =>
    {
        options.Cookie.HttpOnly = true;
        options.Cookie.SecurePolicy = CookieSecurePolicy.Always;
        options.Cookie.SameSite = SameSiteMode.None;
        options.ExpireTimeSpan = TimeSpan.FromMinutes(60);
        options.LoginPath = "/login";
        options.LogoutPath = "/logout";
        options.SlidingExpiration = true;
    });
    builder.Services.AddDefaultIdentity<IdentityUser>(options => options.SignIn.RequireConfirmedAccount = true)
        .AddRoles<IdentityRole>()
        .AddEntityFrameworkStores<ApplicationDbContext>();
    builder.Services.Configure<IdentityOptions>(options =>
    {
        options.Password.RequireDigit = true;
        options.Password.RequireLowercase = true;
        options.Password.RequireNonAlphanumeric = true;
        options.Password.RequireUppercase = true;
        options.Password.RequiredLength = 6;
        options.Password.RequiredUniqueChars = 1;

        options.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(10);
        options.Lockout.MaxFailedAccessAttempts = 5;
        options.Lockout.AllowedForNewUsers = true;
        options.SignIn.RequireConfirmedEmail = true;

        options.User.AllowedUserNameCharacters =
        "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.-_@+ ";
        options.User.RequireUniqueEmail = true;
    });
    builder.Services.Configure<AppSettings>(builder.Configuration.GetSection("AppSettings"));
    builder.Services.Configure<EmailSettings>(builder.Configuration.GetSection("EmailSettings"));
    builder.Services.AddScoped<IEmailService, EmailService>();
    builder.Services.AddScoped<IPdfService, PdfService>();
    builder.Services.AddScoped<ITokenService, TokenService>();
    builder.Services.AddDbContext<ApplicationDbContext>(options =>
        options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection"), sqlServerOptions => sqlServerOptions.CommandTimeout(180)));
    builder.Services.AddAuthentication(options =>
    {
        options.DefaultScheme = CookieAuthenticationDefaults.AuthenticationScheme;
        options.DefaultChallengeScheme = GoogleDefaults.AuthenticationScheme;
    })
    .AddCookie(options =>
    {
        options.LoginPath = "/login";
        options.LogoutPath = "/logout";
        options.ExpireTimeSpan = TimeSpan.FromMinutes(30);
    })
    .AddGoogle(options =>
    {
        options.ClientId = builder.Configuration["Authentication:Google:ClientId"];
        options.ClientSecret = builder.Configuration["Authentication:Google:ClientSecret"];
    });


    var app = builder.Build();

    // Seed roles and admin user
    using (var scope = app.Services.CreateScope())
    {
        var services = scope.ServiceProvider;
        try
        {
            var configuration = services.GetRequiredService<IConfiguration>();
            var roleManager = services.GetRequiredService<RoleManager<IdentityRole>>();
            var userManager = services.GetRequiredService<UserManager<IdentityUser>>();

            var adminCredentials = configuration.GetSection("AdminCredentials").Get<AdminCredentials>();

            CreateRoles.EnsureRolesCreated(services);
            await SeedAdminUser(userManager, roleManager, adminCredentials.Email, adminCredentials.Password);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error creating roles: {ex.Message}");
        }
    }

    app.Use(async (context, next) =>
    {
        var user = context.User.Identity.IsAuthenticated ? context.User.Identity.Name : "Anonymous";
        Serilog.Context.LogContext.PushProperty("UserId", user);
        Serilog.Context.LogContext.PushProperty("RequestPath", context.Request.Path);
        Serilog.Context.LogContext.PushProperty("CorrelationId", context.TraceIdentifier);

        // Log request details
        Log.Information("Request: {RequestPath}, Query: {QueryString}, User: {UserId}, CorrelationId: {CorrelationId}",
            context.Request.Path, context.Request.QueryString, user, context.TraceIdentifier);

        await next.Invoke();

        // Log when request processing is complete
        Log.Information("Finished processing request: {RequestPath}, CorrelationId: {CorrelationId}",
            context.Request.Path, context.TraceIdentifier);
    });
    if (app.Environment.IsDevelopment())
    {
        app.UseWebAssemblyDebugging();
    }
    else
    {
        app.UseDeveloperExceptionPage();
        app.UseExceptionHandler(appBuilder =>
        {
            appBuilder.Run(async context =>
            {
                context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                context.Response.ContentType = "application/json";

                var contextFeature = context.Features.Get<IExceptionHandlerFeature>();
                if (contextFeature != null)
                {
                    await context.Response.WriteAsync(new
                    {
                        StatusCode = context.Response.StatusCode,
                        Message = "Internal Server Error. Please try again later."
                    }.ToString());
                }
            });
        });
        app.UseHsts();
    }

    app.UseBlazorFrameworkFiles();
    app.UseStaticFiles();
    app.UseRouting();
    app.UseCors("AllowSpecificOrigin");
    app.UseAuthentication();
    app.UseAuthorization();
    app.MapControllers();
    app.MapRazorPages();
    app.MapHub<UserStatusHub>("/UserStatusHub");
    app.MapFallbackToFile("index.html");

    app.Run();
}
catch (Exception ex)
{
    Log.Fatal($"Application failed to start, {ex}");
}
finally
{
    Log.CloseAndFlush();
}

static async Task SeedAdminUser(UserManager<IdentityUser> userManager, RoleManager<IdentityRole> roleManager, string email, string password)
{
    try
    {
        if (!await roleManager.RoleExistsAsync("Admin"))
        {
            var roleResult = await roleManager.CreateAsync(new IdentityRole("Admin"));
            if (!roleResult.Succeeded)
            {
                throw new Exception($"Failed to create 'Admin' role: {roleResult.Errors.First().Description}");
            }
        }
    }
    catch (Exception ex)
    {
        Console.WriteLine($"Error creating role: {ex.Message}");
        throw;
    }
    try
    {
        var adminUser = await userManager.FindByEmailAsync(email);
        if (adminUser == null)
        {
            adminUser = new IdentityUser { UserName = email, Email = email };
            var result = await userManager.CreateAsync(adminUser, password);
            if (!result.Succeeded)
            {
                throw new Exception($"Failed to create admin user: {result.Errors.First().Description}");
            }
            else
            {
                var addToRoleResult = await userManager.AddToRoleAsync(adminUser, "Admin");
                if (!addToRoleResult.Succeeded)
                {
                    throw new Exception($"Failed to assign 'Admin' role to user: {addToRoleResult.Errors.First().Description}");
                }
            }
        }
    }
    catch (Exception ex)
    {
        Console.WriteLine($"Error creating user: {ex.Message}");
        throw;
    }
}

public class AdminCredentials
{
    public string Email { get; set; }
    public string Password { get; set; }
}