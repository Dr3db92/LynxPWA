﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;
using System.Collections.Concurrent;
using System.Security.Claims;

public class UserStatusHub : Hub
{
    // Concurrent dictionary to keep track of active users
    private static ConcurrentDictionary<string, string> ActiveUsers = new ConcurrentDictionary<string, string>();

    public override async Task OnConnectedAsync()
    {
        var userId = Context.User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        var userEmail = Context.User.Identity.Name;

        // Log connection information
        if (!string.IsNullOrEmpty(userId))
        {
            ActiveUsers.TryAdd(Context.ConnectionId, userId);
            Console.WriteLine($"User Connected: {userEmail} (ID: {userId})");

            await Clients.All.SendAsync("ReceiveUserStatus", userId, userEmail, true);

            // Send the updated list of active users
            await Clients.All.SendAsync("ReceiveActiveUsers", ActiveUsers.Values.ToList());
        }
        else
        {
            Console.WriteLine("User identification failed.");
            await Clients.Caller.SendAsync("ReceiveError", "User identification failed.");
        }

        await base.OnConnectedAsync();
    }

    public override async Task OnDisconnectedAsync(Exception exception)
    {
        if (ActiveUsers.TryRemove(Context.ConnectionId, out var userId))
        {
            var userEmail = Context.User.Identity.Name;
            Console.WriteLine($"User Disconnected: {userEmail} (ID: {userId})");

            await Clients.All.SendAsync("ReceiveUserStatus", userId, userEmail, false);

            // Optionally, send the updated list of active users
            await Clients.All.SendAsync("ReceiveActiveUsers", ActiveUsers.Values.ToList());
        }

        await base.OnDisconnectedAsync(exception);
    }

    public async Task GetActiveUsers()
    {
        // Send the list of active user IDs to the caller
        await Clients.Caller.SendAsync("ReceiveActiveUsers", ActiveUsers.Values.ToList());
    }
}